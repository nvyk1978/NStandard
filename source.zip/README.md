# N Standard

Initial reference app for N UI components.

## v0.1.1
- Main menu with `エクスプローラ` and `ダイアログ` buttons.
- Opens a floating N Explorer activity.
- Folder hierarchy navigation / parent navigation.
- Internal / available storage switching.
- New folder creation with SAF fallback when direct mkdir is blocked.
- Current folder display.
- Bottom cancel / confirm action.
- N palette and directly grabbable scrollbar (4dp visible thumb / 30dp hit area).


## N Dialog
- Generic dialog component extracted from BookmarkLauncher 0.1.19.
- Includes choice / plain menu / message / single-line input samples.
- Bookmark-specific bookmark, folder, thumbnail and repository behavior is excluded.

## N Explorer
- NExplorerActivity is based on Chirami 0.1.62 folder picker.
- Returns selected absolute folder path in NExplorerActivity.RESULT_PATH.

## Signing
N Standard 0.1.1 (2) establishes the persistent signing key at `app/nstandard-dev.keystore`.
All subsequent builds must retain this keystore byte-for-byte and keep the signingConfig unchanged.

## Staged: ImgStalker thumbnail component
- Added main-screen 「サムネイル」 below 「診断ログ」.
- Extracted reusable NThumbnailLoader from ImgStalker thumbnail pipeline.
- Retains 3-worker pool, memory-scaled 8-48 MiB LRU cache, in-flight coalescing, weak ImageView waiters, generation cancellation, 320px sampled decode, 32 MiB image cap, and 64 MiB local-temp video frame extraction.
- Removed ImgStalker-specific session dependencies; optional Referer/Cookie can be supplied per item.
- Added thumbnail demo screen with image/video mode, URL load, CENTER_CROP square preview, resolution, video duration/play overlay, cache clear and close.
- Added INTERNET permission for remote thumbnail loading.
- Not burned yet; applicationId/version/signing unchanged.

## Staged: PriceRec three-dot dialog
- Added 「三点リーダー」 button below 「サムネイル」.
- Extracted PriceRec v0.1.81 app-menu pattern: AlertDialog.setItems() + rounded N Gray (#454040) window, 20dp radius.
- Demo rows: リスト1 / リスト2 / リスト3 / リスト4 / リスト5.
- No ROM burn / source.zip packaging performed yet.
