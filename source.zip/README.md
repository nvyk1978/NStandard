# N Standard

Reference app for N UI components.

## v0.1.3
- Rebuilt the thumbnail demo around the PriceRec-style image area.
- Image area now contains `撮影`, `全て選択`, and `選択` controls only above the cell display area.
- `撮影` launches the system camera and appends the returned preview image as a thumbnail cell.
- Thumbnail cells support selection and the N green / white check mark.
- Standalone emulator area now contains `セル追加` and `セル確定` controls.
- `セル追加` appends an empty cell and makes it the current selection.
- Cells can be tapped to change the current selection.
- `セル確定` adds the N green / white check mark to the selected cell.
- Emulator remains fully independent from thumbnail/image state.
- Existing applicationId and persistent signing key are retained.

## v0.1.2
- Thumbnail screen title moved down by 50dp.
- Image controls grouped into a dedicated image area.
- Added a working image picker button for local image preview.
- Added a standalone emulator area above the cache-clear / close row.
- Emulator area is implemented as `NEmulatorArea` with no dependency on thumbnail loader/image state.
- Existing applicationId and persistent signing key are retained.

## v0.1.1
- Main menu with `エクスプローラ` and `ダイアログ` buttons.
- Opens a floating N Explorer activity.
- Folder hierarchy navigation / parent navigation.
- Internal / available storage switching.
- New folder creation with SAF fallback when direct mkdir is blocked.
- Current folder display.
- Bottom cancel / confirm action.
- N palette and directly grabbable scrollbar (4dp visible thumb / 30dp hit area).

## N Dialog
- Generic dialog component extracted from BookmarkLauncher 0.1.19.
- Includes choice / plain menu / message / single-line input samples.
- Bookmark-specific bookmark, folder, thumbnail and repository behavior is excluded.

## N Explorer
- NExplorerActivity is based on Chirami 0.1.62 folder picker.
- Returns selected absolute folder path in NExplorerActivity.RESULT_PATH.

## Signing
N Standard 0.1.1 (2) established the persistent signing key at `app/nstandard-dev.keystore`.
All subsequent builds must retain this keystore byte-for-byte and keep the signingConfig unchanged.
