# N Standard 0.1.16 (17)

N Standard is a UI / behaviour reference app for the N specification.

## 0.1.4
- Removed the previous thumbnail/image demo implementation and thumbnail loader.
- Replaced the old custom cell with the Price Rec. 0.1.81 store-cell header implementation:
  - N gray rounded card (18dp)
  - 48dp reorder handle area
  - 18sp bold store name
  - straight green analyzed check badge
  - Price Rec. N toggle (44x26 inside a 58x48 hit area)
  - Price Rec. card padding / spacing
- Each NS cell keeps the requested date and time below it.
- Long-press enters ImgStalker-style selection mode; tap toggles, long-press can range-select, and the selection button switches between select / select-all / all-clear.
- The emulator area remains an independent component and contains only `セル追加` / `セル確定`.
- `セル追加` adds a draft Price Rec.-style store cell; `セル確定` gives the newest draft the analyzed check and updates its timestamp.
- Main demo button renamed from `サムネイル` to `店舗セル`.
- applicationId remains `com.cmyk.nstandard`; stable signing keystore retained.


0.1.5 (6): PriceRec store screen reference rebuilt from scratch: store cards, expand/collapse, long-press store menu, handle drag reorder, toggle, expanded actions/photo selection, bottom search and plus button.
0.1.7 (8): Added PriceRec product-list reference, renamed store sample to 店舗リスト, and replaced the Property dialog contents with the PriceRec 商品編集 reference UI.

0.1.11 (12): Color settings refinement: geometric vector plus icons, larger BG label, tighter list margins, editable palette names using N dialog styling, katakana N-color names for List 1, generic palette numbering from the right, and long-press copy of color names/codes.

0.1.12 (13): Color settings usability pass: palette circles are directly tappable; list-card long press no longer intercepts child taps; names are hidden from the list surface and shown/edited only inside the color editor; compact natural wrapping replaces label-driven 3-column layout; plus vector is thinner and larger.

0.1.14 (15): Color list overflow menu, duplicate/delete, palette delete button, N-dialog name editing, balanced fixed-grid palette spacing.
0.1.15 (16): Added アイコン見本 and ボタン見本 reference screens. Icon references collect the existing three-dot, diagnostic, settings, tag, document, plus, rotate, crop/check and BookmarkLauncher-derived glyphs in one place; the button reference includes capsule/thin-capsule buttons, NToggleSwitch, text buttons, color-specified OK/delete/plus samples, and three long-press selectable cells with the N green straight check. Dialog-family widths now use the common N dialog width and stable first-frame sizing to suppress visible resize/jitter.

0.1.16 (17): Fixed the ボタン見本 circular plus sample so the oval is never stretched; cell selection now enters selection mode on long-press and toggles selection by tap. アイコン見本 removes alarm/timer/stopwatch/countdown/crop, uses square cells with equal horizontal/vertical gaps, adds the ImgStalker Instagram icon beside Twitter, and replaces Bookmark × with BookmarkLauncher's actual black circular delete target and vector X.
