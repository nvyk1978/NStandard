# N Standard 0.1.25 (26)

N Standard is a UI / behaviour reference app for the N specification.

## 0.1.4
- Removed the previous thumbnail/image demo implementation and thumbnail loader.
- Replaced the old custom cell with the Price Rec. 0.1.81 store-cell header implementation:
  - N gray rounded card (18dp)
  - 48dp reorder handle area
  - 18sp bold store name
  - straight green analyzed check badge
  - Price Rec. N toggle (44x26 inside a 58x48 hit area)
  - Price Rec. card padding / spacing
- Each NS cell keeps the requested date and time below it.
- Long-press enters ImgStalker-style selection mode; tap toggles, long-press can range-select, and the selection button switches between select / select-all / all-clear.
- The emulator area remains an independent component and contains only `セル追加` / `セル確定`.
- `セル追加` adds a draft Price Rec.-style store cell; `セル確定` gives the newest draft the analyzed check and updates its timestamp.
- Main demo button renamed from `サムネイル` to `店舗セル`.
- applicationId remains `com.cmyk.nstandard`; stable signing keystore retained.


0.1.5 (6): PriceRec store screen reference rebuilt from scratch: store cards, expand/collapse, long-press store menu, handle drag reorder, toggle, expanded actions/photo selection, bottom search and plus button.
0.1.7 (8): Added PriceRec product-list reference, renamed store sample to 店舗リスト, and replaced the Property dialog contents with the PriceRec 商品編集 reference UI.

0.1.11 (12): Color settings refinement: geometric vector plus icons, larger BG label, tighter list margins, editable palette names using N dialog styling, katakana N-color names for List 1, generic palette numbering from the right, and long-press copy of color names/codes.

0.1.12 (13): Color settings usability pass: palette circles are directly tappable; list-card long press no longer intercepts child taps; names are hidden from the list surface and shown/edited only inside the color editor; compact natural wrapping replaces label-driven 3-column layout; plus vector is thinner and larger.

0.1.14 (15): Color list overflow menu, duplicate/delete, palette delete button, N-dialog name editing, balanced fixed-grid palette spacing.
0.1.15 (16): Added アイコン見本 and ボタン見本 reference screens. Icon references collect the existing three-dot, diagnostic, settings, tag, document, plus, rotate, crop/check and BookmarkLauncher-derived glyphs in one place; the button reference includes capsule/thin-capsule buttons, NToggleSwitch, text buttons, color-specified OK/delete/plus samples, and three long-press selectable cells with the N green straight check. Dialog-family widths now use the common N dialog width and stable first-frame sizing to suppress visible resize/jitter.

0.1.16 (17): Fixed the ボタン見本 circular plus sample so the oval is never stretched; cell selection now enters selection mode on long-press and toggles selection by tap. アイコン見本 removes alarm/timer/stopwatch/countdown/crop, uses square cells with equal horizontal/vertical gaps, adds the ImgStalker Instagram icon beside Twitter, and replaces Bookmark × with BookmarkLauncher's actual black circular delete target and vector X.


0.1.17 (18): ボタン見本のセル3個を正方形で横一列に統一。NS内の各ページで既存の題字上余白を50dp基準に統一。
0.1.18 (19): アイコン見本の各アイコンを正方形セルの幾何学的センターへ固定。ラベルがアイコン位置を押し上げないオーバーレイ構造へ変更。

0.1.19 (20): アイコン見本に長押し選択／タップ選択解除と共有ZIP生成を追加。共有ZIPには選択したアイコンだけの実装情報・元アプリ・ChatGPT向け指示を収録。メイン画面は「プロパティ」を「ダイアログ」直下、「三点リーダー」を「診断ログ」直上へ移動。「リスト」を「商品リスト」へ改名。

0.1.20 (21): エクスプローラのフォルダアイコンをBookmarkLauncherのブックマークフォルダ形状へ統一。ボタン見本のセル文字を中央、選択チェックを右上へ配置。プロパティ題字を「プロパティ」、グリップ付きリスト題字を「グリップ付きリスト」へ変更。細いカプセル型ボタンは診断ログで実際に使用している共通実装を再利用。


0.1.21 (22): アイコン見本の選択緑チェックを一回り拡大。＋アイコンはBookmarkLauncher由来の共通実装 NPlusView に統合し、アイコン見本の表示名を「＋」へ一本化。エクスプローラの「戻る／＋新規フォルダ／キャンセル／このフォルダを選択」は診断ログと同じ細いカプセル型ボタンへ統一し、各行を左詰め／右詰め配置に変更。


0.1.22 (23): アイコン見本の選択緑チェックはView枠だけでなく緑円と白チェックの実描画を拡大。ボタン見本のセル1/2/3は文字のfont paddingを除外して縦横の幾何学的センターへ固定。OK直下にNオレンジ #775500 の「オプションボタン」見本を追加。商品編集ダイアログのタグ＋をPriceRec v0.1.81準拠の実動作へ変更し、タグ選択・新規追加・重複防止・削除・名称変更・OK/キャンセル反映をサンプルデータで実装。


0.1.23 (24): ボタン見本のセル長押し選択の上に、商品編集で使用中のPriceRec v0.1.81由来タグ選択コンポーネントそのものを共用してタグ欄見本を追加。タグ列は横スクロール、右端の＋はスクロール位置に依存せず固定。タップ選択/解除、長押し名称変更、＋からタグ選択・新規追加・削除・名称変更を行う既存挙動を維持。セル長押し選択も従来どおり維持。アイコン見本の緑チェックは0.1.20のサイズ/描画へ完全復帰し、通常の「チェック」アイコンだけを一回り拡大。左右content marginは25dpを維持。

0.1.24 (25): ボタン見本から「テキストボタン」を削除。エクスプローラのメイン背景をNグレー #454040、ストレージ選択欄をNダークグレー #252020へ変更。左右content marginはデフォルト25dpを維持。


0.1.25 (26): マージン規格を共通化。通常ページ（マージンページを除く）は上50dp／左右25dp／下30dpを基準に統一。マージンページの初期値も上50／左右25／下30へ変更し、現在値をクリップボードへコピーする「コピー」と規定値へ戻す「規定値」ボタンを追加。エクスプローラ、診断ログ、三点リーダー、商品編集などダイアログ系の外形横幅は画面左右15dp余白へ統一。
