# N Standard

Initial reference app for N UI components.

## v0.1.0
- Main menu with one `Nエクスプローラ` button.
- Opens a floating N Explorer activity.
- Folder hierarchy navigation / parent navigation.
- Internal / available storage switching.
- New folder creation with SAF fallback when direct mkdir is blocked.
- Current folder display.
- Bottom cancel / confirm action.
- N palette and directly grabbable scrollbar (4dp visible thumb / 30dp hit area).
