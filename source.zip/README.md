# N Standard

Initial reference app for N UI components.

## v0.1.1
- Main menu with one `Nエクスプローラ` button.
- Opens a floating N Explorer activity.
- Folder hierarchy navigation / parent navigation.
- Internal / available storage switching.
- New folder creation with SAF fallback when direct mkdir is blocked.
- Current folder display.
- Bottom cancel / confirm action.
- N palette and directly grabbable scrollbar (4dp visible thumb / 30dp hit area).


## N Explorer
- NExplorerActivity is based on Chirami 0.1.62 folder picker.
- Returns selected absolute folder path in NExplorerActivity.RESULT_PATH.

## Signing
N Standard 0.1.1 (2) establishes the persistent signing key at `app/nstandard-dev.keystore`.
All subsequent builds must retain this keystore byte-for-byte and keep the signingConfig unchanged.
