package com.cmyk.nstandard;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Insets;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.DragEvent;
import android.view.Gravity;
import android.view.HapticFeedbackConstants;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowInsets;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

/**
 * Price Rec. product-list reference transplanted into N Standard.
 * Production DB/file operations are replaced by local demo state; visible layout
 * and interaction behavior intentionally follows Price Rec.'s product list.
 */
public final class NProductListActivity extends Activity {
    public static final String EXTRA_TITLE = "title";
    public static final String EXTRA_ALL_STORES = "all_stores";

    private static final int BG = Color.parseColor("#303030");
    private static final int DGRAY = Color.parseColor("#252020");
    private static final int GRAY = Color.parseColor("#454040");
    private static final int LGRAY = Color.parseColor("#656060");
    private static final int BLUE = Color.parseColor("#223355");
    private static final int LBLUE = Color.parseColor("#445577");
    private static final int RED = Color.parseColor("#441100");
    private static final int ORANGE = Color.parseColor("#775500");
    private static final int NWHITE = Color.parseColor("#A9A999");
    private static final int WHITE = Color.WHITE;
    private static final int SECONDARY = NWHITE;

    private static final int UI_MARGIN = 14;
    private static final int UI_SPACING = 8;
    private static final int UI_TIGHT = 4;
    private static final int UI_ACTION_GAP = 5;

    private final ArrayList<DemoProduct> products = new ArrayList<>();
    private final LinkedHashSet<String> activeTags = new LinkedHashSet<>();
    private final LinkedHashSet<String> activeStores = new LinkedHashSet<>();
    private final Set<Long> selected = new HashSet<>();
    private final Map<Long, LinearLayout> visibleRows = new HashMap<>();

    private LinearLayout panel;
    private LinearLayout listHost;
    private LinearLayout selectionHost;
    private TextView footerSelectionCount;
    private EditText queryInput;
    private ScrollView verticalScroll;
    private HorizontalScrollView horizontalScroll;
    private boolean selecting;
    private boolean allStores;
    private long nextId = 1L;

    private ArrayList<String> columnOrder;
    private final Map<String, Integer> columnWidths = new HashMap<>();

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        allStores = getIntent().getBooleanExtra(EXTRA_ALL_STORES, false);
        seedProducts();
        loadColumnSettings();
        setContentView(buildUi());
        DiagLog.write(this, "OPEN_PRODUCT_LIST_REFERENCE allStores=" + allStores);
    }

    private void seedProducts() {
        String[] names = {
                "カールスバーグ 330ml", "アサヒ スーパードライ", "キリン 一番搾り", "ハイネケン 330ml",
                "メーカーズマーク", "ジェムソン", "ワイルドターキー 8年", "ボンベイ・サファイア",
                "タンカレー No.10", "モンテス・アルファ シャルドネ", "シャブリ", "カヴァ ブリュット"
        };
        String[] tags = {"ビール", "ウイスキー", "ジン", "ワイン", "タグなし"};
        String[] stores = {"店舗名", "店舗 02", "店舗 03"};
        long now = System.currentTimeMillis();
        for (int i = 0; i < 112; i++) {
            DemoProduct p = new DemoProduct();
            p.id = nextId++;
            p.name = names[i % names.length];
            p.store = stores[i % stores.length];
            p.price = 420 + ((i * 37) % 2100);
            p.volume = (i % 5 == 0) ? 700 : ((i % 3 == 0) ? 500 : 330);
            p.tag = tags[i % tags.length];
            p.capturedAt = now - i * 86400000L;
            p.priceType = (i % 2 == 0) ? "税込" : "税抜";
            p.productKey = "prd." + p.name.replace(" ", ".") + "." + p.volume;
            products.add(p);
        }
    }

    private View buildUi() {
        panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setBackgroundColor(BG);
        panel.setPadding(dp(UI_MARGIN), dp(N.PAGE_TITLE_TOP_DP), dp(UI_MARGIN), dp(UI_SPACING));
        panel.setOnApplyWindowInsetsListener((v, insets) -> {
            int top = 0, bottom = 0;
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                Insets bars = insets.getInsets(WindowInsets.Type.systemBars());
                Insets ime = insets.getInsets(WindowInsets.Type.ime());
                top = bars.top;
                bottom = Math.max(bars.bottom, ime.bottom);
            } else {
                top = insets.getSystemWindowInsetTop();
                bottom = insets.getSystemWindowInsetBottom();
            }
            v.setPadding(dp(UI_MARGIN), top + dp(N.PAGE_TITLE_TOP_DP), dp(UI_MARGIN), bottom + dp(UI_SPACING));
            return insets;
        });

        LinearLayout titleRow = new LinearLayout(this);
        titleRow.setGravity(Gravity.CENTER_VERTICAL);
        TextView title = text(getIntent().getStringExtra(EXTRA_TITLE) == null
                ? (allStores ? "全商品リスト" : "商品リスト")
                : getIntent().getStringExtra(EXTRA_TITLE), 22, NWHITE, true);
        titleRow.addView(title, new LinearLayout.LayoutParams(0, dp(48), 1f));
        TextView csv = actionLink(allStores ? "全CSV一覧" : "CSV一覧");
        csv.setOnClickListener(v -> NCsvHistoryDialog.show(this, allStores ? null : "店舗名"));
        titleRow.addView(csv, new LinearLayout.LayoutParams(dp(allStores ? 112 : 96), dp(42)));
        panel.addView(titleRow);

        if (allStores) {
            panel.addView(makeStoreFilterArea(), lp(-1, 42, 0, 0, 0, UI_TIGHT));
        }
        panel.addView(makeTagFilterArea(), lp(-1, 42, 0, 0, 0, UI_SPACING));

        queryInput = dialogInput("商品名検索");
        panel.addView(productSearchInputHolder(queryInput), new LinearLayout.LayoutParams(-1, dp(46)));
        queryInput.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) { }
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) {
                selected.clear(); selecting = false; render();
            }
            @Override public void afterTextChanged(Editable s) { }
        });

        selectionHost = new LinearLayout(this);
        selectionHost.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout.LayoutParams selectionLp = new LinearLayout.LayoutParams(-1, dp(48));
        selectionLp.topMargin = dp(UI_SPACING);
        panel.addView(selectionHost, selectionLp);

        listHost = new LinearLayout(this);
        listHost.setOrientation(LinearLayout.VERTICAL);
        panel.addView(listHost, new LinearLayout.LayoutParams(-1, 0, 1f));

        LinearLayout footer = new LinearLayout(this);
        footer.setGravity(Gravity.CENTER_VERTICAL);
        footer.setPadding(0, dp(UI_TIGHT), 0, 0);
        footerSelectionCount = text("", 14, SECONDARY, true);
        footer.addView(footerSelectionCount, new LinearLayout.LayoutParams(dp(92), dp(48)));
        footer.addView(new View(this), new LinearLayout.LayoutParams(0, dp(48), 1f));
        TextView close = actionLink("閉じる");
        close.setGravity(Gravity.CENTER);
        close.setOnClickListener(v -> finish());
        footer.addView(close, new LinearLayout.LayoutParams(dp(92), dp(48)));
        panel.addView(footer, new LinearLayout.LayoutParams(-1, dp(52)));

        render();
        panel.requestApplyInsets();
        return panel;
    }

    private View makeStoreFilterArea() {
        LinearLayout host = new LinearLayout(this);
        host.setGravity(Gravity.CENTER_VERTICAL);
        renderStoreFilter(host);
        return host;
    }

    private void renderStoreFilter(LinearLayout host) {
        host.removeAllViews();
        HorizontalScrollView hsv = new HorizontalScrollView(this);
        hsv.setHorizontalScrollBarEnabled(false);
        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);
        TextView all = chip("全店舗", activeStores.isEmpty(), false);
        all.setOnClickListener(v -> { activeStores.clear(); selected.clear(); selecting = false; renderStoreFilter(host); render(); });
        row.addView(all);
        LinkedHashSet<String> stores = new LinkedHashSet<>();
        for (DemoProduct p : products) stores.add(p.store);
        for (String store : stores) {
            TextView c = chip(store, activeStores.contains(store), false);
            c.setOnClickListener(v -> {
                if (!activeStores.add(store)) activeStores.remove(store);
                selected.clear(); selecting = false; renderStoreFilter(host); render();
            });
            row.addView(c);
        }
        hsv.addView(row);
        host.addView(hsv, new LinearLayout.LayoutParams(-1, dp(42)));
    }

    private View makeTagFilterArea() {
        LinearLayout host = new LinearLayout(this);
        host.setGravity(Gravity.CENTER_VERTICAL);
        renderTagFilter(host);
        return host;
    }

    private void renderTagFilter(LinearLayout host) {
        host.removeAllViews();
        HorizontalScrollView hsv = new HorizontalScrollView(this);
        hsv.setHorizontalScrollBarEnabled(false);
        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);
        LinkedHashSet<String> tags = new LinkedHashSet<>();
        for (DemoProduct p : products) if (!"タグなし".equals(p.tag)) tags.add(p.tag);
        for (String tag : tags) {
            TextView c = chip(tag, activeTags.contains(tag), false);
            c.setOnClickListener(v -> {
                if (!activeTags.add(tag)) activeTags.remove(tag);
                selected.clear(); selecting = false; renderTagFilter(host); render();
            });
            row.addView(c);
        }
        TextView none = chip("タグなし", activeTags.contains("タグなし"), true);
        none.setOnClickListener(v -> {
            if (!activeTags.add("タグなし")) activeTags.remove("タグなし");
            selected.clear(); selecting = false; renderTagFilter(host); render();
        });
        row.addView(none);
        hsv.addView(row);
        host.addView(hsv, new LinearLayout.LayoutParams(-1, dp(42)));
    }

    private void render() {
        if (selectionHost == null || listHost == null) return;
        int keepY = verticalScroll == null ? 0 : verticalScroll.getScrollY();
        int keepX = horizontalScroll == null ? 0 : horizontalScroll.getScrollX();
        renderSelectionControls();
        listHost.removeAllViews();
        visibleRows.clear();

        ArrayList<DemoProduct> filtered = filteredProducts();
        if (filtered.isEmpty()) {
            TextView empty = text("条件に一致する商品がありません。", 14, SECONDARY, false);
            empty.setGravity(Gravity.CENTER);
            listHost.addView(empty, new LinearLayout.LayoutParams(-1, -1));
            return;
        }

        LinearLayout sheet = new LinearLayout(this);
        sheet.setOrientation(LinearLayout.VERTICAL);
        sheet.addView(makeProductHeader());
        String lastName = null;
        for (int i = 0; i < filtered.size(); i++) {
            if (i > 0 && i % 50 == 0) sheet.addView(makeProductHeader());
            DemoProduct p = filtered.get(i);
            String displayName = p.name.equals(lastName) ? "" : p.name;
            lastName = p.name;
            LinearLayout row = makeProductRow(p, displayName);
            visibleRows.put(p.id, row);
            if (selecting && selected.contains(p.id)) row.setBackgroundColor(BLUE);
            row.setOnClickListener(v -> {
                if (selecting) toggleSelected(p.id, "row"); else showProductEditor(p);
            });
            row.setOnLongClickListener(v -> {
                v.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS);
                if (!selecting) { selecting = true; selected.clear(); selected.add(p.id); }
                else toggleSelectedInternal(p.id);
                if (selected.isEmpty()) selecting = false;
                renderSelectionControls(); refreshSelectionHighlights();
                return true;
            });
            sheet.addView(row);
        }
        horizontalScroll = new HorizontalScrollView(this);
        horizontalScroll.setHorizontalScrollBarEnabled(false);
        horizontalScroll.addView(sheet);
        verticalScroll = new ScrollView(this);
        verticalScroll.setVerticalScrollBarEnabled(true);
        verticalScroll.addView(horizontalScroll);
        listHost.addView(verticalScroll, new LinearLayout.LayoutParams(-1, -1));
        verticalScroll.post(() -> { verticalScroll.scrollTo(0, keepY); horizontalScroll.scrollTo(keepX, 0); });
    }

    private ArrayList<DemoProduct> filteredProducts() {
        ArrayList<DemoProduct> out = new ArrayList<>();
        String q = queryInput == null ? "" : queryInput.getText().toString().trim().toLowerCase(Locale.ROOT);
        for (DemoProduct p : products) {
            if (!allStores && !"店舗名".equals(p.store)) continue;
            if (allStores && !activeStores.isEmpty() && !activeStores.contains(p.store)) continue;
            if (!activeTags.isEmpty() && !activeTags.contains(p.tag)) continue;
            String hay = (p.name + " " + p.store + " " + p.tag).toLowerCase(Locale.ROOT);
            if (!q.isEmpty() && !hay.contains(q)) continue;
            out.add(p);
        }
        return out;
    }

    private void renderSelectionControls() {
        selectionHost.removeAllViews();
        selectionHost.setPadding(0, 0, 0, dp(UI_TIGHT));
        footerSelectionCount.setText(selecting ? selected.size() + "件選択" : "");
        footerSelectionCount.setVisibility(selecting ? View.VISIBLE : View.INVISIBLE);
        if (!selecting) {
            ImageView add = roundPlusIcon(LBLUE, NWHITE, "新規商品追加");
            add.setOnClickListener(v -> showAddProductDialog());
            selectionHost.addView(add, new LinearLayout.LayoutParams(dp(38), dp(38)));
            selectionHost.addView(new View(this), new LinearLayout.LayoutParams(0, dp(38), 1f));
            TextView all = button("全て選択", DGRAY, 13);
            all.setOnClickListener(v -> {
                selecting = true; selected.clear(); for (DemoProduct p : filteredProducts()) selected.add(p.id);
                renderSelectionControls(); refreshSelectionHighlights();
            });
            LinearLayout.LayoutParams a = new LinearLayout.LayoutParams(dp(96), dp(38)); a.rightMargin = dp(UI_ACTION_GAP);
            selectionHost.addView(all, a);
            TextView select = button("選択", BLUE, 13);
            select.setOnClickListener(v -> { selecting = true; selected.clear(); renderSelectionControls(); refreshSelectionHighlights(); });
            selectionHost.addView(select, new LinearLayout.LayoutParams(dp(96), dp(38)));
        } else {
            selectionHost.setGravity(Gravity.CENTER_VERTICAL | Gravity.END);
            TextView delete = button("削除", selected.isEmpty() ? DGRAY : RED, 13);
            delete.setEnabled(!selected.isEmpty());
            delete.setOnClickListener(v -> deleteSelected());
            LinearLayout.LayoutParams d = new LinearLayout.LayoutParams(dp(72), dp(38)); d.rightMargin = dp(6);
            selectionHost.addView(delete, d);
            TextView same = button("同一商品", selected.size() < 2 ? DGRAY : ORANGE, 13);
            same.setEnabled(selected.size() >= 2);
            same.setOnClickListener(v -> unifySelected());
            LinearLayout.LayoutParams s = new LinearLayout.LayoutParams(dp(92), dp(38)); s.leftMargin = dp(6);
            selectionHost.addView(same, s);
            TextView cancel = button("キャンセル", DGRAY, 13);
            cancel.setOnClickListener(v -> { selected.clear(); selecting = false; renderSelectionControls(); refreshSelectionHighlights(); });
            LinearLayout.LayoutParams c = new LinearLayout.LayoutParams(dp(88), dp(38)); c.leftMargin = dp(6);
            selectionHost.addView(cancel, c);
            TextView tags = button("タグ編集", selected.isEmpty() ? DGRAY : BLUE, 13);
            tags.setEnabled(!selected.isEmpty());
            tags.setOnClickListener(v -> editSelectedTags());
            LinearLayout.LayoutParams t = new LinearLayout.LayoutParams(dp(96), dp(38)); t.leftMargin = dp(6);
            selectionHost.addView(tags, t);
        }
    }

    private LinearLayout makeProductHeader() {
        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setBackgroundColor(DGRAY);
        row.setOnDragListener((v, event) -> {
            if (event.getAction() == DragEvent.ACTION_DROP && event.getLocalState() instanceof String) {
                String dragged = (String) event.getLocalState();
                int target = headerIndexAt(row, event.getX());
                int from = columnOrder.indexOf(dragged);
                if (from >= 0 && target >= 0 && from != target) {
                    columnOrder.remove(from);
                    columnOrder.add(Math.min(target, columnOrder.size()), dragged);
                    saveColumnSettings(); render();
                }
                return true;
            }
            return true;
        });
        for (String key : columnOrder) {
            TextView cell = text(columnLabel(key), 13, SECONDARY, true);
            cell.setGravity(Gravity.CENTER_VERTICAL);
            cell.setPadding(dp(10), 0, dp(10), 0);
            cell.setContentDescription(columnLabel(key) + "。タップで幅変更、長押しで並べ替え");
            cell.setOnClickListener(v -> showColumnWidthDialog(key));
            cell.setOnLongClickListener(v -> {
                v.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS);
                ClipData data = ClipData.newPlainText("column", key);
                v.startDragAndDrop(data, new View.DragShadowBuilder(v), key, 0);
                return true;
            });
            row.addView(cell, new LinearLayout.LayoutParams(dp(width(key)), dp(38)));
        }
        return row;
    }

    private int headerIndexAt(LinearLayout row, float x) {
        float cursor = 0f;
        for (int i = 0; i < row.getChildCount(); i++) {
            View child = row.getChildAt(i);
            float mid = cursor + child.getWidth() / 2f;
            if (x < mid) return i;
            cursor += child.getWidth();
        }
        return Math.max(0, row.getChildCount() - 1);
    }

    private LinearLayout makeProductRow(DemoProduct p, String productCell) {
        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.TOP);
        row.setPadding(0, dp(1), 0, dp(1));
        for (String key : columnOrder) {
            int w = width(key);
            if ("product".equals(key)) {
                FrameLayout cell = new FrameLayout(this);
                cell.setMinimumHeight(dp(44));
                TextView name = text(productCell, 13, WHITE, false);
                name.setGravity(Gravity.START | Gravity.TOP);
                name.setMaxLines(3);
                name.setEllipsize(TextUtils.TruncateAt.END);
                name.setPadding(dp(10), dp(5), dp(36), dp(5));
                cell.addView(name, new FrameLayout.LayoutParams(-1, -2, Gravity.TOP));
                View magnifier = new MagnifierIconView(this);
                magnifier.setContentDescription("他店舗価格を比較");
                magnifier.setOnClickListener(v -> {
                    if (selecting) toggleSelected(p.id, "compare");
                    else Toast.makeText(this, p.name + " の価格比較", Toast.LENGTH_SHORT).show();
                });
                FrameLayout.LayoutParams mp = new FrameLayout.LayoutParams(dp(30), dp(30), Gravity.END | Gravity.TOP);
                mp.rightMargin = dp(3);
                cell.addView(magnifier, mp);
                row.addView(cell, new LinearLayout.LayoutParams(dp(w), -2));
            } else {
                TextView cell = text(columnValue(key, p), "tag".equals(key) ? 13 : 14, WHITE, false);
                cell.setGravity(Gravity.START | Gravity.TOP);
                cell.setMaxLines(3);
                cell.setEllipsize(TextUtils.TruncateAt.END);
                cell.setMinHeight(dp(44));
                cell.setPadding(dp(10), dp(5), dp(10), dp(5));
                row.addView(cell, new LinearLayout.LayoutParams(dp(w), -2));
            }
        }
        return row;
    }

    private void toggleSelected(long id, String source) {
        toggleSelectedInternal(id);
        if (selected.isEmpty()) selecting = false;
        DiagLog.write(this, "PRODUCT_SELECT_TOGGLE id=" + id + " source=" + source + " count=" + selected.size());
        renderSelectionControls(); refreshSelectionHighlights();
    }

    private void toggleSelectedInternal(long id) {
        if (!selected.add(id)) selected.remove(id);
    }

    private void refreshSelectionHighlights() {
        for (Map.Entry<Long, LinearLayout> e : visibleRows.entrySet()) {
            e.getValue().setBackgroundColor(selecting && selected.contains(e.getKey()) ? BLUE : Color.TRANSPARENT);
        }
    }

    private void showProductEditor(DemoProduct p) {
        NProductEditorDialog.EditorData data = new NProductEditorDialog.EditorData();
        data.storeName = p.store;
        data.name = p.name;
        data.price = p.price;
        data.volume = p.volume;
        data.productKey = p.productKey == null ? "" : p.productKey;
        data.priceType = p.priceType;
        if (p.tag != null && !"タグなし".equals(p.tag)) data.tags.add(p.tag);
        NProductEditorDialog.show(this, data, () -> {
            p.store = data.storeName;
            p.name = data.name;
            p.price = data.price;
            p.volume = data.volume;
            p.productKey = data.productKey;
            p.priceType = data.priceType;
            p.tag = data.tags.isEmpty() ? "タグなし" : data.tags.iterator().next();
            p.capturedAt = System.currentTimeMillis();
            render();
        }, () -> {
            products.remove(p);
            selected.remove(p.id);
            if (selected.isEmpty()) selecting = false;
            render();
        });
    }

    private void showAddProductDialog() {
        NNewProductDialog.show(this, allStores ? null : "店舗名", data -> {
            DemoProduct p = new DemoProduct();
            p.id = nextId++;
            p.name = data.name;
            p.price = data.price;
            p.volume = data.volume;
            p.store = data.storeName == null ? "店舗名" : data.storeName;
            p.tag = data.tags.isEmpty() ? "タグなし" : data.tags.iterator().next();
            p.capturedAt = System.currentTimeMillis();
            p.priceType = data.priceType;
            p.productKey = data.productKey;
            products.add(0, p);
            render();
        });
    }

    private void deleteSelected() {
        if (selected.isEmpty()) return;
        new AlertDialog.Builder(this).setTitle("削除")
                .setMessage(selected.size() + "件の商品を削除しますか？")
                .setNegativeButton("キャンセル", null)
                .setPositiveButton("削除", (d, w) -> {
                    products.removeIf(p -> selected.contains(p.id));
                    selected.clear(); selecting = false; render();
                }).show();
    }

    private void unifySelected() {
        if (selected.size() < 2) return;
        DemoProduct base = null;
        for (DemoProduct p : products) if (selected.contains(p.id)) { base = p; break; }
        if (base == null) return;
        final DemoProduct selectedBase = base;
        ArrayList<String> candidates = new ArrayList<>();
        for (DemoProduct p : products) if (selected.contains(p.id) && !candidates.contains(p.name)) candidates.add(p.name);
        new AlertDialog.Builder(this).setTitle("同一商品")
                .setItems(candidates.toArray(new String[0]), (d, which) -> {
                    String common = candidates.get(which);
                    for (DemoProduct p : products) if (selected.contains(p.id)) p.name = common;
                    Toast.makeText(this, selected.size() + "件を同一商品にしました", Toast.LENGTH_SHORT).show();
                    selected.clear(); selecting = false; render();
                }).show();
    }

    private void editSelectedTags() {
        if (selected.isEmpty()) return;
        String[] tags = {"ビール", "ウイスキー", "ジン", "ワイン", "タグなし"};
        new AlertDialog.Builder(this).setTitle("タグ編集")
                .setItems(tags, (d, which) -> {
                    for (DemoProduct p : products) if (selected.contains(p.id)) p.tag = tags[which];
                    selected.clear(); selecting = false; render();
                }).show();
    }

    private void showColumnWidthDialog(String key) {
        final int current = width(key);
        final String[] options = {"狭く", "標準", "広く", current + "dp"};
        new AlertDialog.Builder(this).setTitle(columnLabel(key) + " 列幅")
                .setItems(options, (d, which) -> {
                    int value;
                    if (which == 0) value = Math.max(minWidth(key), current - 20);
                    else if (which == 2) value = Math.min(maxWidth(key), current + 20);
                    else if (which == 1) value = defaultWidth(key);
                    else return;
                    columnWidths.put(key, value); saveColumnSettings(); render();
                }).show();
    }

    private View productSearchInputHolder(EditText input) {
        FrameLayout holder = new FrameLayout(this);
        holder.addView(input, new FrameLayout.LayoutParams(-1, -1));
        input.setPadding(input.getPaddingLeft(), input.getPaddingTop(), dp(46), input.getPaddingBottom());
        TextView clear = text("×", 24, DGRAY, true);
        clear.setGravity(Gravity.CENTER);
        clear.setVisibility(input.length() == 0 ? View.GONE : View.VISIBLE);
        clear.setOnClickListener(v -> { input.setText(""); input.requestFocus(); });
        FrameLayout.LayoutParams cp = new FrameLayout.LayoutParams(dp(40), dp(40), Gravity.END | Gravity.CENTER_VERTICAL);
        cp.rightMargin = dp(3); holder.addView(clear, cp);
        input.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) { }
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) { clear.setVisibility(s == null || s.length() == 0 ? View.GONE : View.VISIBLE); }
            @Override public void afterTextChanged(Editable s) { }
        });
        return holder;
    }

    private EditText dialogInput(String hint) {
        EditText input = new EditText(this);
        input.setHint(hint);
        input.setSingleLine(true);
        input.setTextSize(17);
        input.setTextColor(DGRAY);
        input.setHintTextColor(GRAY);
        input.setGravity(Gravity.CENTER_VERTICAL);
        input.setIncludeFontPadding(false);
        input.setMinHeight(dp(48));
        input.setPadding(dp(16), 0, dp(16), 0);
        input.setBackground(roundRect(NWHITE, 999));
        return input;
    }

    private TextView chip(String label, boolean selected, boolean none) {
        TextView v = text(label, 13, WHITE, false);
        v.setGravity(Gravity.CENTER);
        v.setPadding(dp(13), 0, dp(13), 0);
        v.setBackground(roundRect(selected ? (none ? ORANGE : BLUE) : DGRAY, 10));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, dp(28));
        lp.rightMargin = dp(6); v.setLayoutParams(lp);
        return v;
    }

    private TextView button(String label, int color, int sizeSp) {
        TextView b = text(label, sizeSp, WHITE, true);
        b.setGravity(Gravity.CENTER);
        b.setBackground(roundRect(color, 999));
        b.setPadding(dp(10), 0, dp(10), 0);
        return b;
    }

    private TextView actionLink(String label) {
        TextView v = text(label, 14, WHITE, true);
        v.setGravity(Gravity.CENTER);
        v.setBackground(roundRect(LBLUE, 999));
        v.setPadding(dp(8), 0, dp(8), 0);
        return v;
    }

    private ImageView roundPlusIcon(int bg, int fg, String description) {
        ImageView iv = new ImageView(this);
        iv.setContentDescription(description);
        iv.setBackground(circle(bg));
        iv.setImageDrawable(new PlusDrawable(fg));
        iv.setPadding(dp(12), dp(12), dp(12), dp(12));
        return iv;
    }

    private TextView text(String value, float size, int color, boolean bold) {
        TextView v = new TextView(this);
        v.setText(value);
        v.setTextSize(size);
        v.setTextColor(color);
        v.setTypeface(Typeface.DEFAULT, bold ? Typeface.BOLD : Typeface.NORMAL);
        v.setIncludeFontPadding(false);
        return v;
    }

    private GradientDrawable roundRect(int color, float radius) {
        GradientDrawable g = new GradientDrawable(); g.setColor(color); g.setCornerRadius(dp(radius)); return g;
    }
    private GradientDrawable circle(int color) {
        GradientDrawable g = new GradientDrawable(); g.setColor(color); g.setShape(GradientDrawable.OVAL); return g;
    }

    private LinearLayout.LayoutParams lp(int wDp, int hDp, int l, int t, int r, int b) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(wDp < 0 ? wDp : dp(wDp), hDp < 0 ? hDp : dp(hDp));
        p.setMargins(dp(l), dp(t), dp(r), dp(b)); return p;
    }

    private String columnValue(String key, DemoProduct p) {
        switch (key) {
            case "store": return p.store;
            case "price": return "¥" + p.price + ("税込".equals(p.priceType) ? " 込" : " 抜");
            case "volume": return String.valueOf(p.volume);
            case "unit100": return p.volume <= 0 ? "—" : "¥" + Math.round(p.price * 100f / p.volume) + ("税込".equals(p.priceType) ? " 込" : " 抜");
            case "tag": return p.tag;
            case "date": return new SimpleDateFormat("yyyy/MM/dd HH:mm", Locale.JAPAN).format(new Date(p.capturedAt));
            default: return "";
        }
    }

    private String columnLabel(String key) {
        switch (key) {
            case "product": return "商品名";
            case "store": return "店舗";
            case "price": return "価格";
            case "volume": return "容量";
            case "unit100": return "100単価";
            case "tag": return "タグ";
            case "date": return "日付";
            default: return key;
        }
    }

    private int defaultWidth(String key) {
        switch (key) {
            case "product": return 220; case "store": return 140; case "price": return 90;
            case "volume": return 80; case "unit100": return 90; case "tag": return 120; case "date": return 130;
            default: return 100;
        }
    }
    private int minWidth(String key) {
        switch (key) {
            case "product": return 120; case "store": return 80; case "price": return 70;
            case "volume": return 56; case "unit100": return 70; case "tag": return 70; case "date": return 90;
            default: return 56;
        }
    }
    private int maxWidth(String key) {
        switch (key) {
            case "product": return 420; case "store": return 300; case "price": return 220;
            case "volume": return 180; case "unit100": return 220; case "tag": return 280; case "date": return 280;
            default: return 320;
        }
    }
    private int width(String key) { return columnWidths.containsKey(key) ? columnWidths.get(key) : defaultWidth(key); }

    private void loadColumnSettings() {
        String def = allStores ? "product,store,price,volume,unit100,tag,date" : "product,price,volume,unit100,tag,date";
        String raw = getPreferences(MODE_PRIVATE).getString(allStores ? "cols_all" : "cols_store", def);
        columnOrder = new ArrayList<>(Arrays.asList(raw.split(",")));
        for (String k : new String[]{"product","store","price","volume","unit100","tag","date"}) {
            int val = getPreferences(MODE_PRIVATE).getInt("width_" + k, defaultWidth(k));
            columnWidths.put(k, val);
        }
    }

    private void saveColumnSettings() {
        getPreferences(MODE_PRIVATE).edit()
                .putString(allStores ? "cols_all" : "cols_store", TextUtils.join(",", columnOrder))
                .apply();
        android.content.SharedPreferences.Editor e = getPreferences(MODE_PRIVATE).edit();
        for (Map.Entry<String,Integer> x : columnWidths.entrySet()) e.putInt("width_" + x.getKey(), x.getValue());
        e.apply();
    }

    private int dp(float v) { return Math.round(v * getResources().getDisplayMetrics().density); }
    private String blankFallback(String value, String fallback) { String s = value == null ? "" : value.trim(); return s.isEmpty() ? fallback : s; }

    private static final class DemoProduct {
        long id; String name; String store; int price; int volume; String tag; long capturedAt; String priceType; String productKey;
    }

    private final class MagnifierIconView extends View {
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        MagnifierIconView(Context c) { super(c); p.setColor(NWHITE); p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(dp(2)); }
        @Override protected void onDraw(Canvas c) {
            super.onDraw(c);
            float r = Math.min(getWidth(), getHeight()) * 0.23f;
            float cx = getWidth() * 0.43f, cy = getHeight() * 0.42f;
            c.drawCircle(cx, cy, r, p);
            c.drawLine(cx + r * .72f, cy + r * .72f, getWidth() * .78f, getHeight() * .78f, p);
        }
    }

    private final class PlusDrawable extends android.graphics.drawable.Drawable {
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        PlusDrawable(int color) { p.setColor(color); p.setStrokeWidth(dp(2)); p.setStrokeCap(Paint.Cap.SQUARE); }
        @Override public void draw(Canvas c) {
            float cx = getBounds().exactCenterX(), cy = getBounds().exactCenterY();
            float r = Math.min(getBounds().width(), getBounds().height()) * .28f;
            c.drawLine(cx-r, cy, cx+r, cy, p); c.drawLine(cx, cy-r, cx, cy+r, p);
        }
        @Override public void setAlpha(int alpha) { p.setAlpha(alpha); }
        @Override public void setColorFilter(android.graphics.ColorFilter cf) { p.setColorFilter(cf); }
        @Override public int getOpacity() { return android.graphics.PixelFormat.TRANSLUCENT; }
    }
}
