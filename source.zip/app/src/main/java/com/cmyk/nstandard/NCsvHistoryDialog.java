package com.cmyk.nstandard;

import android.app.Activity;
import android.app.AlertDialog;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/** Price Rec. v0.1.81 CSV一覧／CSV内容のNS見本。 */
public final class NCsvHistoryDialog {
    private static final int DGRAY = Color.parseColor("#252020");
    private static final int GRAY = Color.parseColor("#454040");
    private static final int LGRAY = Color.parseColor("#656060");
    private static final int BLUE = Color.parseColor("#223355");
    private static final int RED = Color.parseColor("#441100");
    private static final int WHITE = Color.WHITE;
    private static final int SECONDARY = Color.parseColor("#A9A999");
    private static final SimpleDateFormat DATE = new SimpleDateFormat("yyyy/MM/dd HH:mm", Locale.JAPAN);

    private NCsvHistoryDialog() {}

    public static void show(Activity activity, String storeName) {
        if (activity == null) return;
        ArrayList<Batch> batches = seed(storeName);
        LinearLayout content = new LinearLayout(activity);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(activity,14), dp(activity,8), dp(activity,14), dp(activity,14));

        LinearLayout rows = new LinearLayout(activity);
        rows.setOrientation(LinearLayout.VERTICAL);
        ScrollView scroll = fadeScroll(activity);
        scroll.addView(rows);
        content.addView(scroll, new LinearLayout.LayoutParams(-1, dp(activity,470)));

        final Runnable[] render = new Runnable[1];
        render[0] = () -> {
            rows.removeAllViews();
            if (batches.isEmpty()) {
                TextView empty = text(activity, "CSV取込はまだありません。", 14, SECONDARY, false);
                empty.setGravity(Gravity.CENTER); empty.setPadding(dp(activity,12), dp(activity,30), dp(activity,12), dp(activity,30));
                rows.addView(empty); return;
            }
            for (Batch batch : new ArrayList<>(batches)) {
                LinearLayout card = new LinearLayout(activity);
                card.setOrientation(LinearLayout.VERTICAL);
                card.setPadding(dp(activity,12), dp(activity,8), dp(activity,12), dp(activity,8));
                card.setBackground(round(activity, DGRAY, 14));

                card.addView(text(activity, DATE.format(new Date(batch.importedAt)), 14, WHITE, true), new LinearLayout.LayoutParams(-1, dp(activity,26)));
                TextView file = text(activity, batch.fileName, 13, SECONDARY, false); file.setSingleLine(true);
                card.addView(file, new LinearLayout.LayoutParams(-1, dp(activity,24)));
                String stores = batch.storeNames.isEmpty() ? "" : "  /  " + batch.storeNames;
                card.addView(text(activity, batch.quality + "  " + batch.count + "件（追加" + batch.addCount + " / 更新" + batch.updateCount + "）" + stores,
                        12, SECONDARY, false), new LinearLayout.LayoutParams(-1, dp(activity,24)));
                card.setOnClickListener(v -> showContents(activity, batch));

                LinearLayout actions = new LinearLayout(activity); actions.setGravity(Gravity.CENTER_VERTICAL);
                if (batch.readOnly) {
                    TextView mode = text(activity, "閲覧モード", 13, SECONDARY, true); mode.setGravity(Gravity.CENTER_VERTICAL | Gravity.END);
                    actions.addView(mode, new LinearLayout.LayoutParams(0, dp(activity,42), 1f));
                } else {
                    TextView reload = action(activity, "再読み込み", BLUE); reload.setGravity(Gravity.CENTER_VERTICAL | Gravity.START);
                    reload.setOnClickListener(v -> confirmReload(activity, batch, render[0]));
                    actions.addView(reload, new LinearLayout.LayoutParams(0, dp(activity,42), 1f));
                    TextView delete = action(activity, "CSVを削除", RED); delete.setGravity(Gravity.CENTER_VERTICAL | Gravity.END);
                    delete.setOnClickListener(v -> confirmDelete(activity, batch, batches, render[0]));
                    actions.addView(delete, new LinearLayout.LayoutParams(dp(activity,132), dp(activity,42)));
                }
                card.addView(actions, new LinearLayout.LayoutParams(-1, dp(activity,42)));
                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1,-2); lp.bottomMargin = dp(activity,8); rows.addView(card,lp);
            }
        };

        TextView close = action(activity, "閉じる", BLUE); close.setGravity(Gravity.CENTER);
        LinearLayout footer = new LinearLayout(activity); footer.setGravity(Gravity.END | Gravity.CENTER_VERTICAL);
        footer.addView(close, new LinearLayout.LayoutParams(dp(activity,96), dp(activity,42)));
        LinearLayout.LayoutParams flp = new LinearLayout.LayoutParams(-1, dp(activity,48)); flp.topMargin = dp(activity,8); content.addView(footer, flp);

        render[0].run();
        AlertDialog dialog = new AlertDialog.Builder(activity)
                .setTitle(storeName == null ? "全CSV一覧" : storeName + " CSV一覧")
                .setView(content).create();
        close.setOnClickListener(v -> dialog.dismiss());
        showRounded(activity, dialog, true);
    }

    private static void confirmReload(Activity activity, Batch batch, Runnable rerender) {
        AlertDialog d = new AlertDialog.Builder(activity)
                .setTitle("CSV再読み込み")
                .setMessage("編集したデータは削除されます。\n\n" + batch.fileName + " を元のCSV内容で再読み込みしますか？")
                .setNegativeButton("キャンセル", null)
                .setPositiveButton("再読み込み", (x,w) -> {
                    batch.importedAt = System.currentTimeMillis();
                    Toast.makeText(activity, "CSVを再読み込みしました", Toast.LENGTH_LONG).show();
                    if (rerender != null) rerender.run();
                }).create();
        showRounded(activity,d,false);
    }

    private static void confirmDelete(Activity activity, Batch batch, List<Batch> batches, Runnable rerender) {
        AlertDialog d = new AlertDialog.Builder(activity)
                .setTitle("CSV消去")
                .setMessage(DATE.format(new Date(batch.importedAt)) + "\n" + batch.fileName +
                        "\n\nこのCSVで追加した商品は削除し、更新した商品は取込前の状態へ戻します。\n店舗・タグ・元画像は削除しません。")
                .setNegativeButton("キャンセル", null)
                .setPositiveButton("消去", (x,w) -> {
                    batches.remove(batch);
                    Toast.makeText(activity, "削除 " + batch.addCount + " / 復元 " + batch.updateCount, Toast.LENGTH_LONG).show();
                    if (rerender != null) rerender.run();
                }).create();
        showRounded(activity,d,false);
    }

    private static void showContents(Activity activity, Batch batch) {
        LinearLayout content = new LinearLayout(activity); content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(activity,14), dp(activity,8), dp(activity,14), dp(activity,8));
        TextView meta = text(activity, DATE.format(new Date(batch.importedAt)) + "  /  " + batch.quality + "  " + batch.count + "件\n" + batch.fileName,
                12, SECONDARY, false); meta.setPadding(0,dp(activity,4),0,dp(activity,8)); content.addView(meta);

        LinearLayout sheet = new LinearLayout(activity); sheet.setOrientation(LinearLayout.VERTICAL);
        int[] widths = {90,240,170,100,90,110,150};
        sheet.addView(sheetRow(activity, new String[]{"動作","商品名","店舗","価格","容量","タグ","source_image"}, widths, true));
        for (String[] row : batch.rows) sheet.addView(sheetRow(activity,row,widths,false));
        HorizontalScrollView hsv = new HorizontalScrollView(activity); hsv.setHorizontalScrollBarEnabled(false); hsv.addView(sheet);
        ScrollView scroll = fadeScroll(activity); scroll.addView(hsv); content.addView(scroll,new LinearLayout.LayoutParams(-1,dp(activity,500)));
        AlertDialog d = new AlertDialog.Builder(activity).setTitle("CSV内容").setView(content).setNegativeButton("閉じる",null).create();
        showRounded(activity,d,true);
    }

    private static View sheetRow(Activity a, String[] values, int[] widths, boolean header) {
        LinearLayout row = new LinearLayout(a); row.setOrientation(LinearLayout.HORIZONTAL);
        row.setBackgroundColor(header ? GRAY : Color.TRANSPARENT);
        for (int i=0;i<values.length;i++) {
            TextView t = text(a, values[i], header ? 12 : 13, header ? WHITE : SECONDARY, header);
            t.setPadding(dp(a,8),dp(a,7),dp(a,8),dp(a,7)); t.setGravity(Gravity.START|Gravity.CENTER_VERTICAL);
            row.addView(t,new LinearLayout.LayoutParams(dp(a,widths[i]),dp(a,40)));
        }
        return row;
    }

    private static ArrayList<Batch> seed(String storeName) {
        String store = storeName == null ? "店舗名 / 店舗 02" : storeName;
        ArrayList<Batch> out = new ArrayList<>();
        long now = System.currentTimeMillis();
        Batch a = new Batch(now-3600_000L,"PriceRec_20260928_194202.csv","高品質",8,6,2,store,false);
        a.rows.add(new String[]{"追加","カールスバーグ 330ml", storeName==null?"店舗名":storeName,"¥500","330","ビール","IMG_20260928_01.jpg"});
        a.rows.add(new String[]{"更新","ジェムソン", storeName==null?"店舗名":storeName,"¥2,180","700","ウイスキー","IMG_20260928_02.jpg"});
        a.rows.add(new String[]{"追加","シャブリ", storeName==null?"店舗名":storeName,"¥2,980","750","ワイン","IMG_20260928_03.jpg"});
        out.add(a);
        Batch b = new Batch(now-86400_000L,"PriceRec_20260927_181055.csv","標準",5,5,0,store,false);
        b.rows.add(new String[]{"追加","タンカレー No.10", storeName==null?"店舗名":storeName,"¥3,280","700","ジン","IMG_20260927_01.jpg"});
        out.add(b);
        Batch c = new Batch(now-2*86400_000L,"PriceRec_20260926_173012.csv","標準",3,2,1,store,true);
        c.rows.add(new String[]{"更新","ハイネケン 330ml", storeName==null?"店舗名":storeName,"¥398","330","ビール","—"});
        out.add(c);
        return out;
    }

    private static final class Batch {
        long importedAt; final String fileName,quality,storeNames; final int count,addCount,updateCount; final boolean readOnly;
        final ArrayList<String[]> rows = new ArrayList<>();
        Batch(long t,String f,String q,int c,int a,int u,String s,boolean ro){importedAt=t;fileName=f;quality=q;count=c;addCount=a;updateCount=u;storeNames=s;readOnly=ro;}
    }

    private static ScrollView fadeScroll(Activity a) { ScrollView s=new ScrollView(a); s.setVerticalFadingEdgeEnabled(true); s.setFadingEdgeLength(dp(a,24)); return s; }
    private static TextView action(Activity a,String s,int color){TextView t=text(a,s,13,WHITE,true);t.setPadding(dp(a,8),0,dp(a,8),0);t.setClickable(true);return t;}
    private static TextView text(Activity a,String s,int sp,int color,boolean bold){TextView t=new TextView(a);t.setText(s);t.setTextSize(sp);t.setTextColor(color);t.setGravity(Gravity.CENTER_VERTICAL);if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);return t;}
    private static GradientDrawable round(Activity a,int color,float r){GradientDrawable g=new GradientDrawable();g.setColor(color);g.setCornerRadius(dp(a,r));return g;}
    private static void showRounded(Activity a, AlertDialog d, boolean wide){Window pre=d.getWindow();if(pre!=null)pre.setBackgroundDrawable(round(a,GRAY,20));N.showDialogStable(a,d,wide ? .94f : .90f);Window w=d.getWindow();if(w!=null)w.setBackgroundDrawable(round(a,GRAY,20));}
    private static int dp(Activity a,float v){return Math.round(v*a.getResources().getDisplayMetrics().density);}
}
