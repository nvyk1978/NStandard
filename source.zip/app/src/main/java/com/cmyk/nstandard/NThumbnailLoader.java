package com.cmyk.nstandard;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.media.MediaMetadataRetriever;
import android.os.Handler;
import android.os.Looper;
import android.util.LruCache;
import android.view.View;
import android.webkit.WebSettings;
import android.widget.ImageView;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.lang.ref.WeakReference;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

/**
 * Generic thumbnail loader extracted from ImgStalker.
 *
 * Retained behavior:
 * - 3-worker background pool
 * - memory-scaled LRU bitmap cache (8-48 MiB)
 * - duplicate in-flight request coalescing
 * - weak ImageView waiters
 * - generation based cancellation so stale callbacks cannot rebind recycled views
 * - image download cap 32 MiB / video cap 64 MiB
 * - bounds-first sampled decode, max edge 320 px, RGB_565
 * - video frame extraction through a bounded local temporary file
 *
 * ImgStalker-specific cookie/session classes are intentionally removed. Callers can provide
 * optional Referer/Cookie values through Item when a protected source requires them.
 */
public final class NThumbnailLoader {
    public enum Kind { IMAGE, VIDEO }

    public static final class Item {
        public final String url;
        public final Kind kind;
        public final String referrer;
        public final String cookie;
        public volatile int width;
        public volatile int height;
        public volatile long durationMs;

        public Item(String url, Kind kind) {
            this(url, kind, "", "");
        }

        public Item(String url, Kind kind, String referrer, String cookie) {
            this.url = url == null ? "" : url.trim();
            this.kind = kind == null ? Kind.IMAGE : kind;
            this.referrer = referrer == null ? "" : referrer.trim();
            this.cookie = cookie == null ? "" : cookie.trim();
        }
    }

    public interface MetadataListener {
        void onMetadataChanged(Item item);
    }

    private static final int MAX_THUMB_BYTES = 32 * 1024 * 1024;
    private static final int MAX_VIDEO_THUMB_BYTES = 64 * 1024 * 1024;
    private static final int THUMB_MAX_EDGE = 320;

    private static final class Pending {
        final int generation;
        final ArrayList<WeakReference<ImageView>> waiters = new ArrayList<>();
        Future<?> future;

        Pending(int generation) {
            this.generation = generation;
        }
    }

    private final Context appContext;
    private final Handler main = new Handler(Looper.getMainLooper());
    private final ExecutorService pool = Executors.newFixedThreadPool(3);
    private final LruCache<String, Bitmap> cache;
    private final Object pendingLock = new Object();
    private final Map<String, Pending> pendingByKey = new HashMap<>();
    private final MetadataListener metadataListener;
    private final String userAgent;
    private volatile int generation = 1;

    public NThumbnailLoader(Context context) {
        this(context, null);
    }

    public NThumbnailLoader(Context context, MetadataListener metadataListener) {
        this.appContext = context.getApplicationContext();
        this.metadataListener = metadataListener;

        String baseUa;
        try {
            baseUa = WebSettings.getDefaultUserAgent(context);
        } catch (Exception e) {
            baseUa = "Mozilla/5.0 (Linux; Android) AppleWebKit/537.36 Mobile Safari/537.36";
        }
        this.userAgent = baseUa + " NStandard/" + DiagLog.versionName(context);

        int maxKb = (int) (Runtime.getRuntime().maxMemory() / 1024L);
        int cacheKb = Math.max(8192, Math.min(49152, maxKb / 8));
        cache = new LruCache<String, Bitmap>(cacheKb) {
            @Override
            protected int sizeOf(String key, Bitmap value) {
                return Math.max(1, value.getByteCount() / 1024);
            }
        };
        DiagLog.write(context, "THUMB_CACHE_INIT kb=" + cacheKb + " workers=3 edge=" + THUMB_MAX_EDGE);
    }

    /** Still-image prefetch. Video extraction remains visible-view only, matching ImgStalker. */
    public void prefetch(Item item) {
        if (!valid(item) || item.kind != Kind.IMAGE) return;
        String key = cacheKey(item);
        Bitmap hit = cache.get(key);
        if (usable(hit)) return;

        final int requestGeneration = generation;
        final Pending request;
        synchronized (pendingLock) {
            Pending existing = pendingByKey.get(key);
            if (existing != null && existing.generation == requestGeneration) return;
            request = new Pending(requestGeneration);
            pendingByKey.put(key, request);
            request.future = pool.submit(() -> runRequest(key, item, request));
        }
        DiagLog.write(appContext, "THUMB_PREFETCH kind=" + item.kind + " url=" + item.url
                + " generation=" + requestGeneration);
    }

    public void load(ImageView view, Item item) {
        if (view == null || !valid(item)) return;
        view.setVisibility(View.VISIBLE);

        String key = cacheKey(item);
        Object previousTag = view.getTag();
        boolean sameBinding = key.equals(previousTag);
        view.setTag(key);

        Bitmap hit = cache.get(key);
        if (usable(hit)) {
            view.setImageBitmap(hit);
            view.setAlpha(1f);
            notifyMetadata(item);
            DiagLog.write(appContext, "THUMB_CACHE_HIT kind=" + item.kind + " url=" + item.url);
            return;
        }

        if (!sameBinding) view.setImageDrawable(null);
        view.setAlpha(0.55f);

        final int requestGeneration = generation;
        final Pending request;
        synchronized (pendingLock) {
            Pending existing = pendingByKey.get(key);
            if (existing != null && existing.generation == requestGeneration) {
                if (addWaiter(existing, view)) {
                    DiagLog.write(appContext, "THUMB_JOIN kind=" + item.kind + " url=" + item.url
                            + " waiters=" + existing.waiters.size());
                }
                return;
            }

            request = new Pending(requestGeneration);
            addWaiter(request, view);
            pendingByKey.put(key, request);
            request.future = pool.submit(() -> runRequest(key, item, request));
        }
        DiagLog.write(appContext, "THUMB_LOAD kind=" + item.kind + " url=" + item.url
                + " generation=" + requestGeneration);
    }

    public void clear(ImageView view) {
        if (view == null) return;
        view.setTag(null);
        view.setImageDrawable(null);
        view.setAlpha(0.55f);
    }

    public void clearCache() {
        cache.evictAll();
        DiagLog.write(appContext, "THUMB_CACHE_CLEAR");
    }

    public void cancelPending() {
        ArrayList<Future<?>> futures = new ArrayList<>();
        int newGeneration = generation + 1;
        generation = newGeneration;
        synchronized (pendingLock) {
            for (Pending p : pendingByKey.values()) {
                if (p.future != null) futures.add(p.future);
            }
            pendingByKey.clear();
        }
        for (Future<?> future : futures) future.cancel(true);
        DiagLog.write(appContext, "THUMB_CANCEL_PENDING count=" + futures.size()
                + " generation=" + newGeneration);
    }

    public void shutdown() {
        cancelPending();
        pool.shutdownNow();
        cache.evictAll();
        DiagLog.write(appContext, "THUMB_SHUTDOWN");
    }

    private void runRequest(String key, Item item, Pending request) {
        Bitmap bitmap = null;
        boolean metadataWasMissing = item.width <= 0 || item.height <= 0
                || (item.kind == Kind.VIDEO && item.durationMs <= 0L);
        try {
            if (Thread.currentThread().isInterrupted()) return;
            bitmap = item.kind == Kind.VIDEO ? fetchVideoFrame(item) : fetchImage(item);
            if (bitmap != null) cache.put(key, bitmap);
        } catch (InterruptedException interrupted) {
            Thread.currentThread().interrupt();
            DiagLog.write(appContext, "THUMB_ABORT kind=" + item.kind + " url=" + item.url
                    + " generation=" + request.generation);
        } catch (Exception e) {
            if (request.generation == generation && !Thread.currentThread().isInterrupted()) {
                DiagLog.write(appContext, "THUMB_FAIL kind=" + item.kind + " url=" + item.url
                        + " error=" + e.getClass().getSimpleName() + ": " + e.getMessage());
            }
        } finally {
            synchronized (pendingLock) {
                if (pendingByKey.get(key) == request) pendingByKey.remove(key);
            }
        }

        final Bitmap ready = bitmap;
        final boolean metadataNowAvailable = metadataWasMissing
                && (item.width > 0 || item.height > 0 || item.durationMs > 0L);
        if (request.generation != generation) return;

        main.post(() -> {
            if (request.generation != generation) return;
            for (WeakReference<ImageView> ref : request.waiters) {
                ImageView target = ref.get();
                if (target == null) continue;
                Object tag = target.getTag();
                if (!(tag instanceof String) || !key.equals(tag)) continue;
                if (usable(ready)) {
                    target.setImageBitmap(ready);
                    target.setAlpha(1f);
                } else {
                    target.setImageDrawable(null);
                    target.setAlpha(0.55f);
                }
            }
            if (metadataNowAvailable) notifyMetadata(item);
        });
    }

    private Bitmap fetchImage(Item item) throws Exception {
        HttpURLConnection con = open(item, "image/avif,image/webp,image/apng,image/*,*/*;q=0.8", "image", 16000);
        try {
            int code = con.getResponseCode();
            String contentType = con.getContentType();
            long contentLength = con.getContentLengthLong();
            DiagLog.write(appContext, "THUMB_HTTP code=" + code + " type=" + contentType
                    + " length=" + contentLength + " finalUrl=" + con.getURL()
                    + " ref=" + item.referrer + " cookie=" + item.cookie.length());
            if (code < 200 || code >= 400) throw new IllegalStateException("HTTP " + code);
            if (contentType != null && !contentType.toLowerCase().startsWith("image/")) {
                throw new IllegalStateException("unexpected content-type " + contentType);
            }
            if (contentLength > MAX_THUMB_BYTES) {
                throw new IllegalStateException("thumbnail source too large: " + contentLength);
            }

            byte[] data;
            try (InputStream in = con.getInputStream(); ByteArrayOutputStream out = new ByteArrayOutputStream()) {
                byte[] buf = new byte[32 * 1024];
                int total = 0;
                int n;
                while ((n = in.read(buf)) >= 0) {
                    checkInterrupted();
                    total += n;
                    if (total > MAX_THUMB_BYTES) throw new IllegalStateException("thumbnail source too large");
                    out.write(buf, 0, n);
                }
                data = out.toByteArray();
            }

            checkInterrupted();
            BitmapFactory.Options bounds = new BitmapFactory.Options();
            bounds.inJustDecodeBounds = true;
            BitmapFactory.decodeByteArray(data, 0, data.length, bounds);
            if (bounds.outWidth <= 0 || bounds.outHeight <= 0) {
                throw new IllegalStateException("decode bounds failed bytes=" + data.length);
            }
            item.width = bounds.outWidth;
            item.height = bounds.outHeight;

            BitmapFactory.Options opts = new BitmapFactory.Options();
            opts.inPreferredConfig = Bitmap.Config.RGB_565;
            opts.inSampleSize = calculateSample(bounds.outWidth, bounds.outHeight, THUMB_MAX_EDGE, THUMB_MAX_EDGE);
            Bitmap decoded = BitmapFactory.decodeByteArray(data, 0, data.length, opts);
            if (decoded == null) throw new IllegalStateException("bitmap decode failed bytes=" + data.length);
            Bitmap result = scaleToMaxEdge(decoded, THUMB_MAX_EDGE);
            DiagLog.write(appContext, "THUMB_OK url=" + item.url + " source="
                    + bounds.outWidth + "x" + bounds.outHeight + " decoded="
                    + result.getWidth() + "x" + result.getHeight() + " bytes=" + data.length
                    + " sample=" + opts.inSampleSize);
            return result;
        } finally {
            con.disconnect();
        }
    }

    private Bitmap fetchVideoFrame(Item item) throws Exception {
        File temp = File.createTempFile("nstandard_video_thumb_", ".mp4", appContext.getCacheDir());
        HttpURLConnection con = null;
        try {
            con = open(item, "video/mp4,video/*,*/*;q=0.8", "video", 20000);
            int code = con.getResponseCode();
            String contentType = con.getContentType();
            long contentLength = con.getContentLengthLong();
            DiagLog.write(appContext, "VIDEO_THUMB_HTTP code=" + code + " type=" + contentType
                    + " length=" + contentLength + " finalUrl=" + con.getURL()
                    + " ref=" + item.referrer + " cookie=" + item.cookie.length());
            if (code < 200 || code >= 400) throw new IllegalStateException("HTTP " + code);
            if (contentLength > MAX_VIDEO_THUMB_BYTES) {
                throw new IllegalStateException("video thumbnail source too large: " + contentLength);
            }

            long total = 0L;
            try (InputStream in = con.getInputStream(); FileOutputStream out = new FileOutputStream(temp)) {
                byte[] buf = new byte[64 * 1024];
                int n;
                while ((n = in.read(buf)) >= 0) {
                    checkInterrupted();
                    total += n;
                    if (total > MAX_VIDEO_THUMB_BYTES) {
                        throw new IllegalStateException("video thumbnail source too large");
                    }
                    out.write(buf, 0, n);
                }
            }
            checkInterrupted();

            MediaMetadataRetriever retriever = new MediaMetadataRetriever();
            try {
                retriever.setDataSource(temp.getAbsolutePath());
                long duration = parseLong(retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION));
                int width = parseInt(retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH));
                int height = parseInt(retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT));
                int rotation = parseInt(retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION));
                if (rotation == 90 || rotation == 270) {
                    int t = width;
                    width = height;
                    height = t;
                }
                if (duration > 0L) item.durationMs = duration;
                if (width > 0 && height > 0) {
                    item.width = width;
                    item.height = height;
                }

                long frameUs = duration > 1500L ? 1_000_000L : 0L;
                Bitmap frame = retriever.getFrameAtTime(frameUs, MediaMetadataRetriever.OPTION_CLOSEST_SYNC);
                if (frame == null) frame = retriever.getFrameAtTime(0L, MediaMetadataRetriever.OPTION_CLOSEST_SYNC);
                if (frame == null) throw new IllegalStateException("video frame unavailable");
                Bitmap result = scaleToMaxEdge(frame, THUMB_MAX_EDGE);
                DiagLog.write(appContext, "VIDEO_THUMB_OK source=local_http url=" + item.url
                        + " source=" + item.width + "x" + item.height
                        + " decoded=" + result.getWidth() + "x" + result.getHeight()
                        + " durationMs=" + item.durationMs + " bytes=" + total);
                return result;
            } finally {
                retriever.release();
            }
        } finally {
            if (con != null) con.disconnect();
            if (temp.exists() && !temp.delete()) {
                DiagLog.write(appContext, "VIDEO_THUMB_TEMP_DELETE_FAIL path=" + temp.getName());
            }
        }
    }

    private HttpURLConnection open(Item item, String accept, String fetchDest, int readTimeout) throws Exception {
        HttpURLConnection con = (HttpURLConnection) new URL(item.url).openConnection();
        con.setInstanceFollowRedirects(true);
        con.setConnectTimeout(12000);
        con.setReadTimeout(readTimeout);
        con.setRequestProperty("User-Agent", userAgent);
        con.setRequestProperty("Accept", accept);
        con.setRequestProperty("Accept-Encoding", "identity");
        con.setRequestProperty("Sec-Fetch-Dest", fetchDest);
        con.setRequestProperty("Sec-Fetch-Mode", "no-cors");
        if (!item.referrer.isEmpty()) con.setRequestProperty("Referer", item.referrer);
        if (!item.cookie.isEmpty()) con.setRequestProperty("Cookie", item.cookie);
        con.connect();
        return con;
    }

    private void notifyMetadata(Item item) {
        if (metadataListener != null) metadataListener.onMetadataChanged(item);
    }

    private static boolean valid(Item item) {
        return item != null && item.url != null && !item.url.trim().isEmpty();
    }

    private static String cacheKey(Item item) {
        return item.kind.name() + "|" + item.url;
    }

    private static boolean usable(Bitmap bitmap) {
        return bitmap != null && !bitmap.isRecycled();
    }

    private static boolean addWaiter(Pending pending, ImageView view) {
        for (WeakReference<ImageView> ref : pending.waiters) {
            if (ref.get() == view) return false;
        }
        pending.waiters.add(new WeakReference<>(view));
        return true;
    }

    private static void checkInterrupted() throws InterruptedException {
        if (Thread.currentThread().isInterrupted()) throw new InterruptedException("thumbnail cancelled");
    }

    private static int calculateSample(int srcW, int srcH, int reqW, int reqH) {
        int sample = 1;
        if (srcH > reqH || srcW > reqW) {
            int halfH = srcH / 2;
            int halfW = srcW / 2;
            while ((halfH / sample) >= reqH && (halfW / sample) >= reqW) sample *= 2;
        }
        return Math.max(1, sample);
    }

    private static Bitmap scaleToMaxEdge(Bitmap source, int maxEdge) {
        if (source == null) return null;
        int w = source.getWidth();
        int h = source.getHeight();
        int longest = Math.max(w, h);
        if (longest <= maxEdge) return source;
        float scale = maxEdge / (float) longest;
        int outW = Math.max(1, Math.round(w * scale));
        int outH = Math.max(1, Math.round(h * scale));
        Bitmap scaled = Bitmap.createScaledBitmap(source, outW, outH, true);
        if (scaled != source && !source.isRecycled()) source.recycle();
        return scaled;
    }

    private static int parseInt(String value) {
        try {
            return value == null ? 0 : Integer.parseInt(value);
        } catch (Exception ignored) {
            return 0;
        }
    }

    private static long parseLong(String value) {
        try {
            return value == null ? 0L : Long.parseLong(value);
        } catch (Exception ignored) {
            return 0L;
        }
    }
}
