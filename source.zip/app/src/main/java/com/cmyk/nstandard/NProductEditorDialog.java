package com.cmyk.nstandard;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.text.Editable;
import android.text.InputType;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

/**
 * Price Rec. "商品編集" dialog reference for N Standard.
 * Data persistence is intentionally demo-only; visible layout and interactions
 * follow Price Rec.'s editor so this can be used as a UI/behavior sample.
 */
public final class NProductEditorDialog {
    private static final int BG = Color.parseColor("#303030");
    private static final int DGRAY = Color.parseColor("#252020");
    private static final int GRAY = Color.parseColor("#454040");
    private static final int LGRAY = Color.parseColor("#656060");
    private static final int BLUE = Color.parseColor("#223355");
    private static final int RED = Color.parseColor("#441100");
    private static final int ORANGE = Color.parseColor("#775500");
    private static final int WHITE = Color.WHITE;
    private static final int SECONDARY = Color.parseColor("#A9A999");

    private static final int DIALOG_MARGIN = 14;
    private static final int SPACING = 8;
    private static final int TIGHT_SPACING = 4;
    private static final int ACTION_GAP = 5;
    private static final int ACTION_SPACING = 18;
    private static final int ACTION_BOTTOM = 18;

    private NProductEditorDialog() {}

    public static final class EditorData {
        public String storeName = "店舗名";
        public final ArrayList<String> stores = new ArrayList<>(Arrays.asList("店舗名", "店舗 02", "店舗 03"));
        public String name = "商品名";
        public int price = 500;
        public int volume = 350;
        public String productKey = "prd.商品名.350";
        public String priceType = "税込";
        public final LinkedHashSet<String> tags = new LinkedHashSet<>();
        public final ArrayList<String> availableTags = new ArrayList<>(Arrays.asList("ビール", "ウイスキー", "ジン", "ワイン"));
        public boolean referenceAvailable = false;
    }

    public static void show(Activity activity, EditorData data, Runnable afterSave, Runnable afterDelete) {
        if (activity == null || data == null) return;

        LinearLayout panel = new LinearLayout(activity);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(activity, DIALOG_MARGIN), dp(activity, SPACING),
                dp(activity, DIALOG_MARGIN), dp(activity, ACTION_BOTTOM));

        LinearLayout form = new LinearLayout(activity);
        form.setOrientation(LinearLayout.VERTICAL);
        panel.addView(form, new LinearLayout.LayoutParams(-1, -2));

        TextView storeButton = button(activity, data.storeName, DGRAY, 14);
        storeButton.setOnClickListener(v -> showStoreChoice(activity, data, storeButton));
        LinearLayout.LayoutParams storeLp = new LinearLayout.LayoutParams(-1, dp(activity, 44));
        storeLp.bottomMargin = dp(activity, SPACING);
        form.addView(storeButton, storeLp);

        EditText name = input(activity, "商品名");
        name.setText(data.name == null ? "" : data.name);
        addField(activity, form, "商品名", name);

        EditText price = input(activity, "価格");
        price.setInputType(InputType.TYPE_CLASS_NUMBER);
        price.setText(data.price <= 0 ? "" : String.valueOf(data.price));
        addField(activity, form, "価格（円）", price);

        EditText volume = input(activity, "容量");
        volume.setInputType(InputType.TYPE_CLASS_NUMBER);
        volume.setText(data.volume <= 0 ? "" : String.valueOf(data.volume));
        addField(activity, form, "容量", volume);

        EditText productKey = input(activity, "product_key");
        productKey.setText(data.productKey == null ? "" : data.productKey);
        addField(activity, form, "product_key", productKey);

        final String[] selectedPriceType = {normalizePriceType(data.priceType)};
        TextView priceType = button(activity, selectedPriceType[0], DGRAY, 14);
        priceType.setOnClickListener(v -> showPriceTypeChoice(activity, selectedPriceType, priceType));
        addControl(activity, form, "価格種別", priceType);

        View tagArea = makeTagSelectionArea(activity, data);
        addWrapControl(activity, form, "タグ", tagArea);

        LinearLayout actions = new LinearLayout(activity);
        actions.setGravity(Gravity.CENTER_VERTICAL);

        TextView deleteButton = button(activity, "削除", RED, 13);
        TextView referenceButton = button(activity, "参照画像", ORANGE, 13);
        TextView cancelButton = button(activity, "キャンセル", DGRAY, 13);
        TextView saveButton = button(activity, "保存", BLUE, 13);

        actions.addView(deleteButton, new LinearLayout.LayoutParams(0, dp(activity, 38), 1f));
        LinearLayout.LayoutParams a2 = new LinearLayout.LayoutParams(0, dp(activity, 38), 1f);
        a2.leftMargin = dp(activity, ACTION_GAP); actions.addView(referenceButton, a2);
        LinearLayout.LayoutParams a3 = new LinearLayout.LayoutParams(0, dp(activity, 38), 1f);
        a3.leftMargin = dp(activity, ACTION_GAP); actions.addView(cancelButton, a3);
        LinearLayout.LayoutParams a4 = new LinearLayout.LayoutParams(0, dp(activity, 38), 1f);
        a4.leftMargin = dp(activity, ACTION_GAP); actions.addView(saveButton, a4);

        LinearLayout.LayoutParams actionRowLp = new LinearLayout.LayoutParams(-1, dp(activity, 38));
        actionRowLp.topMargin = dp(activity, ACTION_SPACING);
        panel.addView(actions, actionRowLp);

        ScrollView scroll = new ScrollView(activity);
        scroll.setFillViewport(false);
        scroll.setVerticalFadingEdgeEnabled(true);
        scroll.setFadingEdgeLength(dp(activity, 24));
        scroll.addView(panel, new ScrollView.LayoutParams(-1, -2));

        AlertDialog dialog = new AlertDialog.Builder(activity)
                .setTitle("ダイアログ")
                .setView(scroll)
                .create();

        deleteButton.setOnClickListener(v -> {
            AlertDialog confirm = new AlertDialog.Builder(activity)
                    .setTitle("商品削除")
                    .setMessage("「" + safe(data.name) + "」を削除しますか？\n元画像は削除されません。")
                    .setNegativeButton("キャンセル", null)
                    .setPositiveButton("削除", (dd, which) -> {
                        dialog.dismiss();
                        if (afterDelete != null) afterDelete.run();
                    })
                    .create();
            showRounded(activity, confirm, false);
        });

        referenceButton.setOnClickListener(v -> {
            if (data.referenceAvailable) {
                Toast.makeText(activity, "参照画像を開く見本", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(activity, "参照画像がありません", Toast.LENGTH_SHORT).show();
            }
        });
        cancelButton.setOnClickListener(v -> dialog.dismiss());
        saveButton.setOnClickListener(v -> {
            String n = name.getText().toString().trim();
            if (n.isEmpty()) {
                name.setError("商品名を入力");
                name.requestFocus();
                return;
            }
            int priceValue = 0;
            int volumeValue = 0;
            try { priceValue = Integer.parseInt(price.getText().toString().trim()); } catch (Exception ignored) { }
            try { volumeValue = Integer.parseInt(volume.getText().toString().trim()); } catch (Exception ignored) { }
            data.name = n;
            data.price = priceValue;
            data.volume = volumeValue;
            data.productKey = productKey.getText().toString().trim();
            data.priceType = selectedPriceType[0];
            data.storeName = storeButton.getText().toString();
            dialog.dismiss();
            if (afterSave != null) afterSave.run();
        });

        showRounded(activity, dialog, true);
    }

    private static View makeTagSelectionArea(Activity activity, EditorData data) {
        LinearLayout host = new LinearLayout(activity);
        host.setGravity(Gravity.BOTTOM);
        host.setMinimumHeight(dp(activity, 34));
        final Runnable[] render = new Runnable[1];
        render[0] = () -> {
            host.removeAllViews();

            HorizontalScrollView hsv = new HorizontalScrollView(activity);
            hsv.setHorizontalScrollBarEnabled(false);
            hsv.setFillViewport(false);
            LinearLayout row = new LinearLayout(activity);
            row.setGravity(Gravity.CENTER_VERTICAL);
            for (String tag : new ArrayList<>(data.availableTags)) {
                boolean selected = data.tags.contains(tag);
                TextView tagChip = chip(activity, tag, selected, false);
                tagChip.setOnClickListener(v -> {
                    if (!data.tags.add(tag)) data.tags.remove(tag);
                    render[0].run();
                });
                tagChip.setOnLongClickListener(v -> {
                    v.performHapticFeedback(android.view.HapticFeedbackConstants.LONG_PRESS);
                    showRenameTagDialog(activity, data, tag, renamed -> render[0].run());
                    return true;
                });
                row.addView(tagChip);
            }
            TextView none = chip(activity, "タグなし", data.tags.isEmpty(), true);
            none.setOnClickListener(v -> {
                data.tags.clear();
                render[0].run();
            });
            row.addView(none);
            hsv.addView(row);
            host.addView(hsv, new LinearLayout.LayoutParams(0, -2, 1f));

            // PriceRec common tag selector: orange circular + opens the real tag-selection/add flow.
            NPlusView plus = new NPlusView(activity, ORANGE, WHITE, 1f);
            plus.setContentDescription("タグ選択");
            plus.setOnClickListener(v -> showTagAddDialog(activity, data, render[0]));
            LinearLayout.LayoutParams plusLp = new LinearLayout.LayoutParams(dp(activity, 34), dp(activity, 34));
            plusLp.leftMargin = dp(activity, 8);
            host.addView(plus, plusLp);
        };
        render[0].run();
        return host;
    }

    /**
     * Demo-data transplant of PriceRec v0.1.81 showTagAddDialog().
     * Add/rename/delete mutate the sample tag catalog immediately; OK applies the pending
     * product-tag selection, while Cancel leaves the product's selection unchanged.
     */
    private static void showTagAddDialog(Activity activity, EditorData data, Runnable afterClose) {
        LinearLayout panel = new LinearLayout(activity);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(activity, DIALOG_MARGIN), dp(activity, SPACING),
                dp(activity, DIALOG_MARGIN), dp(activity, ACTION_BOTTOM));

        LinearLayout rows = new LinearLayout(activity);
        rows.setOrientation(LinearLayout.VERTICAL);
        ScrollView tagListScroll = new ScrollView(activity);
        tagListScroll.setFillViewport(false);
        tagListScroll.setVerticalFadingEdgeEnabled(true);
        tagListScroll.setFadingEdgeLength(dp(activity, 24));
        tagListScroll.addView(rows, new ScrollView.LayoutParams(-1, -2));
        panel.addView(tagListScroll, new LinearLayout.LayoutParams(-1, -2));

        LinearLayout addRow = new LinearLayout(activity);
        addRow.setGravity(Gravity.BOTTOM);
        addRow.setPadding(0, dp(activity, SPACING), 0, 0);
        EditText newTag = input(activity, "新しいタグ");
        LinearLayout.LayoutParams inputLp = new LinearLayout.LayoutParams(0, dp(activity, 48), 1f);
        inputLp.rightMargin = dp(activity, SPACING);
        addRow.addView(newTag, inputLp);

        FrameLayout addSlot = new FrameLayout(activity);
        addRow.addView(addSlot, new LinearLayout.LayoutParams(dp(activity, 56), dp(activity, 48)));
        NPlusView add = new NPlusView(activity, DGRAY, LGRAY, 1f);
        add.setContentDescription("タグ作成");
        FrameLayout.LayoutParams addLp = new FrameLayout.LayoutParams(dp(activity, 48), dp(activity, 48), Gravity.END | Gravity.BOTTOM);
        addLp.rightMargin = dp(activity, 4);
        addSlot.addView(add, addLp);
        panel.addView(addRow, new LinearLayout.LayoutParams(-1, -2));

        LinearLayout footer = new LinearLayout(activity);
        footer.setGravity(Gravity.CENTER_VERTICAL);
        TextView deleteAction = button(activity, "削除", DGRAY, 13);
        TextView cancelAction = button(activity, "キャンセル", DGRAY, 13);
        TextView okAction = button(activity, "OK", BLUE, 13);
        footer.addView(deleteAction, new LinearLayout.LayoutParams(dp(activity, 118), dp(activity, 38)));
        footer.addView(new View(activity), new LinearLayout.LayoutParams(0, dp(activity, 38), 1f));
        LinearLayout.LayoutParams cancelLp = new LinearLayout.LayoutParams(dp(activity, 118), dp(activity, 38));
        cancelLp.rightMargin = dp(activity, ACTION_GAP);
        footer.addView(cancelAction, cancelLp);
        footer.addView(okAction, new LinearLayout.LayoutParams(dp(activity, 118), dp(activity, 38)));
        LinearLayout.LayoutParams footerLp = new LinearLayout.LayoutParams(-1, dp(activity, 48));
        footerLp.topMargin = dp(activity, SPACING);
        panel.addView(footer, footerLp);

        AlertDialog dialog = new AlertDialog.Builder(activity)
                .setTitle("タグ選択")
                .setView(panel)
                .create();

        LinkedHashSet<String> pending = new LinkedHashSet<>(data.tags);
        pending.retainAll(data.availableTags);
        final Runnable[] renderRows = new Runnable[1];
        renderRows[0] = () -> {
            rows.removeAllViews();
            for (String tag : new ArrayList<>(data.availableTags)) {
                boolean selected = pending.contains(tag);
                LinearLayout row = new LinearLayout(activity);
                row.setGravity(Gravity.CENTER_VERTICAL);
                row.setPadding(0, dp(activity, 1), 0, dp(activity, 1));
                row.setBackground(round(activity, selected ? BLUE : DGRAY, 7));

                TextView name = text(activity, tag, 13, WHITE, selected);
                name.setIncludeFontPadding(false);
                name.setGravity(Gravity.CENTER_VERTICAL);
                name.setPadding(dp(activity, 12), 0, dp(activity, 12), 0);
                row.addView(name, new LinearLayout.LayoutParams(0, dp(activity, 38), 1f));

                LinearLayout.LayoutParams rowLp = new LinearLayout.LayoutParams(-1, -2);
                rowLp.bottomMargin = dp(activity, TIGHT_SPACING);
                rows.addView(row, rowLp);

                row.setOnClickListener(v -> {
                    if (!pending.add(tag)) pending.remove(tag);
                    renderRows[0].run();
                });
                row.setOnLongClickListener(v -> {
                    v.performHapticFeedback(android.view.HapticFeedbackConstants.LONG_PRESS);
                    final boolean wasSelected = pending.contains(tag);
                    showRenameTagDialog(activity, data, tag, renamed -> {
                        pending.remove(tag);
                        if (wasSelected && renamed != null) pending.add(renamed);
                        pending.retainAll(data.availableTags);
                        renderRows[0].run();
                    });
                    return true;
                });
            }
            boolean selecting = !pending.isEmpty();
            deleteAction.setEnabled(selecting);
            deleteAction.setClickable(selecting);
            deleteAction.setTextColor(selecting ? WHITE : LGRAY);
            deleteAction.setBackground(round(activity, selecting ? RED : DGRAY, 18));
            deleteAction.setAlpha(selecting ? 1f : .72f);
        };

        add.setOnClickListener(v -> {
            String name = newTag.getText().toString().trim();
            if (name.isEmpty()) {
                newTag.setError("タグ名を入力");
                newTag.requestFocus();
                return;
            }
            if (containsTag(data.availableTags, name, null)) {
                newTag.setError("同じ名前のタグがあります");
                newTag.requestFocus();
                return;
            }
            data.availableTags.add(name);
            newTag.setText("");
            renderRows[0].run();
        });

        deleteAction.setOnClickListener(v -> {
            if (pending.isEmpty()) return;
            int count = pending.size();
            AlertDialog confirm = new AlertDialog.Builder(activity)
                    .setTitle("タグ削除")
                    .setMessage("選択した" + count + "件のタグを削除します。画像や商品自体は削除されません。")
                    .setNegativeButton("キャンセル", null)
                    .setPositiveButton("削除", (d, which) -> {
                        ArrayList<String> removing = new ArrayList<>(pending);
                        data.availableTags.removeAll(removing);
                        data.tags.removeAll(removing);
                        pending.clear();
                        renderRows[0].run();
                    })
                    .create();
            showRounded(activity, confirm, false);
        });

        cancelAction.setOnClickListener(v -> dialog.cancel());
        okAction.setOnClickListener(v -> {
            data.tags.clear();
            data.tags.addAll(pending);
            dialog.dismiss();
        });
        dialog.setOnDismissListener(d -> {
            data.tags.retainAll(data.availableTags);
            if (afterClose != null) afterClose.run();
        });

        newTag.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) { }
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) {
                // PriceRec dims the + until there is text. NPlusView is intentionally shared;
                // alpha conveys that state without creating an app-specific plus drawable.
                boolean enabled = s != null && !s.toString().trim().isEmpty();
                add.setAlpha(enabled ? 1f : .62f);
            }
            @Override public void afterTextChanged(Editable s) { }
        });
        add.setAlpha(.62f);

        renderRows[0].run();
        showRounded(activity, dialog, true);
        Window w = dialog.getWindow();
        if (w != null) w.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
    }

    private interface TagRenameListener { void onRenamed(String newName); }

    private static void showRenameTagDialog(Activity activity, EditorData data, String oldName, TagRenameListener afterRename) {
        EditText input = input(activity, "タグ名");
        input.setText(oldName);
        input.setSelectAllOnFocus(true);
        LinearLayout holder = new LinearLayout(activity);
        holder.setPadding(dp(activity, DIALOG_MARGIN), dp(activity, SPACING),
                dp(activity, DIALOG_MARGIN), dp(activity, SPACING));
        holder.addView(input, new LinearLayout.LayoutParams(-1, dp(activity, 48)));

        AlertDialog dialog = new AlertDialog.Builder(activity)
                .setTitle("タグ名変更")
                .setView(holder)
                .setNegativeButton("キャンセル", null)
                .setPositiveButton("保存", null)
                .create();
        dialog.setOnShowListener(d -> dialog.getButton(DialogInterface.BUTTON_POSITIVE).setOnClickListener(v -> {
            String name = input.getText().toString().trim();
            if (name.isEmpty()) {
                input.setError("タグ名を入力");
                return;
            }
            if (containsTag(data.availableTags, name, oldName)) {
                input.setError("同じ名前のタグがあります");
                return;
            }
            int index = data.availableTags.indexOf(oldName);
            if (index >= 0) data.availableTags.set(index, name);
            if (data.tags.remove(oldName)) data.tags.add(name);
            dialog.dismiss();
            if (afterRename != null) afterRename.onRenamed(name);
        }));
        showRounded(activity, dialog, false);
    }

    private static boolean containsTag(List<String> tags, String candidate, String except) {
        for (String tag : tags) {
            if (except != null && tag.equals(except)) continue;
            if (tag.equalsIgnoreCase(candidate)) return true;
        }
        return false;
    }

    private static void showStoreChoice(Activity activity, EditorData data, TextView button) {
        if (data.stores.isEmpty()) return;
        String[] names = data.stores.toArray(new String[0]);
        AlertDialog d = new AlertDialog.Builder(activity)
                .setTitle("店舗を選択")
                .setItems(names, (dialog, which) -> {
                    data.storeName = names[which];
                    button.setText(names[which]);
                })
                .setNegativeButton("キャンセル", null)
                .create();
        showRounded(activity, d, false);
    }

    private static void showPriceTypeChoice(Activity activity, String[] selected, TextView button) {
        String[] values = {"税抜", "税込", "不明"};
        int checked = "税抜".equals(selected[0]) ? 0 : ("税込".equals(selected[0]) ? 1 : 2);
        AlertDialog d = new AlertDialog.Builder(activity)
                .setTitle("価格種別")
                .setSingleChoiceItems(values, checked, (dialog, which) -> {
                    selected[0] = values[which];
                    button.setText(values[which]);
                    dialog.dismiss();
                })
                .setNegativeButton("キャンセル", null)
                .create();
        showRounded(activity, d, false);
    }

    private static void addField(Activity a, LinearLayout panel, String label, EditText input) {
        addControl(a, panel, label, input);
    }

    private static void addControl(Activity a, LinearLayout panel, String label, View control) {
        TextView l = text(a, label, 12, SECONDARY, false);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, dp(a, 24));
        lp.topMargin = dp(a, TIGHT_SPACING);
        panel.addView(l, lp);
        panel.addView(control, new LinearLayout.LayoutParams(-1, dp(a, 46)));
    }

    private static void addWrapControl(Activity a, LinearLayout panel, String label, View control) {
        TextView l = text(a, label, 12, SECONDARY, false);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, dp(a, 24));
        lp.topMargin = dp(a, TIGHT_SPACING);
        panel.addView(l, lp);
        control.setMinimumHeight(dp(a, 46));
        panel.addView(control, new LinearLayout.LayoutParams(-1, -2));
    }

    private static EditText input(Activity a, String hint) {
        EditText e = new EditText(a);
        e.setHint(hint);
        e.setHintTextColor(LGRAY);
        e.setTextColor(WHITE);
        e.setTextSize(15);
        e.setSingleLine(true);
        e.setPadding(dp(a, 12), 0, dp(a, 12), 0);
        e.setBackground(round(a, DGRAY, 14));
        return e;
    }

    private static TextView button(Activity a, String label, int bg, int sp) {
        TextView t = text(a, label, sp, WHITE, true);
        t.setGravity(Gravity.CENTER);
        t.setBackground(round(a, bg, 18));
        t.setClickable(true);
        t.setFocusable(true);
        return t;
    }

    private static TextView chip(Activity a, String label, boolean selected, boolean none) {
        TextView t = text(a, label, 12, selected ? WHITE : SECONDARY, selected);
        t.setGravity(Gravity.CENTER);
        t.setPadding(dp(a, 12), 0, dp(a, 12), 0);
        t.setBackground(round(a, selected ? BLUE : (none ? DGRAY : GRAY), 16));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, dp(a, 34));
        lp.rightMargin = dp(a, 6);
        t.setLayoutParams(lp);
        return t;
    }

    private static TextView text(Activity a, String s, int sp, int color, boolean bold) {
        TextView t = new TextView(a);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(color);
        t.setGravity(Gravity.CENTER_VERTICAL);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }

    private static GradientDrawable round(Activity a, int color, float radiusDp) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(a, radiusDp));
        return g;
    }

    private static void showRounded(Activity a, AlertDialog dialog, boolean wide) {
        Window pre = dialog.getWindow();
        if (pre != null) pre.setBackgroundDrawable(round(a, GRAY, 20));
        N.showDialogStable(a, dialog, wide ? 0.94f : 0.90f);
        Window w = dialog.getWindow();
        if (w != null) w.setBackgroundDrawable(round(a, GRAY, 20));
    }

    private static String normalizePriceType(String s) {
        if (s == null) return "不明";
        if (s.contains("税抜") || s.contains("税別")) return "税抜";
        if (s.contains("税込")) return "税込";
        return "不明";
    }

    private static String safe(String s) { return s == null ? "" : s; }
    private static int dp(Activity a, float v) { return Math.round(v * a.getResources().getDisplayMetrics().density); }
}
