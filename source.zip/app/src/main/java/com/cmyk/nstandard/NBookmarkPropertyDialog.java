package com.cmyk.nstandard;

import android.app.Activity;
import android.app.Dialog;
import android.graphics.drawable.GradientDrawable;
import android.text.InputType;
import android.view.Gravity;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Space;
import android.widget.TextView;
import android.widget.Toast;

import java.text.DateFormat;
import java.util.Date;

/**
 * BookmarkLauncher のブックマーク詳細ダイアログを直接基準にした見本。
 * N Standard 版ではスクリーンショット／サムネイル欄だけを除外する。
 */
public final class NBookmarkPropertyDialog {
    private static final int GRAY = 0xFF454040;
    private static final int L_BLUE = 0xFF445577;
    private static final int L_RED = 0xFF662211;
    private static final int TEXT = 0xFFFFFFFF;
    private static final int ICON = 0xFFA9A999;

    private NBookmarkPropertyDialog() {}

    public static void show(Activity activity) {
        Dialog dialog = baseDialog(activity);
        LinearLayout root = root(activity);

        TextView header = editableTitle(activity, "サンプルブックマーク");
        header.setOnClickListener(v -> showInput(activity, "名前を編集", "表示名", header.getText().toString(), text -> {
            if (text.isBlank()) return;
            header.setText(text);
        }));
        root.addView(header, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(activity, 46)));

        // BookmarkLauncher 本体との差分はここだけ。サムネイル欄は生成しない。
        addField(activity, root, "サイト名", "example.com");
        addField(activity, root, "ページタイトル", "サンプルページ");
        addField(activity, root, "URL", "https://example.com/");

        DateFormat f = DateFormat.getDateTimeInstance(DateFormat.MEDIUM, DateFormat.SHORT);
        long now = System.currentTimeMillis();
        LinearLayout dates = new LinearLayout(activity);
        dates.setOrientation(LinearLayout.HORIZONTAL);
        dates.setGravity(Gravity.CENTER_VERTICAL);
        dates.addView(compactField(activity, "ブックマーク", f.format(new Date(now - 86400000L))),
                new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        dates.addView(compactField(activity, "最終アクセス", f.format(new Date(now))),
                new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        root.addView(dates, lpMatchWrap(activity, 6, 4, 0, 0));

        addField(activity, root, "オフラインビューイング", "未設定");

        LinearLayout bottom = bottomRow(activity);
        TextView delete = action(activity, "削除", L_RED);
        delete.setGravity(Gravity.CENTER);
        delete.setOnClickListener(v -> {
            dialog.dismiss();
            Toast.makeText(activity, "削除（見本）", Toast.LENGTH_SHORT).show();
        });
        bottom.addView(delete, new LinearLayout.LayoutParams(dp(activity, 84), dp(activity, 44)));

        Space leftGap = new Space(activity);
        bottom.addView(leftGap, new LinearLayout.LayoutParams(dp(activity, 8), 1));
        TextView copy = action(activity, "コピー", L_BLUE);
        copy.setGravity(Gravity.CENTER);
        copy.setOnClickListener(v -> {
            dialog.dismiss();
            Toast.makeText(activity, "コピー（見本）", Toast.LENGTH_SHORT).show();
        });
        bottom.addView(copy, new LinearLayout.LayoutParams(dp(activity, 92), dp(activity, 44)));

        addFlexibleSpacer(activity, bottom);
        TextView close = action(activity, "閉じる", GRAY);
        close.setGravity(Gravity.CENTER);
        close.setOnClickListener(v -> dialog.dismiss());
        bottom.addView(close, new LinearLayout.LayoutParams(dp(activity, 92), dp(activity, 44)));
        root.addView(bottom, lpMatchWrap(activity, 12, 0, 0, 0));

        dialog.setContentView(root);
        showDialog(activity, dialog);
    }

    private interface TextListener { void onText(String text); }

    private static void showInput(Activity activity, String title, String hint, String initial, TextListener listener) {
        Dialog dialog = baseDialog(activity);
        LinearLayout root = root(activity);
        addTitle(activity, root, title, Gravity.CENTER_VERTICAL);

        EditText input = new EditText(activity);
        input.setSingleLine(true);
        input.setText(initial == null ? "" : initial);
        input.setHint(hint);
        input.setTextColor(TEXT);
        input.setHintTextColor(ICON);
        input.setTextSize(16);
        input.setPadding(dp(activity, 14), 0, dp(activity, 14), 0);
        input.setBackground(roundRect(activity, GRAY, 12));
        input.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
        root.addView(input, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(activity, 52)));

        LinearLayout buttons = buttonRow(activity);
        TextView cancel = action(activity, "キャンセル", GRAY);
        cancel.setGravity(Gravity.CENTER);
        cancel.setOnClickListener(v -> dialog.dismiss());
        buttons.addView(cancel, new LinearLayout.LayoutParams(dp(activity, 112), dp(activity, 46)));

        Space gap = new Space(activity);
        buttons.addView(gap, new LinearLayout.LayoutParams(dp(activity, 8), 1));

        TextView save = action(activity, "保存", L_BLUE);
        save.setGravity(Gravity.CENTER);
        save.setOnClickListener(v -> {
            String text = input.getText().toString().trim();
            dialog.dismiss();
            listener.onText(text);
        });
        buttons.addView(save, new LinearLayout.LayoutParams(dp(activity, 96), dp(activity, 46)));
        root.addView(buttons, lpMatchWrap(activity, 14, 12, 0, 0));

        dialog.setContentView(root);
        dialog.setOnShowListener(d -> {
            input.requestFocus();
            Window w = dialog.getWindow();
            if (w != null) w.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_VISIBLE);
        });
        showDialog(activity, dialog);
    }

    private static android.view.View compactField(Activity activity, String label, String value) {
        LinearLayout box = new LinearLayout(activity);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(activity, 2), dp(activity, 2), dp(activity, 8), dp(activity, 4));
        TextView l = new TextView(activity);
        l.setText(label);
        l.setTextColor(ICON);
        l.setTextSize(12);
        box.addView(l, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        TextView v = new TextView(activity);
        v.setText(value);
        v.setTextColor(TEXT);
        v.setTextSize(13);
        v.setSingleLine(true);
        box.addView(v, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        return box;
    }

    private static TextView editableTitle(Activity activity, String title) {
        TextView tv = new TextView(activity);
        tv.setText(title);
        tv.setTextColor(TEXT);
        tv.setTextSize(20);
        tv.setGravity(Gravity.CENTER);
        tv.setSingleLine(true);
        tv.setClickable(true);
        return tv;
    }

    private static void addField(Activity activity, LinearLayout root, String label, String value) {
        TextView labelView = new TextView(activity);
        labelView.setText(label);
        labelView.setTextColor(ICON);
        labelView.setTextSize(12);
        root.addView(labelView, lpMatchWrap(activity, 4, 2, 2, 2));

        TextView valueView = new TextView(activity);
        valueView.setText(value);
        valueView.setTextColor(TEXT);
        valueView.setTextSize(15);
        valueView.setTextIsSelectable(true);
        valueView.setPadding(dp(activity, 2), 0, dp(activity, 2), dp(activity, 8));
        root.addView(valueView, lpMatchWrap(activity, 0, 4, 0, 0));
    }

    private static Dialog baseDialog(Activity activity) {
        Dialog dialog = new Dialog(activity);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setCancelable(true);
        dialog.setCanceledOnTouchOutside(true);
        return dialog;
    }

    private static LinearLayout root(Activity activity) {
        LinearLayout root = new LinearLayout(activity);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(activity, 18), dp(activity, 18), dp(activity, 18), dp(activity, 18));
        root.setBackground(roundRect(activity, GRAY, 18));
        return root;
    }

    private static void addTitle(Activity activity, LinearLayout root, String title, int gravity) {
        TextView tv = new TextView(activity);
        tv.setText(title);
        tv.setTextColor(TEXT);
        tv.setTextSize(20);
        tv.setGravity(gravity);
        root.addView(tv, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(activity, 46)));
    }

    private static TextView action(Activity activity, String text, int background) {
        TextView tv = new TextView(activity);
        tv.setText(text);
        tv.setTextColor(TEXT);
        tv.setTextSize(16);
        tv.setGravity(Gravity.CENTER_VERTICAL);
        tv.setPadding(dp(activity, 14), 0, dp(activity, 14), 0);
        int resolvedBackground = background == GRAY ? L_BLUE : background;
        tv.setBackground(roundRect(activity, resolvedBackground, 999));
        return tv;
    }

    private static LinearLayout buttonRow(Activity activity) {
        LinearLayout row = new LinearLayout(activity);
        row.setGravity(Gravity.END | Gravity.CENTER_VERTICAL);
        return row;
    }

    private static LinearLayout bottomRow(Activity activity) {
        LinearLayout row = new LinearLayout(activity);
        row.setGravity(Gravity.START | Gravity.CENTER_VERTICAL);
        row.setOrientation(LinearLayout.HORIZONTAL);
        return row;
    }

    private static void addFlexibleSpacer(Activity activity, LinearLayout row) {
        Space spacer = new Space(activity);
        row.addView(spacer, new LinearLayout.LayoutParams(0, 1, 1f));
    }

    private static void showDialog(Activity activity, Dialog dialog) {
        dialog.show();
        Window w = dialog.getWindow();
        if (w != null) {
            w.setBackgroundDrawableResource(android.R.color.transparent);
            WindowManager.LayoutParams p = new WindowManager.LayoutParams();
            p.copyFrom(w.getAttributes());
            p.width = activity.getResources().getDisplayMetrics().widthPixels - dp(activity, 36);
            p.height = WindowManager.LayoutParams.WRAP_CONTENT;
            p.gravity = Gravity.CENTER;
            w.setAttributes(p);
        }
    }

    private static GradientDrawable roundRect(Activity activity, int color, int radiusDp) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(dp(activity, radiusDp));
        return d;
    }

    private static LinearLayout.LayoutParams lpMatchWrap(Activity activity, int top, int bottom, int left, int right) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.setMargins(dp(activity, left), dp(activity, top), dp(activity, right), dp(activity, bottom));
        return lp;
    }

    private static int dp(Activity activity, int value) {
        return Math.round(value * activity.getResources().getDisplayMetrics().density);
    }
}
