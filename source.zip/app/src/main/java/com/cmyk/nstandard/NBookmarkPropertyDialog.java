package com.cmyk.nstandard;

import android.app.Activity;
import android.app.Dialog;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Space;
import android.widget.TextView;
import android.widget.Toast;

import java.text.DateFormat;
import java.util.Date;

/**
 * BookmarkLauncher のブックマーク詳細ダイアログ見本。
 * N Standard ではスクリーンショット／サムネイル欄だけ除外している。
 */
public final class NBookmarkPropertyDialog {
    private static final int D_GRAY = 0xFF252020;
    private static final int GRAY = 0xFF454040;
    private static final int L_BLUE = 0xFF445577;
    private static final int L_RED = 0xFF662211;
    private static final int TEXT = 0xFFFFFFFF;
    private static final int ICON = 0xFFA9A999;

    private NBookmarkPropertyDialog() {}

    public static void show(Activity activity) {
        Dialog dialog = new Dialog(activity);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);

        ScrollView scroll = new ScrollView(activity);
        scroll.setFillViewport(false);
        LinearLayout root = new LinearLayout(activity);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(activity, 18), dp(activity, 16), dp(activity, 18), dp(activity, 16));
        root.setBackground(roundRect(activity, D_GRAY, 22));
        scroll.addView(root, new ScrollView.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        TextView header = editableTitle(activity, "サンプルブックマーク");
        header.setOnClickListener(v -> showNameEditor(activity, header));
        root.addView(header, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(activity, 46)));

        // BookmarkLauncher のスクリーンショット／サムネイル欄は意図的に移植しない。
        addField(activity, root, "サイト名", "example.com");
        addField(activity, root, "ページタイトル", "サンプルページ");
        addField(activity, root, "URL", "https://example.com/");

        DateFormat f = DateFormat.getDateTimeInstance(DateFormat.MEDIUM, DateFormat.SHORT);
        long now = System.currentTimeMillis();
        LinearLayout dates = new LinearLayout(activity);
        dates.setOrientation(LinearLayout.HORIZONTAL);
        dates.setGravity(Gravity.CENTER_VERTICAL);
        dates.addView(compactField(activity, "ブックマーク", f.format(new Date(now - 86400000L))),
                new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        dates.addView(compactField(activity, "最終アクセス", f.format(new Date(now))),
                new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        LinearLayout.LayoutParams datesLp = matchWrap();
        datesLp.setMargins(dp(activity, 6), dp(activity, 4), 0, 0);
        root.addView(dates, datesLp);

        addField(activity, root, "オフラインビューイング", "未設定");

        LinearLayout bottom = new LinearLayout(activity);
        bottom.setOrientation(LinearLayout.HORIZONTAL);
        bottom.setGravity(Gravity.CENTER_VERTICAL);

        TextView delete = action(activity, "削除", L_RED);
        delete.setGravity(Gravity.CENTER);
        delete.setOnClickListener(v -> {
            dialog.dismiss();
            Toast.makeText(activity, "削除（見本）", Toast.LENGTH_SHORT).show();
        });
        bottom.addView(delete, new LinearLayout.LayoutParams(dp(activity, 84), dp(activity, 44)));

        Space smallGap = new Space(activity);
        bottom.addView(smallGap, new LinearLayout.LayoutParams(dp(activity, 8), 1));

        TextView copy = action(activity, "コピー", L_BLUE);
        copy.setGravity(Gravity.CENTER);
        copy.setOnClickListener(v -> {
            dialog.dismiss();
            Toast.makeText(activity, "コピー（見本）", Toast.LENGTH_SHORT).show();
        });
        bottom.addView(copy, new LinearLayout.LayoutParams(dp(activity, 92), dp(activity, 44)));

        Space flex = new Space(activity);
        bottom.addView(flex, new LinearLayout.LayoutParams(0, 1, 1f));

        TextView close = action(activity, "閉じる", GRAY);
        close.setGravity(Gravity.CENTER);
        close.setOnClickListener(v -> dialog.dismiss());
        bottom.addView(close, new LinearLayout.LayoutParams(dp(activity, 92), dp(activity, 44)));

        LinearLayout.LayoutParams bottomLp = matchWrap();
        bottomLp.setMargins(dp(activity, 12), 0, 0, 0);
        root.addView(bottom, bottomLp);

        dialog.setContentView(scroll);
        showDialog(activity, dialog);
    }

    private static void showNameEditor(Activity activity, TextView header) {
        Dialog editor = new Dialog(activity);
        editor.requestWindowFeature(Window.FEATURE_NO_TITLE);

        LinearLayout root = new LinearLayout(activity);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(activity, 18), dp(activity, 16), dp(activity, 18), dp(activity, 16));
        root.setBackground(roundRect(activity, D_GRAY, 22));

        TextView title = new TextView(activity);
        title.setText("名前を編集");
        title.setTextColor(TEXT);
        title.setTextSize(18);
        title.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        title.setGravity(Gravity.CENTER_VERTICAL);
        root.addView(title, new LinearLayout.LayoutParams(-1, dp(activity, 46)));

        EditText input = new EditText(activity);
        input.setSingleLine(true);
        input.setText(header.getText());
        input.setHint("表示名");
        input.setTextColor(TEXT);
        input.setHintTextColor(ICON);
        input.setTextSize(16);
        input.setPadding(dp(activity, 14), 0, dp(activity, 14), 0);
        input.setBackground(roundRect(activity, GRAY, 12));
        input.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
        root.addView(input, new LinearLayout.LayoutParams(-1, dp(activity, 52)));

        LinearLayout buttons = new LinearLayout(activity);
        buttons.setOrientation(LinearLayout.HORIZONTAL);
        buttons.setGravity(Gravity.END | Gravity.CENTER_VERTICAL);
        LinearLayout.LayoutParams buttonsLp = matchWrap();
        buttonsLp.topMargin = dp(activity, 12);

        TextView cancel = action(activity, "キャンセル", GRAY);
        cancel.setGravity(Gravity.CENTER);
        cancel.setOnClickListener(v -> editor.dismiss());
        buttons.addView(cancel, new LinearLayout.LayoutParams(dp(activity, 112), dp(activity, 46)));

        Space gap = new Space(activity);
        buttons.addView(gap, new LinearLayout.LayoutParams(dp(activity, 8), 1));

        TextView save = action(activity, "保存", L_BLUE);
        save.setGravity(Gravity.CENTER);
        save.setOnClickListener(v -> {
            String text = input.getText().toString().trim();
            if (!text.isEmpty()) header.setText(text);
            editor.dismiss();
        });
        buttons.addView(save, new LinearLayout.LayoutParams(dp(activity, 112), dp(activity, 46)));
        root.addView(buttons, buttonsLp);

        editor.setContentView(root);
        showDialog(activity, editor);
    }

    private static TextView editableTitle(Activity activity, String text) {
        TextView t = new TextView(activity);
        t.setText(text);
        t.setTextColor(TEXT);
        t.setTextSize(20);
        t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        t.setGravity(Gravity.CENTER_VERTICAL);
        t.setPadding(dp(activity, 4), 0, dp(activity, 4), 0);
        return t;
    }

    private static void addField(Activity activity, LinearLayout root, String label, String value) {
        root.addView(compactField(activity, label, value), fieldLp(activity));
    }

    private static LinearLayout compactField(Activity activity, String label, String value) {
        LinearLayout box = new LinearLayout(activity);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(activity, 10), dp(activity, 7), dp(activity, 10), dp(activity, 7));
        box.setBackground(roundRect(activity, GRAY, 12));

        TextView l = new TextView(activity);
        l.setText(label);
        l.setTextColor(ICON);
        l.setTextSize(11);
        box.addView(l, new LinearLayout.LayoutParams(-1, -2));

        TextView v = new TextView(activity);
        v.setText(value);
        v.setTextColor(TEXT);
        v.setTextSize(14);
        v.setTextIsSelectable(true);
        LinearLayout.LayoutParams vlp = new LinearLayout.LayoutParams(-1, -2);
        vlp.topMargin = dp(activity, 2);
        box.addView(v, vlp);
        return box;
    }

    private static LinearLayout.LayoutParams fieldLp(Activity activity) {
        LinearLayout.LayoutParams lp = matchWrap();
        lp.setMargins(0, dp(activity, 6), 0, 0);
        return lp;
    }

    private static TextView action(Activity activity, String text, int bg) {
        TextView t = new TextView(activity);
        t.setText(text);
        t.setTextColor(TEXT);
        t.setTextSize(14);
        t.setGravity(Gravity.CENTER_VERTICAL);
        t.setBackground(roundRect(activity, bg, 14));
        t.setPadding(dp(activity, 12), 0, dp(activity, 12), 0);
        t.setClickable(true);
        t.setFocusable(true);
        return t;
    }

    private static LinearLayout.LayoutParams matchWrap() {
        return new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT);
    }

    private static GradientDrawable roundRect(Activity activity, int color, float radiusDp) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(activity, radiusDp));
        return g;
    }

    private static int dp(Activity activity, float value) {
        return Math.round(value * activity.getResources().getDisplayMetrics().density);
    }

    private static void showDialog(Activity activity, Dialog dialog) {
        dialog.setCanceledOnTouchOutside(true);
        dialog.show();
        Window w = dialog.getWindow();
        if (w == null) return;
        w.setBackgroundDrawableResource(android.R.color.transparent);
        WindowManager.LayoutParams p = new WindowManager.LayoutParams();
        p.copyFrom(w.getAttributes());
        p.width = Math.min(activity.getResources().getDisplayMetrics().widthPixels - dp(activity, 32), dp(activity, 560));
        p.height = WindowManager.LayoutParams.WRAP_CONTENT;
        w.setAttributes(p);
    }
}
