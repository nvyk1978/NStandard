package com.cmyk.nstandard;

import android.app.Activity;
import android.content.ClipData;
import android.content.Context;
import android.content.Intent;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

/**
 * Icon reference screen. Long-press starts selection mode; selected source definitions can
 * be exported as one ZIP for direct sharing to ChatGPT or another app.
 */
public class NIconSampleActivity extends Activity {
    private static final int CELL_GAP_DP = 10;

    private final List<SquareCell> iconCells = new ArrayList<>();
    private boolean selectionMode = false;
    private int selectedCount = 0;
    private TextView shareButton;

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        setContentView(buildUi());
    }

    private View buildUi() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(N.BG);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(N.dp(this, 25), N.dp(this, N.PAGE_TITLE_TOP_DP), N.dp(this, 25), N.dp(this, 24));
        scroll.addView(root, new ScrollView.LayoutParams(-1, -2));

        TextView title = text("アイコン見本", 25, N.WHITE, true);
        title.setGravity(Gravity.START | Gravity.CENTER_VERTICAL);
        root.addView(title, new LinearLayout.LayoutParams(-1, N.dp(this, 56)));

        TextView note = text("長押しで選択・共有", 12, N.WHITE, false);
        note.setAlpha(.78f);
        LinearLayout.LayoutParams noteLp = new LinearLayout.LayoutParams(-1, -2);
        noteLp.bottomMargin = N.dp(this, 14);
        root.addView(note, noteLp);

        List<IconSpec> specs = new ArrayList<>();
        specs.add(new IconSpec("三点リーダー", "more", "Chirami", IconView.MORE));
        specs.add(new IconSpec("診断ログ", "diagnostic", "ImgStalker", IconView.DIAGNOSTIC));
        specs.add(new IconSpec("設定／歯車", "settings", "ImgStalker", IconView.SETTINGS));
        specs.add(new IconSpec("タグ", "tag", "PriceRec", IconView.TAG));
        specs.add(new IconSpec("リスト／ドキュメント", "document", "PriceRec", IconView.DOCUMENT));
        specs.add(new IconSpec("＋", "bookmark_plus", "BookmarkLauncher", IconView.BOOKMARK_PLUS));
        specs.add(new IconSpec("回転", "rotate", "Chirami", IconView.ROTATE));
        specs.add(new IconSpec("チェック", "check", "Chirami", IconView.CHECK));
        specs.add(new IconSpec("緑チェック", "green_check", "N Standard", IconView.GREEN_CHECK));
        specs.add(new IconSpec("Bookmark ×", "bookmark_x", "BookmarkLauncher", IconView.BOOKMARK_X));
        specs.add(new IconSpec("Bookmark フォルダ", "bookmark_folder", "BookmarkLauncher", IconView.FOLDER));
        specs.add(new IconSpec("Twitter", "twitter", "ImgStalker", IconView.IMG_X));
        specs.add(new IconSpec("Instagram", "instagram", "ImgStalker", IconView.IMG_INSTAGRAM));

        for (int i = 0; i < specs.size(); i += 3) {
            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setGravity(Gravity.TOP);
            for (int c = 0; c < 3; c++) {
                int idx = i + c;
                SquareCell cell = idx < specs.size() ? iconCell(specs.get(idx)) : blankCell();
                row.addView(cell, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
                if (c < 2) row.addView(new View(this), new LinearLayout.LayoutParams(N.dp(this, CELL_GAP_DP), 1));
            }
            LinearLayout.LayoutParams rowLp = new LinearLayout.LayoutParams(-1, ViewGroup.LayoutParams.WRAP_CONTENT);
            if (i + 3 < specs.size()) rowLp.bottomMargin = N.dp(this, CELL_GAP_DP);
            root.addView(row, rowLp);
        }

        shareButton = capsule("共有", N.DGRAY, 15);
        shareButton.setOnClickListener(v -> shareSelectedIcons());
        LinearLayout.LayoutParams shareLp = new LinearLayout.LayoutParams(-1, N.dp(this, 46));
        shareLp.topMargin = N.dp(this, 14);
        root.addView(shareButton, shareLp);
        updateShareButton();

        TextView close = capsule("閉じる", N.GRAY, 15);
        close.setOnClickListener(v -> finish());
        LinearLayout.LayoutParams closeLp = new LinearLayout.LayoutParams(-1, N.dp(this, 46));
        closeLp.topMargin = N.dp(this, 10);
        root.addView(close, closeLp);
        return scroll;
    }

    private SquareCell iconCell(IconSpec spec) {
        SquareCell cell = new SquareCell(this, spec);
        cell.setBackground(N.round(N.DGRAY, 14, this));
        cell.setClickable(true);
        cell.setFocusable(true);

        View icon;
        if (spec.kind == IconView.BOOKMARK_PLUS) {
            icon = new NPlusView(this);
        } else if (spec.kind == IconView.BOOKMARK_X) {
            FrameLayout circle = new FrameLayout(this);
            circle.setBackground(oval(Color.BLACK));
            ImageView close = new ImageView(this);
            close.setImageResource(R.drawable.ic_bookmark_close_vector);
            close.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
            circle.addView(close, new FrameLayout.LayoutParams(N.dp(this, 22), N.dp(this, 22), Gravity.CENTER));
            icon = circle;
        } else {
            icon = new IconView(this, spec.kind);
        }

        // Icon is fixed at the geometric center of the square cell. Labels do not affect it.
        FrameLayout.LayoutParams iconLp = new FrameLayout.LayoutParams(N.dp(this, 48), N.dp(this, 48), Gravity.CENTER);
        cell.addView(icon, iconLp);

        TextView label = text(spec.label, 10, N.TEXT, false);
        label.setGravity(Gravity.CENTER);
        label.setMaxLines(2);
        FrameLayout.LayoutParams labelLp = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, N.dp(this, 30), Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL);
        labelLp.leftMargin = N.dp(this, 4);
        labelLp.rightMargin = N.dp(this, 4);
        labelLp.bottomMargin = N.dp(this, 2);
        cell.addView(label, labelLp);

        IconView selectionMark = new IconView(this, IconView.GREEN_CHECK);
        selectionMark.setVisibility(View.GONE);
        FrameLayout.LayoutParams markLp = new FrameLayout.LayoutParams(N.dp(this, 36), N.dp(this, 36), Gravity.TOP | Gravity.END);
        markLp.topMargin = N.dp(this, 4);
        markLp.rightMargin = N.dp(this, 4);
        cell.addView(selectionMark, markLp);
        cell.selectionMark = selectionMark;

        cell.setOnLongClickListener(v -> {
            if (!selectionMode) selectionMode = true;
            setSelected(cell, true);
            return true;
        });
        cell.setOnClickListener(v -> {
            if (selectionMode) setSelected(cell, !cell.selected);
        });
        iconCells.add(cell);
        return cell;
    }

    private void setSelected(SquareCell cell, boolean selected) {
        if (cell.selected == selected) return;
        cell.selected = selected;
        selectedCount += selected ? 1 : -1;
        if (selectedCount < 0) selectedCount = 0;
        if (cell.selectionMark != null) cell.selectionMark.setVisibility(selected ? View.VISIBLE : View.GONE);
        if (selectedCount == 0) selectionMode = false;
        updateShareButton();
    }

    private void updateShareButton() {
        if (shareButton == null) return;
        boolean enabled = selectedCount > 0;
        shareButton.setEnabled(enabled);
        shareButton.setClickable(enabled);
        shareButton.setText(enabled ? "共有（" + selectedCount + "）" : "共有");
        shareButton.setTextColor(enabled ? N.TEXT : N.LGRAY);
        shareButton.setBackground(N.round(enabled ? N.LBLUE : N.DGRAY, 999, this));
        shareButton.setAlpha(enabled ? 1f : .72f);
    }

    private void shareSelectedIcons() {
        List<IconSpec> selected = new ArrayList<>();
        for (SquareCell cell : iconCells) if (cell.selected && cell.spec != null) selected.add(cell.spec);
        if (selected.isEmpty()) return;

        try {
            File dir = new File(getCacheDir(), "icon-share");
            if (!dir.exists() && !dir.mkdirs()) throw new IllegalStateException("共有フォルダを作成できません");
            File[] old = dir.listFiles();
            if (old != null) for (File file : old) if (file.isFile()) file.delete();

            String stamp = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(new Date());
            File zip = new File(dir, "NStandard_icons_" + stamp + ".zip");
            try (ZipOutputStream out = new ZipOutputStream(new FileOutputStream(zip))) {
                writeTextEntry(out, "SHARE_INSTRUCTION.txt",
                        "このZIP内で選択されたN Standardのアイコンを正本として扱ってください。\n" +
                        "対象アプリへ移植する際は、形状・配置・配色を勝手に変更しないでください。\n" +
                        "各icons/*.txtに元アプリと実装ソース／リソース情報があります。\n");
                writeTextEntry(out, "COMPONENT.md", buildComponentMd(selected));
                writeTextEntry(out, "manifest.json", buildManifestJson(selected));
                for (IconSpec spec : selected) {
                    writeAssetEntry(out, "icon_components/" + spec.id + ".txt", "icons/" + spec.id + ".txt");
                }
            }

            Uri uri = Uri.parse("content://" + getPackageName() + ".share/" + Uri.encode(zip.getName()));
            Intent share = new Intent(Intent.ACTION_SEND);
            share.setType("application/zip");
            share.putExtra(Intent.EXTRA_STREAM, uri);
            share.putExtra(Intent.EXTRA_TEXT,
                    "N Standardのアイコン見本から選択したアイコンです。ZIP内を正本として扱ってください。");
            share.setClipData(ClipData.newRawUri("N Standard icons", uri));
            share.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivity(Intent.createChooser(share, "アイコンを共有"));
        } catch (Exception e) {
            DiagLog.write(this, "ICON_SHARE_ERROR " + e.getClass().getSimpleName() + ": " + e.getMessage());
            Toast.makeText(this, "共有ZIPの作成に失敗しました", Toast.LENGTH_SHORT).show();
        }
    }

    private String buildComponentMd(List<IconSpec> selected) {
        StringBuilder b = new StringBuilder();
        b.append("# N Standard アイコン共有\n\n");
        b.append("このZIP内で選択したアイコンを正本として扱ってください。見た目・形状・配色を変更せず移植してください。\n\n");
        b.append("## 選択アイコン\n");
        for (IconSpec spec : selected) {
            b.append("- ").append(spec.label).append(" (`").append(spec.id).append("`) — 元: ").append(spec.sourceApp).append("\n");
        }
        b.append("\n## N配色\n");
        b.append("- D.Gray: #252020\n- L.Blue: #445577\n- White/icons: #A9A999\n- Green: #227733\n- Text: #FFFFFF\n");
        b.append("\n各アイコンの実装情報は `icons/` 以下を参照してください。\n");
        return b.toString();
    }

    private String buildManifestJson(List<IconSpec> selected) {
        StringBuilder b = new StringBuilder();
        b.append("{\n  \"component\": \"N Standard icon selection\",\n  \"icons\": [\n");
        for (int i = 0; i < selected.size(); i++) {
            IconSpec spec = selected.get(i);
            b.append("    {\"id\":\"").append(jsonEscape(spec.id)).append("\",\"name\":\"")
                    .append(jsonEscape(spec.label)).append("\",\"source_app\":\"")
                    .append(jsonEscape(spec.sourceApp)).append("\"}");
            if (i + 1 < selected.size()) b.append(',');
            b.append('\n');
        }
        b.append("  ]\n}\n");
        return b.toString();
    }

    private String jsonEscape(String s) {
        return s.replace("\\", "\\\\").replace("\"", "\\\"").replace("\n", "\\n");
    }

    private void writeTextEntry(ZipOutputStream out, String name, String content) throws Exception {
        out.putNextEntry(new ZipEntry(name));
        out.write(content.getBytes(StandardCharsets.UTF_8));
        out.closeEntry();
    }

    private void writeAssetEntry(ZipOutputStream out, String assetPath, String zipPath) throws Exception {
        out.putNextEntry(new ZipEntry(zipPath));
        try (InputStream in = getAssets().open(assetPath)) {
            byte[] buffer = new byte[8192];
            int read;
            while ((read = in.read(buffer)) >= 0) out.write(buffer, 0, read);
        }
        out.closeEntry();
    }

    private SquareCell blankCell() {
        SquareCell cell = new SquareCell(this, null);
        cell.setVisibility(View.INVISIBLE);
        return cell;
    }

    private static final class SquareCell extends FrameLayout {
        final IconSpec spec;
        boolean selected;
        View selectionMark;
        SquareCell(Context context, IconSpec spec) {
            super(context);
            this.spec = spec;
        }
        @Override protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
            super.onMeasure(widthMeasureSpec, heightMeasureSpec);
            int side = getMeasuredWidth();
            setMeasuredDimension(side, side);
        }
    }

    private android.graphics.drawable.GradientDrawable oval(int color) {
        android.graphics.drawable.GradientDrawable g = new android.graphics.drawable.GradientDrawable();
        g.setShape(android.graphics.drawable.GradientDrawable.OVAL);
        g.setColor(color);
        return g;
    }

    private TextView capsule(String value, int color, float sp) {
        TextView t = text(value, sp, N.TEXT, true);
        t.setGravity(Gravity.CENTER);
        t.setBackground(N.round(color, 999, this));
        return t;
    }

    private TextView text(String value, float sp, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextSize(sp);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }

    private static final class IconSpec {
        final String label;
        final String id;
        final String sourceApp;
        final int kind;
        IconSpec(String label, String id, String sourceApp, int kind) {
            this.label = label;
            this.id = id;
            this.sourceApp = sourceApp;
            this.kind = kind;
        }
    }

    /** Canvas versions of the source-app glyphs so their geometry stays font-independent. */
    private static final class IconView extends View {
        static final int MORE = 1;
        static final int DIAGNOSTIC = 2;
        static final int SETTINGS = 3;
        static final int TAG = 4;
        static final int DOCUMENT = 5;
        static final int ALARM = 6;
        static final int TIMER = 7;
        static final int STOPWATCH = 8;
        static final int COUNTDOWN = 9;
        static final int ROTATE = 11;
        static final int CROP = 12;
        static final int CHECK = 13;
        static final int GREEN_CHECK = 14;
        static final int BOOKMARK_PLUS = 15;
        static final int BOOKMARK_X = 16;
        static final int FOLDER = 17;
        static final int IMG_X = 18;
        static final int IMG_INSTAGRAM = 19;

        private final int kind;
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint p2 = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Path path = new Path();
        private final RectF arc = new RectF();

        IconView(Context c, int kind) {
            super(c);
            this.kind = kind;
            setLayerType(View.LAYER_TYPE_SOFTWARE, null);
        }

        private float d(float dp) { return dp * getResources().getDisplayMetrics().density; }

        @Override protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            float w = getWidth(), h = getHeight(), cx = w / 2f, cy = h / 2f;
            p.reset(); p.setAntiAlias(true); p2.reset(); p2.setAntiAlias(true);

            switch (kind) {
                case MORE: drawChiramiMore(canvas, cx, cy); break;
                case DIAGNOSTIC: drawImgDiagnostic(canvas, cx, cy); break;
                case SETTINGS: drawImgSettings(canvas, cx, cy); break;
                case TAG: drawPriceTag(canvas, w, h); break;
                case DOCUMENT: drawPriceDocument(canvas, w, h); break;
                case ALARM: drawAlarm(canvas, cx, cy); break;
                case TIMER: drawTimer(canvas, cx, cy); break;
                case STOPWATCH: drawStopwatch(canvas, cx, cy); break;
                case COUNTDOWN: drawCountdown(canvas, cx, cy); break;
                case ROTATE: drawChiramiRotate(canvas, cx, cy, w, h); break;
                case CROP: drawCrop(canvas, cx, cy); break;
                case CHECK: drawChiramiCheck(canvas, cx, cy, false); break;
                case GREEN_CHECK: drawGreenCheck(canvas, w, h); break;
                case BOOKMARK_X: drawBookmarkX(canvas, cx, cy); break;
                case FOLDER: drawBookmarkFolder(canvas, w, h); break;
                case IMG_X: drawImgX(canvas, cx, cy); break;
                case IMG_INSTAGRAM: drawImgInstagram(canvas, cx, cy); break;
            }
        }

        // Chirami ToolbarIconView.MORE geometry.
        private void drawChiramiMore(Canvas c, float cx, float cy) {
            p.setColor(N.WHITE); p.setStyle(Paint.Style.FILL);
            c.save(); c.scale(.70f, .70f, cx, cy);
            float r = d(2.15f);
            c.drawCircle(cx, cy - d(9), r, p); c.drawCircle(cx, cy, r, p); c.drawCircle(cx, cy + d(9), r, p);
            c.restore();
        }

        // ImgStalker HeaderIconView.DIAGNOSTIC geometry.
        private void drawImgDiagnostic(Canvas c, float cx, float cy) {
            p.setStyle(Paint.Style.FILL); p.setColor(N.DGRAY); c.drawCircle(cx, cy, Math.min(getWidth(), getHeight()) / 2f, p);
            p.setColor(N.WHITE);
            RectF doc = new RectF(cx - d(9.2f), cy - d(11.2f), cx + d(9.2f), cy + d(11.2f));
            c.drawRoundRect(doc, d(2.6f), d(2.6f), p);
            p.setColor(N.DGRAY); p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(d(2.7f)); p.setStrokeCap(Paint.Cap.ROUND);
            c.drawLine(cx-d(4.8f),cy-d(5.1f),cx+d(4.8f),cy-d(5.1f),p);
            c.drawLine(cx-d(4.8f),cy,cx+d(4.8f),cy,p);
            c.drawLine(cx-d(4.8f),cy+d(5.1f),cx+d(1.8f),cy+d(5.1f),p);
        }

        // ImgStalker HeaderIconView.SETTINGS geometry.
        private void drawImgSettings(Canvas c, float cx, float cy) {
            p.setStyle(Paint.Style.FILL); p.setColor(N.DGRAY); c.drawCircle(cx, cy, Math.min(getWidth(), getHeight()) / 2f, p);
            p.setColor(N.WHITE); c.drawCircle(cx, cy, d(8.4f), p);
            for (int i=0;i<6;i++) { c.save(); c.rotate(i*60f,cx,cy); RectF tooth=new RectF(cx-d(2),cy-d(12.2f),cx+d(2),cy-d(8.15f)); c.drawRoundRect(tooth,d(.8f),d(.8f),p); c.restore(); }
            p.setColor(N.DGRAY); c.drawCircle(cx, cy, d(4.1f), p);
        }

        // PriceRec TagManageIconView geometry.
        private void drawPriceTag(Canvas c, float w, float h) {
            p.setColor(N.WHITE); p.setStyle(Paint.Style.FILL); p2.setColor(N.DGRAY); p2.setStyle(Paint.Style.FILL);
            float cx=w*.5f, cy=h*.5f; c.save(); c.scale(.88f,.88f,cx,cy); c.save(); c.rotate(45,cx,cy);
            float left=w*.34f,right=w*.66f,top=h*.20f,bottom=h*.80f,r=Math.min(w,h)*.12f;
            path.reset(); path.moveTo(left+r,top); path.lineTo(right-r,top); path.quadTo(right,top,right,top+r); path.lineTo(right,bottom-r*.55f); path.quadTo(right,bottom,right-r*.55f,bottom); path.lineTo(left+r*.55f,bottom); path.quadTo(left,bottom,left,bottom-r*.55f); path.lineTo(left,top+r); path.quadTo(left,top,left+r,top); path.close();
            c.drawPath(path,p); c.drawCircle(cx,h*.31f,Math.min(w,h)*.072f,p2); c.restore(); c.restore();
        }

        // PriceRec DocumentListIconView geometry.
        private void drawPriceDocument(Canvas c, float w, float h) {
            p.setColor(N.WHITE); p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(d(2)); p.setStrokeCap(Paint.Cap.ROUND); p.setStrokeJoin(Paint.Join.ROUND);
            c.save(); c.scale(.88f,.88f,w/2f,h/2f);
            float rl=w*.38f,rt=h*.23f,rr=w*.72f,rb=h*.70f; path.reset(); path.moveTo(rl,rt);path.lineTo(rr,rt);path.lineTo(rr,rb);path.lineTo(w*.63f,rb);c.drawPath(path,p);
            float left=w*.28f,top=h*.32f,right=w*.63f,bottom=h*.79f,foldX=w*.51f,foldBottom=h*.45f;
            path.reset();path.moveTo(left,top);path.lineTo(foldX,top);path.lineTo(right,foldBottom);path.lineTo(right,bottom);path.lineTo(left,bottom);path.close();c.drawPath(path,p);
            path.reset();path.moveTo(foldX,top);path.lineTo(foldX,foldBottom);path.lineTo(right,foldBottom);c.drawPath(path,p);
            c.drawLine(w*.34f,h*.50f,w*.55f,h*.50f,p);c.drawLine(w*.34f,h*.59f,w*.55f,h*.59f,p);c.drawLine(w*.34f,h*.68f,w*.55f,h*.68f,p);c.restore();
        }

        private void baseStroke() { p.setColor(N.WHITE); p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(d(2)); p.setStrokeCap(Paint.Cap.ROUND); p.setStrokeJoin(Paint.Join.ROUND); }
        private void drawAlarm(Canvas c,float cx,float cy){baseStroke();float r=d(12);c.drawCircle(cx,cy+d(2),r,p);c.drawLine(cx,cy+d(2),cx,cy-d(5),p);c.drawLine(cx,cy+d(2),cx+d(6),cy+d(6),p);c.drawArc(new RectF(cx-d(17),cy-d(16),cx-d(5),cy-d(4)),205,130,false,p);c.drawArc(new RectF(cx+d(5),cy-d(16),cx+d(17),cy-d(4)),205,130,false,p);c.drawLine(cx-d(8),cy+d(14),cx-d(11),cy+d(18),p);c.drawLine(cx+d(8),cy+d(14),cx+d(11),cy+d(18),p);}
        private void drawTimer(Canvas c,float cx,float cy){baseStroke();RectF body=new RectF(cx-d(11),cy-d(12),cx+d(11),cy+d(14));c.drawRoundRect(body,d(4),d(4),p);c.drawLine(cx-d(5),cy-d(17),cx+d(5),cy-d(17),p);c.drawLine(cx,cy-d(17),cx,cy-d(12),p);c.drawLine(cx,cy-d(5),cx,cy+d(5),p);}
        private void drawStopwatch(Canvas c,float cx,float cy){baseStroke();c.drawCircle(cx,cy+d(3),d(13),p);c.drawLine(cx,cy-d(17),cx,cy-d(10),p);c.drawLine(cx-d(5),cy-d(17),cx+d(5),cy-d(17),p);c.drawLine(cx+d(10),cy-d(11),cx+d(14),cy-d(7),p);c.drawLine(cx,cy+d(3),cx+d(6),cy-d(4),p);}
        private void drawCountdown(Canvas c,float cx,float cy){baseStroke();c.drawCircle(cx,cy,d(14),p);c.drawLine(cx,cy,cx,cy-d(10),p);c.drawLine(cx,cy,cx+d(9),cy,p);p.setStyle(Paint.Style.FILL);path.reset();path.moveTo(cx,cy);path.lineTo(cx,cy-d(10));path.arcTo(new RectF(cx-d(10),cy-d(10),cx+d(10),cy+d(10)),-90,90);path.close();p.setColor(N.LGRAY);c.drawPath(path,p);}

        // Chirami ToolbarIconView.ROTATE geometry.
        private void drawChiramiRotate(Canvas c,float cx,float cy,float w,float h){
            c.save();c.scale(.4655f,.4655f,cx,cy);p.setColor(N.WHITE);p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(d(2.1f));p.setStrokeCap(Paint.Cap.ROUND);float diameter=Math.min(d(38),Math.min(w,h)-d(4));float radius=diameter*.5f;float inset=d(2.1f)*.5f;arc.set(cx-radius+inset,cy-radius+inset,cx+radius-inset,cy+radius-inset);c.drawArc(arc,42,292,false,p);p.setStyle(Paint.Style.FILL);path.reset();float ax=cx+radius*.74f,ay=cy-radius*.56f;path.moveTo(ax+d(5),ay-d(4.2f));path.lineTo(ax+d(4),ay+d(5.5f));path.lineTo(ax-d(5.4f),ay+d(2.7f));path.close();c.drawPath(path,p);c.restore();
        }
        private void drawCrop(Canvas c,float cx,float cy){baseStroke();float s=d(14);c.drawLine(cx-s,cy-d(5),cx-s,cy+s,p);c.drawLine(cx-s,cy+s,cx+d(5),cy+s,p);c.drawLine(cx+s,cy+d(5),cx+s,cy-s,p);c.drawLine(cx+s,cy-s,cx-d(5),cy-s,p);c.drawLine(cx-d(5),cy-s,cx-d(5),cy-d(18),p);c.drawLine(cx+s,cy+d(5),cx+d(18),cy+d(5),p);}
        private void drawChiramiCheck(Canvas c,float cx,float cy,boolean large){c.save();c.scale(large ? .95f : .49f,large ? .95f : .49f,cx,cy);p.setColor(N.WHITE);p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(d(large?1.15f:2.4f));p.setStrokeCap(Paint.Cap.SQUARE);p.setStrokeJoin(Paint.Join.MITER);path.reset();path.moveTo(cx-d(8),cy+d(.5f));path.lineTo(cx-d(2),cy+d(7));path.lineTo(cx+d(10),cy-d(8));c.drawPath(path,p);c.restore();}
        private void drawGreenCheck(Canvas c,float w,float h){p.setColor(N.GREEN);p.setStyle(Paint.Style.FILL);c.drawCircle(w/2,h/2,Math.min(w,h)*.30f,p);p.setColor(Color.WHITE);p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(d(2));p.setStrokeCap(Paint.Cap.SQUARE);p.setStrokeJoin(Paint.Join.MITER);c.drawLine(w*.37f,h*.52f,w*.47f,h*.62f,p);c.drawLine(w*.47f,h*.62f,w*.66f,h*.39f,p);}

        // BookmarkLauncher UrlAddWidgetView geometry.
        private void drawBookmarkX(Canvas c,float cx,float cy){p.setColor(N.RED);p.setStyle(Paint.Style.FILL);float s=Math.min(getWidth(),getHeight())/26f;path.reset();float[][] pts={{6.2f,4.8f},{13,11.6f},{19.8f,4.8f},{21.2f,6.2f},{14.4f,13},{21.2f,19.8f},{19.8f,21.2f},{13,14.4f},{6.2f,21.2f},{4.8f,19.8f},{11.6f,13},{4.8f,6.2f}};float ox=cx-13*s,oy=cy-13*s;path.moveTo(ox+pts[0][0]*s,oy+pts[0][1]*s);for(int i=1;i<pts.length;i++)path.lineTo(ox+pts[i][0]*s,oy+pts[i][1]*s);path.close();c.drawPath(path,p);}
        private void drawBookmarkFolder(Canvas c,float w,float h){p.setStyle(Paint.Style.FILL);p.setColor(N.LBLUE);float left=w*.18f,right=w*.82f,top=h*.28f,bottom=h*.76f,corner=Math.min(w,h)*.06f,tabW=(right-left)*.36f,tabH=(bottom-top)*.17f;path.reset();path.moveTo(left+corner,top);path.lineTo(left+tabW-corner*.35f,top);path.quadTo(left+tabW,top,left+tabW+corner*.25f,top+tabH*.45f);path.lineTo(left+tabW+corner*.8f,top+tabH);path.lineTo(right-corner,top+tabH);path.quadTo(right,top+tabH,right,top+tabH+corner);path.lineTo(right,bottom-corner);path.quadTo(right,bottom,right-corner,bottom);path.lineTo(left+corner,bottom);path.quadTo(left,bottom,left,bottom-corner);path.lineTo(left,top+corner);path.quadTo(left,top,left+corner,top);path.close();c.drawPath(path,p);}

        // ImgStalker HeaderIconView.X path.
        private void drawImgX(Canvas c,float cx,float cy){p.setStyle(Paint.Style.FILL);p.setColor(N.DGRAY);c.drawCircle(cx,cy,Math.min(getWidth(),getHeight())/2f,p);p.setColor(N.WHITE);float scale=d(.93f),ox=cx-12f*scale,oy=cy-12f*scale;path.reset();path.setFillType(Path.FillType.EVEN_ODD);path.moveTo(ox+18.244f*scale,oy+2.25f*scale);path.lineTo(ox+21.552f*scale,oy+2.25f*scale);path.lineTo(ox+14.325f*scale,oy+10.51f*scale);path.lineTo(ox+22.827f*scale,oy+21.75f*scale);path.lineTo(ox+16.17f*scale,oy+21.75f*scale);path.lineTo(ox+10.956f*scale,oy+14.933f*scale);path.lineTo(ox+4.99f*scale,oy+21.75f*scale);path.lineTo(ox+1.68f*scale,oy+21.75f*scale);path.lineTo(ox+9.41f*scale,oy+12.915f*scale);path.lineTo(ox+1.254f*scale,oy+2.25f*scale);path.lineTo(ox+8.08f*scale,oy+2.25f*scale);path.lineTo(ox+12.793f*scale,oy+8.481f*scale);path.close();path.moveTo(ox+17.083f*scale,oy+19.77f*scale);path.lineTo(ox+18.916f*scale,oy+19.77f*scale);path.lineTo(ox+7.084f*scale,oy+4.126f*scale);path.lineTo(ox+5.117f*scale,oy+4.126f*scale);path.close();c.drawPath(path,p);}

        // ImgStalker HeaderIconView.INSTAGRAM geometry, transplanted directly.
        private void drawImgInstagram(Canvas c,float cx,float cy){
            p.setStyle(Paint.Style.FILL);p.setColor(N.DGRAY);c.drawCircle(cx,cy,Math.min(getWidth(),getHeight())/2f,p);
            p.setColor(N.WHITE);p.setStrokeWidth(d(2.2f));p.setStrokeCap(Paint.Cap.SQUARE);p.setStrokeJoin(Paint.Join.ROUND);p.setStyle(Paint.Style.STROKE);
            RectF body=new RectF(cx-d(10),cy-d(10),cx+d(10),cy+d(10));
            c.drawRoundRect(body,d(5),d(5),p);
            c.drawCircle(cx,cy,d(4.5f),p);
            p.setStyle(Paint.Style.FILL);
            c.drawCircle(cx+d(6.2f),cy-d(6.2f),d(1.5f),p);
        }
    }
}
