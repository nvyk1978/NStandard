package com.cmyk.nstandard;

import android.app.Activity;
import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

/**
 * Icon reference screen. The main glyphs are transplanted from the source implementations
 * already used in PriceRec, ImgStalker, Chirami and BookmarkLauncher.
 */
public class NIconSampleActivity extends Activity {
    private static final int CELL_GAP_DP = 10;

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        setContentView(buildUi());
    }

    private View buildUi() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(N.BG);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(N.dp(this, 25), N.dp(this, 42), N.dp(this, 25), N.dp(this, 24));
        scroll.addView(root, new ScrollView.LayoutParams(-1, -2));

        TextView title = text("アイコン見本", 25, N.WHITE, true);
        title.setGravity(Gravity.START | Gravity.CENTER_VERTICAL);
        root.addView(title, new LinearLayout.LayoutParams(-1, N.dp(this, 56)));

        TextView note = text("各アプリ由来の実装を並べた見本", 12, N.WHITE, false);
        note.setAlpha(.78f);
        LinearLayout.LayoutParams noteLp = new LinearLayout.LayoutParams(-1, -2);
        noteLp.bottomMargin = N.dp(this, 14);
        root.addView(note, noteLp);

        List<IconSpec> specs = new ArrayList<>();
        specs.add(new IconSpec("三点リーダー", IconView.MORE));
        specs.add(new IconSpec("診断ログ", IconView.DIAGNOSTIC));
        specs.add(new IconSpec("設定／歯車", IconView.SETTINGS));
        specs.add(new IconSpec("タグ", IconView.TAG));
        specs.add(new IconSpec("リスト／ドキュメント", IconView.DOCUMENT));
        specs.add(new IconSpec("アラーム", IconView.ALARM));
        specs.add(new IconSpec("タイマー", IconView.TIMER));
        specs.add(new IconSpec("ストップウォッチ", IconView.STOPWATCH));
        specs.add(new IconSpec("カウントダウン", IconView.COUNTDOWN));
        specs.add(new IconSpec("＋", IconView.N_PLUS));
        specs.add(new IconSpec("回転", IconView.ROTATE));
        specs.add(new IconSpec("選択範囲／トリミング", IconView.CROP));
        specs.add(new IconSpec("チェック", IconView.CHECK));
        specs.add(new IconSpec("緑チェック", IconView.GREEN_CHECK));
        specs.add(new IconSpec("Bookmark ＋", IconView.BOOKMARK_PLUS));
        specs.add(new IconSpec("Bookmark ×", IconView.BOOKMARK_X));
        specs.add(new IconSpec("Bookmark フォルダ", IconView.FOLDER));
        specs.add(new IconSpec("ImgStalker X", IconView.IMG_X));

        for (int i = 0; i < specs.size(); i += 3) {
            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setGravity(Gravity.TOP);
            for (int c = 0; c < 3; c++) {
                int idx = i + c;
                if (idx < specs.size()) {
                    row.addView(iconCell(specs.get(idx)), new LinearLayout.LayoutParams(0, N.dp(this, 108), 1f));
                } else {
                    row.addView(new View(this), new LinearLayout.LayoutParams(0, N.dp(this, 108), 1f));
                }
                if (c < 2) row.addView(new View(this), new LinearLayout.LayoutParams(N.dp(this, CELL_GAP_DP), 1));
            }
            root.addView(row, new LinearLayout.LayoutParams(-1, N.dp(this, 108)));
        }

        TextView close = capsule("閉じる", N.GRAY, 15);
        close.setOnClickListener(v -> finish());
        LinearLayout.LayoutParams closeLp = new LinearLayout.LayoutParams(-1, N.dp(this, 46));
        closeLp.topMargin = N.dp(this, 14);
        root.addView(close, closeLp);
        return scroll;
    }

    private View iconCell(IconSpec spec) {
        LinearLayout cell = new LinearLayout(this);
        cell.setOrientation(LinearLayout.VERTICAL);
        cell.setGravity(Gravity.CENTER_HORIZONTAL);
        cell.setPadding(N.dp(this, 4), N.dp(this, 7), N.dp(this, 4), N.dp(this, 4));
        cell.setBackground(N.round(N.DGRAY, 14, this));

        View icon;
        if (spec.kind == IconView.N_PLUS) {
            FrameLayout circle = new FrameLayout(this);
            circle.setBackground(oval(N.LBLUE));
            ImageView plus = new ImageView(this);
            plus.setImageResource(R.drawable.ic_plus_geometric);
            plus.setImageTintList(ColorStateList.valueOf(N.WHITE));
            plus.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
            circle.addView(plus, new FrameLayout.LayoutParams(N.dp(this, 27), N.dp(this, 27), Gravity.CENTER));
            icon = circle;
        } else {
            icon = new IconView(this, spec.kind);
        }
        cell.addView(icon, new LinearLayout.LayoutParams(N.dp(this, 52), N.dp(this, 52)));

        TextView label = text(spec.label, 10, N.TEXT, false);
        label.setGravity(Gravity.CENTER);
        label.setMaxLines(2);
        LinearLayout.LayoutParams labelLp = new LinearLayout.LayoutParams(-1, N.dp(this, 38));
        labelLp.topMargin = N.dp(this, 3);
        cell.addView(label, labelLp);
        return cell;
    }

    private android.graphics.drawable.GradientDrawable oval(int color) {
        android.graphics.drawable.GradientDrawable g = new android.graphics.drawable.GradientDrawable();
        g.setShape(android.graphics.drawable.GradientDrawable.OVAL);
        g.setColor(color);
        return g;
    }

    private TextView capsule(String value, int color, float sp) {
        TextView t = text(value, sp, N.TEXT, true);
        t.setGravity(Gravity.CENTER);
        t.setBackground(N.round(color, 999, this));
        return t;
    }

    private TextView text(String value, float sp, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextSize(sp);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }

    private static final class IconSpec {
        final String label;
        final int kind;
        IconSpec(String label, int kind) { this.label = label; this.kind = kind; }
    }

    /** Canvas versions of the source-app glyphs so their geometry stays font-independent. */
    private static final class IconView extends View {
        static final int MORE = 1;
        static final int DIAGNOSTIC = 2;
        static final int SETTINGS = 3;
        static final int TAG = 4;
        static final int DOCUMENT = 5;
        static final int ALARM = 6;
        static final int TIMER = 7;
        static final int STOPWATCH = 8;
        static final int COUNTDOWN = 9;
        static final int N_PLUS = 10;
        static final int ROTATE = 11;
        static final int CROP = 12;
        static final int CHECK = 13;
        static final int GREEN_CHECK = 14;
        static final int BOOKMARK_PLUS = 15;
        static final int BOOKMARK_X = 16;
        static final int FOLDER = 17;
        static final int IMG_X = 18;

        private final int kind;
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint p2 = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Path path = new Path();
        private final RectF arc = new RectF();

        IconView(Context c, int kind) {
            super(c);
            this.kind = kind;
            setLayerType(View.LAYER_TYPE_SOFTWARE, null);
        }

        private float d(float dp) { return dp * getResources().getDisplayMetrics().density; }

        @Override protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            float w = getWidth(), h = getHeight(), cx = w / 2f, cy = h / 2f;
            p.reset(); p.setAntiAlias(true); p2.reset(); p2.setAntiAlias(true);

            switch (kind) {
                case MORE: drawChiramiMore(canvas, cx, cy); break;
                case DIAGNOSTIC: drawImgDiagnostic(canvas, cx, cy); break;
                case SETTINGS: drawImgSettings(canvas, cx, cy); break;
                case TAG: drawPriceTag(canvas, w, h); break;
                case DOCUMENT: drawPriceDocument(canvas, w, h); break;
                case ALARM: drawAlarm(canvas, cx, cy); break;
                case TIMER: drawTimer(canvas, cx, cy); break;
                case STOPWATCH: drawStopwatch(canvas, cx, cy); break;
                case COUNTDOWN: drawCountdown(canvas, cx, cy); break;
                case ROTATE: drawChiramiRotate(canvas, cx, cy, w, h); break;
                case CROP: drawCrop(canvas, cx, cy); break;
                case CHECK: drawChiramiCheck(canvas, cx, cy, false); break;
                case GREEN_CHECK: drawGreenCheck(canvas, w, h); break;
                case BOOKMARK_PLUS: drawBookmarkPlus(canvas, w, h); break;
                case BOOKMARK_X: drawBookmarkX(canvas, cx, cy); break;
                case FOLDER: drawBookmarkFolder(canvas, w, h); break;
                case IMG_X: drawImgX(canvas, cx, cy); break;
            }
        }

        // Chirami ToolbarIconView.MORE geometry.
        private void drawChiramiMore(Canvas c, float cx, float cy) {
            p.setColor(N.WHITE); p.setStyle(Paint.Style.FILL);
            c.save(); c.scale(.70f, .70f, cx, cy);
            float r = d(2.15f);
            c.drawCircle(cx, cy - d(9), r, p); c.drawCircle(cx, cy, r, p); c.drawCircle(cx, cy + d(9), r, p);
            c.restore();
        }

        // ImgStalker HeaderIconView.DIAGNOSTIC geometry.
        private void drawImgDiagnostic(Canvas c, float cx, float cy) {
            p.setStyle(Paint.Style.FILL); p.setColor(N.DGRAY); c.drawCircle(cx, cy, Math.min(getWidth(), getHeight()) / 2f, p);
            p.setColor(N.WHITE);
            RectF doc = new RectF(cx - d(9.2f), cy - d(11.2f), cx + d(9.2f), cy + d(11.2f));
            c.drawRoundRect(doc, d(2.6f), d(2.6f), p);
            p.setColor(N.DGRAY); p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(d(2.7f)); p.setStrokeCap(Paint.Cap.ROUND);
            c.drawLine(cx-d(4.8f),cy-d(5.1f),cx+d(4.8f),cy-d(5.1f),p);
            c.drawLine(cx-d(4.8f),cy,cx+d(4.8f),cy,p);
            c.drawLine(cx-d(4.8f),cy+d(5.1f),cx+d(1.8f),cy+d(5.1f),p);
        }

        // ImgStalker HeaderIconView.SETTINGS geometry.
        private void drawImgSettings(Canvas c, float cx, float cy) {
            p.setStyle(Paint.Style.FILL); p.setColor(N.DGRAY); c.drawCircle(cx, cy, Math.min(getWidth(), getHeight()) / 2f, p);
            p.setColor(N.WHITE); c.drawCircle(cx, cy, d(8.4f), p);
            for (int i=0;i<6;i++) { c.save(); c.rotate(i*60f,cx,cy); RectF tooth=new RectF(cx-d(2),cy-d(12.2f),cx+d(2),cy-d(8.15f)); c.drawRoundRect(tooth,d(.8f),d(.8f),p); c.restore(); }
            p.setColor(N.DGRAY); c.drawCircle(cx, cy, d(4.1f), p);
        }

        // PriceRec TagManageIconView geometry.
        private void drawPriceTag(Canvas c, float w, float h) {
            p.setColor(N.WHITE); p.setStyle(Paint.Style.FILL); p2.setColor(N.DGRAY); p2.setStyle(Paint.Style.FILL);
            float cx=w*.5f, cy=h*.5f; c.save(); c.scale(.88f,.88f,cx,cy); c.save(); c.rotate(45,cx,cy);
            float left=w*.34f,right=w*.66f,top=h*.20f,bottom=h*.80f,r=Math.min(w,h)*.12f;
            path.reset(); path.moveTo(left+r,top); path.lineTo(right-r,top); path.quadTo(right,top,right,top+r); path.lineTo(right,bottom-r*.55f); path.quadTo(right,bottom,right-r*.55f,bottom); path.lineTo(left+r*.55f,bottom); path.quadTo(left,bottom,left,bottom-r*.55f); path.lineTo(left,top+r); path.quadTo(left,top,left+r,top); path.close();
            c.drawPath(path,p); c.drawCircle(cx,h*.31f,Math.min(w,h)*.072f,p2); c.restore(); c.restore();
        }

        // PriceRec DocumentListIconView geometry.
        private void drawPriceDocument(Canvas c, float w, float h) {
            p.setColor(N.WHITE); p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(d(2)); p.setStrokeCap(Paint.Cap.ROUND); p.setStrokeJoin(Paint.Join.ROUND);
            c.save(); c.scale(.88f,.88f,w/2f,h/2f);
            float rl=w*.38f,rt=h*.23f,rr=w*.72f,rb=h*.70f; path.reset(); path.moveTo(rl,rt);path.lineTo(rr,rt);path.lineTo(rr,rb);path.lineTo(w*.63f,rb);c.drawPath(path,p);
            float left=w*.28f,top=h*.32f,right=w*.63f,bottom=h*.79f,foldX=w*.51f,foldBottom=h*.45f;
            path.reset();path.moveTo(left,top);path.lineTo(foldX,top);path.lineTo(right,foldBottom);path.lineTo(right,bottom);path.lineTo(left,bottom);path.close();c.drawPath(path,p);
            path.reset();path.moveTo(foldX,top);path.lineTo(foldX,foldBottom);path.lineTo(right,foldBottom);c.drawPath(path,p);
            c.drawLine(w*.34f,h*.50f,w*.55f,h*.50f,p);c.drawLine(w*.34f,h*.59f,w*.55f,h*.59f,p);c.drawLine(w*.34f,h*.68f,w*.55f,h*.68f,p);c.restore();
        }

        private void baseStroke() { p.setColor(N.WHITE); p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(d(2)); p.setStrokeCap(Paint.Cap.ROUND); p.setStrokeJoin(Paint.Join.ROUND); }
        private void drawAlarm(Canvas c,float cx,float cy){baseStroke();float r=d(12);c.drawCircle(cx,cy+d(2),r,p);c.drawLine(cx,cy+d(2),cx,cy-d(5),p);c.drawLine(cx,cy+d(2),cx+d(6),cy+d(6),p);c.drawArc(new RectF(cx-d(17),cy-d(16),cx-d(5),cy-d(4)),205,130,false,p);c.drawArc(new RectF(cx+d(5),cy-d(16),cx+d(17),cy-d(4)),205,130,false,p);c.drawLine(cx-d(8),cy+d(14),cx-d(11),cy+d(18),p);c.drawLine(cx+d(8),cy+d(14),cx+d(11),cy+d(18),p);}
        private void drawTimer(Canvas c,float cx,float cy){baseStroke();RectF body=new RectF(cx-d(11),cy-d(12),cx+d(11),cy+d(14));c.drawRoundRect(body,d(4),d(4),p);c.drawLine(cx-d(5),cy-d(17),cx+d(5),cy-d(17),p);c.drawLine(cx,cy-d(17),cx,cy-d(12),p);c.drawLine(cx,cy-d(5),cx,cy+d(5),p);}
        private void drawStopwatch(Canvas c,float cx,float cy){baseStroke();c.drawCircle(cx,cy+d(3),d(13),p);c.drawLine(cx,cy-d(17),cx,cy-d(10),p);c.drawLine(cx-d(5),cy-d(17),cx+d(5),cy-d(17),p);c.drawLine(cx+d(10),cy-d(11),cx+d(14),cy-d(7),p);c.drawLine(cx,cy+d(3),cx+d(6),cy-d(4),p);}
        private void drawCountdown(Canvas c,float cx,float cy){baseStroke();c.drawCircle(cx,cy,d(14),p);c.drawLine(cx,cy,cx,cy-d(10),p);c.drawLine(cx,cy,cx+d(9),cy,p);p.setStyle(Paint.Style.FILL);path.reset();path.moveTo(cx,cy);path.lineTo(cx,cy-d(10));path.arcTo(new RectF(cx-d(10),cy-d(10),cx+d(10),cy+d(10)),-90,90);path.close();p.setColor(N.LGRAY);c.drawPath(path,p);}

        // Chirami ToolbarIconView.ROTATE geometry.
        private void drawChiramiRotate(Canvas c,float cx,float cy,float w,float h){
            c.save();c.scale(.4655f,.4655f,cx,cy);p.setColor(N.WHITE);p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(d(2.1f));p.setStrokeCap(Paint.Cap.ROUND);float diameter=Math.min(d(38),Math.min(w,h)-d(4));float radius=diameter*.5f;float inset=d(2.1f)*.5f;arc.set(cx-radius+inset,cy-radius+inset,cx+radius-inset,cy+radius-inset);c.drawArc(arc,42,292,false,p);p.setStyle(Paint.Style.FILL);path.reset();float ax=cx+radius*.74f,ay=cy-radius*.56f;path.moveTo(ax+d(5),ay-d(4.2f));path.lineTo(ax+d(4),ay+d(5.5f));path.lineTo(ax-d(5.4f),ay+d(2.7f));path.close();c.drawPath(path,p);c.restore();
        }
        private void drawCrop(Canvas c,float cx,float cy){baseStroke();float s=d(14);c.drawLine(cx-s,cy-d(5),cx-s,cy+s,p);c.drawLine(cx-s,cy+s,cx+d(5),cy+s,p);c.drawLine(cx+s,cy+d(5),cx+s,cy-s,p);c.drawLine(cx+s,cy-s,cx-d(5),cy-s,p);c.drawLine(cx-d(5),cy-s,cx-d(5),cy-d(18),p);c.drawLine(cx+s,cy+d(5),cx+d(18),cy+d(5),p);}
        private void drawChiramiCheck(Canvas c,float cx,float cy,boolean large){c.save();c.scale(large ? .95f : .49f,large ? .95f : .49f,cx,cy);p.setColor(N.WHITE);p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(d(large?1.15f:2.4f));p.setStrokeCap(Paint.Cap.SQUARE);p.setStrokeJoin(Paint.Join.MITER);path.reset();path.moveTo(cx-d(8),cy+d(.5f));path.lineTo(cx-d(2),cy+d(7));path.lineTo(cx+d(10),cy-d(8));c.drawPath(path,p);c.restore();}
        private void drawGreenCheck(Canvas c,float w,float h){p.setColor(N.GREEN);p.setStyle(Paint.Style.FILL);c.drawCircle(w/2,h/2,Math.min(w,h)*.30f,p);p.setColor(Color.WHITE);p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(d(2));p.setStrokeCap(Paint.Cap.SQUARE);p.setStrokeJoin(Paint.Join.MITER);c.drawLine(w*.37f,h*.52f,w*.47f,h*.62f,p);c.drawLine(w*.47f,h*.62f,w*.66f,h*.39f,p);}

        // BookmarkLauncher UrlAddWidgetView geometry.
        private void drawBookmarkPlus(Canvas c,float w,float h){float diameter=Math.min(w,h)*.78f,cx=w/2,cy=h/2,r=diameter/2;p.setStyle(Paint.Style.FILL);p.setColor(N.LBLUE);c.drawCircle(cx,cy,r,p);p.setColor(N.WHITE);p.setStrokeWidth(Math.max(d(2),diameter*.055f));p.setStrokeCap(Paint.Cap.SQUARE);float arm=diameter*.22f;c.drawLine(cx-arm,cy,cx+arm,cy,p);c.drawLine(cx,cy-arm,cx,cy+arm,p);}
        private void drawBookmarkX(Canvas c,float cx,float cy){p.setColor(N.RED);p.setStyle(Paint.Style.FILL);float s=Math.min(getWidth(),getHeight())/26f;path.reset();float[][] pts={{6.2f,4.8f},{13,11.6f},{19.8f,4.8f},{21.2f,6.2f},{14.4f,13},{21.2f,19.8f},{19.8f,21.2f},{13,14.4f},{6.2f,21.2f},{4.8f,19.8f},{11.6f,13},{4.8f,6.2f}};float ox=cx-13*s,oy=cy-13*s;path.moveTo(ox+pts[0][0]*s,oy+pts[0][1]*s);for(int i=1;i<pts.length;i++)path.lineTo(ox+pts[i][0]*s,oy+pts[i][1]*s);path.close();c.drawPath(path,p);}
        private void drawBookmarkFolder(Canvas c,float w,float h){p.setStyle(Paint.Style.FILL);p.setColor(N.LBLUE);float left=w*.18f,right=w*.82f,top=h*.28f,bottom=h*.76f,corner=Math.min(w,h)*.06f,tabW=(right-left)*.36f,tabH=(bottom-top)*.17f;path.reset();path.moveTo(left+corner,top);path.lineTo(left+tabW-corner*.35f,top);path.quadTo(left+tabW,top,left+tabW+corner*.25f,top+tabH*.45f);path.lineTo(left+tabW+corner*.8f,top+tabH);path.lineTo(right-corner,top+tabH);path.quadTo(right,top+tabH,right,top+tabH+corner);path.lineTo(right,bottom-corner);path.quadTo(right,bottom,right-corner,bottom);path.lineTo(left+corner,bottom);path.quadTo(left,bottom,left,bottom-corner);path.lineTo(left,top+corner);path.quadTo(left,top,left+corner,top);path.close();c.drawPath(path,p);}

        // ImgStalker HeaderIconView.X path.
        private void drawImgX(Canvas c,float cx,float cy){p.setStyle(Paint.Style.FILL);p.setColor(N.DGRAY);c.drawCircle(cx,cy,Math.min(getWidth(),getHeight())/2f,p);p.setColor(N.WHITE);float scale=d(.93f),ox=cx-12f*scale,oy=cy-12f*scale;path.reset();path.setFillType(Path.FillType.EVEN_ODD);path.moveTo(ox+18.244f*scale,oy+2.25f*scale);path.lineTo(ox+21.552f*scale,oy+2.25f*scale);path.lineTo(ox+14.325f*scale,oy+10.51f*scale);path.lineTo(ox+22.827f*scale,oy+21.75f*scale);path.lineTo(ox+16.17f*scale,oy+21.75f*scale);path.lineTo(ox+10.956f*scale,oy+14.933f*scale);path.lineTo(ox+4.99f*scale,oy+21.75f*scale);path.lineTo(ox+1.68f*scale,oy+21.75f*scale);path.lineTo(ox+9.41f*scale,oy+12.915f*scale);path.lineTo(ox+1.254f*scale,oy+2.25f*scale);path.lineTo(ox+8.08f*scale,oy+2.25f*scale);path.lineTo(ox+12.793f*scale,oy+8.481f*scale);path.close();path.moveTo(ox+17.083f*scale,oy+19.77f*scale);path.lineTo(ox+18.916f*scale,oy+19.77f*scale);path.lineTo(ox+7.084f*scale,oy+4.126f*scale);path.lineTo(ox+5.117f*scale,oy+4.126f*scale);path.close();c.drawPath(path,p);}
    }
}
