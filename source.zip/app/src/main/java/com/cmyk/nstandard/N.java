package com.cmyk.nstandard;

import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.view.View;
import android.view.ViewGroup;

final class N {
    static final int BG = Color.rgb(48, 48, 48);      // #303030
    static final int DGRAY = Color.rgb(37, 32, 32);   // #252020
    static final int GRAY = Color.rgb(69, 64, 64);    // #454040
    static final int LGRAY = Color.rgb(101, 96, 96);  // #656060
    static final int BLUE = Color.rgb(34, 51, 85);    // #223355
    static final int LBLUE = Color.rgb(68, 85, 119);  // #445577
    static final int ORANGE = Color.rgb(119, 85, 0);  // #775500
    static final int WHITE = Color.rgb(169, 169, 153);// #A9A999
    static final int TEXT = Color.WHITE;

    private N() {}

    static int dp(View v, float value) {
        return Math.round(value * v.getResources().getDisplayMetrics().density);
    }

    static int dp(android.content.Context c, float value) {
        return Math.round(value * c.getResources().getDisplayMetrics().density);
    }

    static GradientDrawable round(int color, float radiusDp, android.content.Context c) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(c, radiusDp));
        return g;
    }

    static void margins(View view, int l, int t, int r, int b) {
        ViewGroup.LayoutParams lp = view.getLayoutParams();
        if (lp instanceof ViewGroup.MarginLayoutParams) {
            ((ViewGroup.MarginLayoutParams) lp).setMargins(l, t, r, b);
            view.setLayoutParams(lp);
        }
    }
}
