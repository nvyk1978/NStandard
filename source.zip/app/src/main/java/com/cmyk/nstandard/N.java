package com.cmyk.nstandard;

import android.app.Activity;
import android.app.Dialog;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import android.view.Window;
import android.view.WindowManager;

final class N {
    static final int BG = Color.rgb(48, 48, 48);       // #303030
    static final int DGRAY = Color.rgb(37, 32, 32);    // #252020
    static final int GRAY = Color.rgb(69, 64, 64);     // #454040
    static final int LGRAY = Color.rgb(101, 96, 96);   // #656060
    static final int BLUE = Color.rgb(34, 51, 85);     // #223355
    static final int LBLUE = Color.rgb(68, 85, 119);   // #445577
    static final int RED = Color.rgb(68, 17, 0);       // #441100
    static final int LRED = Color.rgb(102, 34, 17);    // #662211
    static final int ORANGE = Color.rgb(119, 85, 0);   // #775500
    static final int DORANGE = Color.rgb(85, 51, 0);   // #553300
    static final int WHITE = Color.rgb(169, 169, 153); // #A9A999
    static final int GREEN = Color.rgb(34, 119, 51);   // #227733
    static final int NEON_GREEN = Color.rgb(0, 255, 64);// #00FF40
    static final int TEXT = Color.WHITE;

    private N() {}

    static int dp(View v, float value) {
        return Math.round(value * v.getResources().getDisplayMetrics().density);
    }

    static int dp(android.content.Context c, float value) {
        return Math.round(value * c.getResources().getDisplayMetrics().density);
    }

    static GradientDrawable round(int color, float radiusDp, android.content.Context c) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(c, radiusDp));
        return g;
    }

    static void margins(View view, int l, int t, int r, int b) {
        ViewGroup.LayoutParams lp = view.getLayoutParams();
        if (lp instanceof ViewGroup.MarginLayoutParams) {
            ((ViewGroup.MarginLayoutParams) lp).setMargins(l, t, r, b);
            view.setLayoutParams(lp);
        }
    }

    /** Canonical NS dialog width: the same width as the main "ダイアログ" sample. */
    static int dialogWidth(Activity activity) {
        return Math.round(activity.getResources().getDisplayMetrics().widthPixels * 0.90f);
    }

    /**
     * Shows a dialog without exposing the intermediate platform-sized frame.
     * The decor stays transparent until the canonical width has been applied and the
     * first layout pass is ready, so the user sees only the final geometry.
     */
    static void showDialogStable(Activity activity, Dialog dialog) {
        showDialogStable(activity, dialog, 0.90f);
    }

    static void showDialogStable(Activity activity, Dialog dialog, float widthRatio) {
        Window before = dialog.getWindow();
        if (before != null) before.getDecorView().setAlpha(0f);

        dialog.show();

        Window window = dialog.getWindow();
        if (window == null) return;
        final View decor = window.getDecorView();
        decor.setAlpha(0f);

        WindowManager.LayoutParams p = new WindowManager.LayoutParams();
        p.copyFrom(window.getAttributes());
        p.width = Math.round(activity.getResources().getDisplayMetrics().widthPixels * widthRatio);
        p.height = WindowManager.LayoutParams.WRAP_CONTENT;
        p.gravity = Gravity.CENTER;
        window.setAttributes(p);

        ViewTreeObserver observer = decor.getViewTreeObserver();
        observer.addOnPreDrawListener(new ViewTreeObserver.OnPreDrawListener() {
            @Override public boolean onPreDraw() {
                if (decor.getViewTreeObserver().isAlive()) {
                    decor.getViewTreeObserver().removeOnPreDrawListener(this);
                }
                decor.setAlpha(1f);
                return true;
            }
        });
    }
}
