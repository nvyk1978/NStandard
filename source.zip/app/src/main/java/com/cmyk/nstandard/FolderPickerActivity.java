package com.cmyk.nstandard;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ContentResolver;
import android.content.Intent;
import android.content.UriPermission;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.os.storage.StorageManager;
import android.os.storage.StorageVolume;
import android.provider.DocumentsContract;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class FolderPickerActivity extends Activity {
    public static final String EXTRA_TITLE = "title";
    public static final String EXTRA_CONFIRM_TEXT = "confirm_text";
    public static final String RESULT_PATH = "path";

    private static final int REQ_SAF_MKDIR = 3101;
    private static final int M = 18;

    private final ExecutorService io = Executors.newSingleThreadExecutor();
    private final Handler main = new Handler(Looper.getMainLooper());

    private LinearLayout folderList;
    private TextView storageButton;
    private TextView pathView;
    private GripScrollHost scrollHost;
    private File currentDir;
    private List<VolumeEntry> volumes = new ArrayList<>();
    private int selectedVolume = 0;
    private long navGeneration = 0;
    private String pendingFolderName;

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        configureWindow();
        buildUi();
        loadVolumes();
    }

    @Override
    protected void onDestroy() {
        io.shutdownNow();
        super.onDestroy();
    }

    private void configureWindow() {
        Window w = getWindow();
        if (w == null) return;
        w.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        WindowManager.LayoutParams p = new WindowManager.LayoutParams();
        p.copyFrom(w.getAttributes());
        p.width = Math.min(N.dp(this, 560), getResources().getDisplayMetrics().widthPixels - N.dp(this, 24));
        p.height = Math.min(N.dp(this, 720), getResources().getDisplayMetrics().heightPixels - N.dp(this, 72));
        p.gravity = Gravity.CENTER;
        p.dimAmount = 0.55f;
        w.setAttributes(p);
        w.addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);
    }

    private void buildUi() {
        LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(N.dp(this, M), N.dp(this, 16), N.dp(this, M), N.dp(this, 14));
        panel.setBackground(N.round(N.GRAY, 12, this));

        TextView title = new TextView(this);
        title.setText(getIntent().getStringExtra(EXTRA_TITLE) == null ? "Nエクスプローラ" : getIntent().getStringExtra(EXTRA_TITLE));
        title.setTextColor(N.TEXT);
        title.setTextSize(18);
        title.setGravity(Gravity.CENTER_VERTICAL);
        panel.addView(title, new LinearLayout.LayoutParams(-1, N.dp(this, 40)));

        storageButton = new TextView(this);
        storageButton.setText("ストレージ");
        storageButton.setTextSize(16);
        storageButton.setTextColor(N.TEXT);
        storageButton.setGravity(Gravity.CENTER_VERTICAL);
        storageButton.setPadding(N.dp(this, 14), 0, N.dp(this, 14), 0);
        storageButton.setBackground(N.round(N.DGRAY, 10, this));
        storageButton.setOnClickListener(v -> showStorageChooser());
        LinearLayout.LayoutParams storageLp = new LinearLayout.LayoutParams(-1, N.dp(this, 42));
        storageLp.setMargins(0, N.dp(this, 6), 0, N.dp(this, 12));
        panel.addView(storageButton, storageLp);

        pathView = new TextView(this);
        pathView.setTextColor(N.TEXT);
        pathView.setTextSize(13);
        pathView.setGravity(Gravity.CENTER_VERTICAL);
        pathView.setSingleLine(true);
        pathView.setPadding(N.dp(this, 2), 0, N.dp(this, 2), 0);
        panel.addView(pathView, new LinearLayout.LayoutParams(-1, N.dp(this, 34)));

        LinearLayout tools = new LinearLayout(this);
        tools.setOrientation(LinearLayout.HORIZONTAL);
        tools.setGravity(Gravity.CENTER_VERTICAL);
        tools.addView(toolButton("親フォルダ", R.drawable.ic_up_n, v -> goParent()), new LinearLayout.LayoutParams(0, N.dp(this, 42), 1f));
        View toolGap = new View(this);
        tools.addView(toolGap, new LinearLayout.LayoutParams(N.dp(this, 8), 1));
        tools.addView(toolButton("新規フォルダ", R.drawable.ic_add_folder_n, v -> showNewFolderDialog()), new LinearLayout.LayoutParams(0, N.dp(this, 42), 1f));
        LinearLayout.LayoutParams toolsLp = new LinearLayout.LayoutParams(-1, N.dp(this, 42));
        toolsLp.setMargins(0, 0, 0, N.dp(this, 10));
        panel.addView(tools, toolsLp);

        folderList = new LinearLayout(this);
        folderList.setOrientation(LinearLayout.VERTICAL);
        folderList.setBackgroundColor(N.BG);
        scrollHost = new GripScrollHost(this, folderList);
        LinearLayout.LayoutParams scLp = new LinearLayout.LayoutParams(-1, 0, 1f);
        panel.addView(scrollHost, scLp);

        LinearLayout bottom = new LinearLayout(this);
        bottom.setOrientation(LinearLayout.HORIZONTAL);
        bottom.setGravity(Gravity.CENTER_VERTICAL);
        TextView cancel = pill("キャンセル", N.DGRAY);
        cancel.setOnClickListener(v -> finish());
        String confirmText = getIntent().getStringExtra(EXTRA_CONFIRM_TEXT);
        TextView confirm = pill(confirmText == null ? "このフォルダを選択" : confirmText, N.LBLUE);
        confirm.setOnClickListener(v -> confirmCurrent());
        bottom.addView(cancel, new LinearLayout.LayoutParams(0, N.dp(this, 44), 1f));
        View gap = new View(this);
        bottom.addView(gap, new LinearLayout.LayoutParams(N.dp(this, 10), 1));
        bottom.addView(confirm, new LinearLayout.LayoutParams(0, N.dp(this, 44), 1f));
        LinearLayout.LayoutParams bottomLp = new LinearLayout.LayoutParams(-1, N.dp(this, 44));
        bottomLp.setMargins(0, N.dp(this, 12), 0, 0);
        panel.addView(bottom, bottomLp);

        setContentView(panel);
    }

    private TextView pill(String text, int color) {
        TextView b = new TextView(this);
        b.setText(text);
        b.setTextColor(N.TEXT);
        b.setTextSize(14);
        b.setGravity(Gravity.CENTER);
        b.setBackground(N.round(color, 22, this));
        b.setClickable(true);
        b.setFocusable(true);
        return b;
    }

    private View toolButton(String text, int iconRes, View.OnClickListener listener) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER);
        row.setBackground(N.round(N.DGRAY, 10, this));
        row.setClickable(true);
        row.setFocusable(true);
        row.setOnClickListener(listener);

        ImageView icon = new ImageView(this);
        icon.setImageResource(iconRes);
        icon.setScaleType(ImageView.ScaleType.CENTER);
        row.addView(icon, new LinearLayout.LayoutParams(N.dp(this, 26), N.dp(this, 26)));

        TextView label = new TextView(this);
        label.setText(text);
        label.setTextColor(N.TEXT);
        label.setTextSize(14);
        label.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, -1);
        lp.setMargins(N.dp(this, 6), 0, 0, 0);
        row.addView(label, lp);
        return row;
    }

    private void loadVolumes() {
        volumes.clear();
        StorageManager sm = getSystemService(StorageManager.class);
        if (sm != null) {
            for (StorageVolume volume : sm.getStorageVolumes()) {
                File dir = null;
                if (Build.VERSION.SDK_INT >= 30) dir = volume.getDirectory();
                if (dir == null && volume.isPrimary()) dir = Environment.getExternalStorageDirectory();
                if (dir == null) continue;
                String desc = volume.getDescription(this);
                if (desc == null || desc.trim().isEmpty()) desc = volume.isPrimary() ? "内蔵ストレージ" : "ストレージ";
                if (volume.isPrimary()) desc = "内蔵ストレージ";
                volumes.add(new VolumeEntry(desc, dir, volume));
            }
        }
        if (volumes.isEmpty()) {
            volumes.add(new VolumeEntry("内蔵ストレージ", Environment.getExternalStorageDirectory(), null));
        }
        selectedVolume = 0;
        setCurrentDirectory(volumes.get(0).root);
    }

    private void showStorageChooser() {
        String[] names = new String[volumes.size()];
        for (int i = 0; i < volumes.size(); i++) names[i] = volumes.get(i).label;
        AlertDialog d = new AlertDialog.Builder(this)
                .setTitle("ストレージ")
                .setSingleChoiceItems(names, selectedVolume, (dialog, which) -> {
                    selectedVolume = which;
                    dialog.dismiss();
                    setCurrentDirectory(volumes.get(which).root);
                })
                .setNegativeButton("キャンセル", null)
                .create();
        d.setOnShowListener(x -> styleDialog(d));
        d.show();
    }

    private void setCurrentDirectory(File dir) {
        if (dir == null) return;
        currentDir = dir;
        VolumeEntry v = volumes.get(Math.min(selectedVolume, volumes.size() - 1));
        storageButton.setText(v.label);
        pathView.setText(prettyPath(v, dir));
        loadFolderRows(dir);
    }

    private String prettyPath(VolumeEntry volume, File dir) {
        try {
            String root = volume.root.getCanonicalPath();
            String path = dir.getCanonicalPath();
            if (path.equals(root)) return volume.label + " /";
            if (path.startsWith(root + File.separator)) {
                return volume.label + " / " + path.substring(root.length() + 1).replace(File.separatorChar, '／');
            }
        } catch (Exception ignored) {}
        return dir.getAbsolutePath();
    }

    private void loadFolderRows(File dir) {
        final long generation = ++navGeneration;
        folderList.removeAllViews();
        TextView loading = infoRow("読み込み中…");
        folderList.addView(loading, new LinearLayout.LayoutParams(-1, N.dp(this, 46)));

        io.execute(() -> {
            File[] children;
            try {
                children = dir.listFiles(file -> file != null && file.isDirectory() && !file.isHidden());
            } catch (Throwable t) {
                children = null;
            }
            if (children == null) children = new File[0];
            Arrays.sort(children, Comparator.comparing(File::getName, String.CASE_INSENSITIVE_ORDER));
            final File[] result = children;
            main.post(() -> {
                if (generation != navGeneration || isFinishing()) return;
                folderList.removeAllViews();
                if (result.length == 0) {
                    folderList.addView(infoRow("フォルダはありません"), new LinearLayout.LayoutParams(-1, N.dp(this, 46)));
                } else {
                    for (File child : result) {
                        folderList.addView(folderRow(child), new LinearLayout.LayoutParams(-1, N.dp(this, 46)));
                    }
                }
                scrollHost.resetScroll();
            });
        });
    }

    private TextView infoRow(String text) {
        TextView t = new TextView(this);
        t.setText(text);
        t.setTextColor(N.WHITE);
        t.setTextSize(14);
        t.setGravity(Gravity.CENTER_VERTICAL);
        t.setPadding(N.dp(this, 12), 0, N.dp(this, 12), 0);
        return t;
    }

    private View folderRow(File folder) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(N.dp(this, 6), 0, N.dp(this, 12), 0);
        row.setBackgroundColor(N.BG);
        row.setClickable(true);
        row.setFocusable(true);

        ImageView icon = new ImageView(this);
        icon.setImageResource(R.drawable.ic_folder_n);
        icon.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
        row.addView(icon, new LinearLayout.LayoutParams(N.dp(this, 32), N.dp(this, 32)));

        TextView name = new TextView(this);
        name.setText(folder.getName());
        name.setTextColor(N.TEXT);
        name.setTextSize(14);
        name.setGravity(Gravity.CENTER_VERTICAL);
        name.setSingleLine(true);
        LinearLayout.LayoutParams nameLp = new LinearLayout.LayoutParams(0, -1, 1f);
        nameLp.setMargins(N.dp(this, 8), 0, 0, 0);
        row.addView(name, nameLp);

        row.setOnClickListener(v -> setCurrentDirectory(folder));
        return row;
    }

    private void goParent() {
        if (currentDir == null) return;
        VolumeEntry v = volumes.get(Math.min(selectedVolume, volumes.size() - 1));
        if (samePath(currentDir, v.root)) return;
        File parent = currentDir.getParentFile();
        if (parent == null || !isWithin(parent, v.root)) parent = v.root;
        setCurrentDirectory(parent);
    }

    private void showNewFolderDialog() {
        final android.widget.EditText input = new android.widget.EditText(this);
        input.setSingleLine(true);
        input.setTextColor(N.TEXT);
        input.setHintTextColor(N.WHITE);
        input.setHint("フォルダ名");
        input.setBackground(N.round(N.DGRAY, 10, this));
        input.setPadding(N.dp(this, 12), 0, N.dp(this, 12), 0);

        FrameLayout box = new FrameLayout(this);
        int side = N.dp(this, 18);
        box.setPadding(side, N.dp(this, 8), side, 0);
        box.addView(input, new FrameLayout.LayoutParams(-1, N.dp(this, 44)));

        AlertDialog d = new AlertDialog.Builder(this)
                .setTitle("新規フォルダ")
                .setView(box)
                .setNegativeButton("キャンセル", null)
                .setPositiveButton("作成", null)
                .create();
        d.setOnShowListener(x -> {
            styleDialog(d);
            d.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
                String name = input.getText().toString().trim();
                if (!validFolderName(name)) {
                    Toast.makeText(this, "使用できないフォルダ名です", Toast.LENGTH_SHORT).show();
                    return;
                }
                d.dismiss();
                createFolder(name);
            });
        });
        d.show();
    }

    private void createFolder(String name) {
        if (currentDir == null) return;
        File target = new File(currentDir, name);
        if (target.exists()) {
            Toast.makeText(this, "同名フォルダがあります", Toast.LENGTH_SHORT).show();
            return;
        }
        boolean ok = false;
        try { ok = target.mkdir(); } catch (Throwable ignored) {}
        if (ok) {
            loadFolderRows(currentDir);
            return;
        }
        pendingFolderName = name;
        requestSafForCurrentDirectory();
    }

    private void requestSafForCurrentDirectory() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION |
                Intent.FLAG_GRANT_WRITE_URI_PERMISSION |
                Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION |
                Intent.FLAG_GRANT_PREFIX_URI_PERMISSION);
        if (Build.VERSION.SDK_INT >= 26 && currentDir != null) {
            Uri initial = tryBuildInitialUri(currentDir);
            if (initial != null) intent.putExtra(DocumentsContract.EXTRA_INITIAL_URI, initial);
        }
        Toast.makeText(this, "このフォルダへの書き込み権限を選択してください", Toast.LENGTH_LONG).show();
        startActivityForResult(intent, REQ_SAF_MKDIR);
    }

    private Uri tryBuildInitialUri(File dir) {
        try {
            VolumeEntry v = volumes.get(Math.min(selectedVolume, volumes.size() - 1));
            String root = v.root.getCanonicalPath();
            String path = dir.getCanonicalPath();
            String rel = path.equals(root) ? "" : path.substring(root.length() + 1).replace(File.separatorChar, '/');
            String volumeId = v.volume != null && !v.volume.isPrimary() && v.volume.getUuid() != null ? v.volume.getUuid() : "primary";
            String docId = volumeId + ":" + rel;
            return DocumentsContract.buildDocumentUri("com.android.externalstorage.documents", docId);
        } catch (Throwable ignored) {
            return null;
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != REQ_SAF_MKDIR) return;
        String folderName = pendingFolderName;
        pendingFolderName = null;
        if (resultCode != RESULT_OK || data == null || data.getData() == null) return;
        Uri tree = data.getData();
        int flags = data.getFlags() & (Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
        try {
            getContentResolver().takePersistableUriPermission(tree, flags);
        } catch (Throwable ignored) {}
        if (folderName != null) {
            boolean ok = createFolderWithSaf(tree, folderName);
            if (!ok) Toast.makeText(this, "フォルダを作成できませんでした", Toast.LENGTH_LONG).show();
            loadFolderRows(currentDir);
        }
    }

    private boolean createFolderWithSaf(Uri tree, String name) {
        try {
            String rootDocId = DocumentsContract.getTreeDocumentId(tree);
            Uri rootDoc = DocumentsContract.buildDocumentUriUsingTree(tree, rootDocId);
            Uri created = DocumentsContract.createDocument(getContentResolver(), rootDoc,
                    DocumentsContract.Document.MIME_TYPE_DIR, name);
            return created != null;
        } catch (Throwable t) {
            return false;
        }
    }

    private void confirmCurrent() {
        if (currentDir == null) return;
        Intent result = new Intent();
        result.putExtra(RESULT_PATH, currentDir.getAbsolutePath());
        setResult(RESULT_OK, result);
        finish();
    }

    private void styleDialog(AlertDialog d) {
        Window w = d.getWindow();
        if (w != null) {
            w.setBackgroundDrawable(N.round(N.GRAY, 12, this));
        }
        if (d.getButton(AlertDialog.BUTTON_POSITIVE) != null) d.getButton(AlertDialog.BUTTON_POSITIVE).setTextColor(N.TEXT);
        if (d.getButton(AlertDialog.BUTTON_NEGATIVE) != null) d.getButton(AlertDialog.BUTTON_NEGATIVE).setTextColor(N.TEXT);
        if (d.getButton(AlertDialog.BUTTON_NEUTRAL) != null) d.getButton(AlertDialog.BUTTON_NEUTRAL).setTextColor(N.TEXT);
    }

    private boolean validFolderName(String name) {
        if (name == null || name.isEmpty() || ".".equals(name) || "..".equals(name)) return false;
        return !(name.contains("/") || name.contains("\\") || name.contains(":"));
    }

    private boolean samePath(File a, File b) {
        try { return a.getCanonicalFile().equals(b.getCanonicalFile()); }
        catch (Exception e) { return a.getAbsolutePath().equals(b.getAbsolutePath()); }
    }

    private boolean isWithin(File child, File root) {
        try {
            String c = child.getCanonicalPath();
            String r = root.getCanonicalPath();
            return c.equals(r) || c.startsWith(r + File.separator);
        } catch (Exception e) {
            return false;
        }
    }

    private static final class VolumeEntry {
        final String label;
        final File root;
        final StorageVolume volume;
        VolumeEntry(String label, File root, StorageVolume volume) {
            this.label = label;
            this.root = root;
            this.volume = volume;
        }
    }

    private static final class GripScrollHost extends FrameLayout {
        private final ScrollView scroll;
        private final View thumb;
        private final View grabZone;
        private final Handler handler = new Handler(Looper.getMainLooper());
        private final Runnable fade;
        private final int thumbWidth;
        private boolean dragging;

        GripScrollHost(android.content.Context context, View content) {
            super(context);
            setBackgroundColor(N.BG);

            scroll = new ScrollView(context);
            scroll.setFillViewport(true);
            scroll.setVerticalScrollBarEnabled(false);
            scroll.addView(content, new ScrollView.LayoutParams(-1, -2));
            addView(scroll, new FrameLayout.LayoutParams(-1, -1));

            thumbWidth = N.dp(context, 4);
            thumb = new View(context);
            thumb.setBackground(N.round(N.WHITE, 2, context));
            thumb.setAlpha(0f);
            FrameLayout.LayoutParams thumbLp = new FrameLayout.LayoutParams(thumbWidth, N.dp(context, 36), Gravity.END | Gravity.TOP);
            thumbLp.rightMargin = N.dp(context, 2);
            addView(thumb, thumbLp);

            grabZone = new View(context);
            grabZone.setBackgroundColor(Color.TRANSPARENT);
            FrameLayout.LayoutParams grabLp = new FrameLayout.LayoutParams(N.dp(context, 30), -1, Gravity.END);
            addView(grabZone, grabLp);

            fade = () -> thumb.animate().alpha(0f).setDuration(260).start();

            scroll.setOnScrollChangeListener((v, sx, sy, osx, osy) -> updateThumb(true));
            grabZone.setOnTouchListener((v, e) -> {
                switch (e.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN:
                        dragging = true;
                        handler.removeCallbacks(fade);
                        thumb.animate().cancel();
                        thumb.setAlpha(1f);
                        dragTo(e.getY());
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        dragTo(e.getY());
                        return true;
                    case MotionEvent.ACTION_UP:
                    case MotionEvent.ACTION_CANCEL:
                        dragging = false;
                        scheduleFade();
                        return true;
                    default:
                        return false;
                }
            });
            post(() -> updateThumb(false));
        }

        void resetScroll() {
            scroll.post(() -> {
                scroll.scrollTo(0, 0);
                updateThumb(false);
            });
        }

        private void dragTo(float y) {
            int extent = scroll.getHeight();
            int range = scroll.getChildCount() == 0 ? extent : scroll.getChildAt(0).getHeight();
            int maxScroll = Math.max(0, range - extent);
            if (maxScroll == 0) return;
            int thumbH = thumb.getLayoutParams().height;
            float track = Math.max(1f, getHeight() - thumbH);
            float pos = Math.max(0f, Math.min(track, y - thumbH / 2f));
            int target = Math.round(maxScroll * (pos / track));
            scroll.scrollTo(0, target);
            updateThumb(false);
        }

        private void updateThumb(boolean interacted) {
            if (scroll.getChildCount() == 0 || getHeight() <= 0) return;
            int extent = scroll.getHeight();
            int range = scroll.getChildAt(0).getHeight();
            if (range <= extent || extent <= 0) {
                thumb.setAlpha(0f);
                return;
            }
            int h = Math.max(N.dp(getContext(), 28), Math.round((float) extent * extent / range));
            h = Math.min(h, Math.max(N.dp(getContext(), 28), getHeight()));
            FrameLayout.LayoutParams lp = (FrameLayout.LayoutParams) thumb.getLayoutParams();
            lp.height = h;
            int maxScroll = Math.max(1, range - extent);
            int track = Math.max(1, getHeight() - h);
            lp.topMargin = Math.round(track * (scroll.getScrollY() / (float) maxScroll));
            thumb.setLayoutParams(lp);
            if (interacted && !dragging) {
                thumb.animate().cancel();
                thumb.setAlpha(1f);
                scheduleFade();
            }
        }

        private void scheduleFade() {
            handler.removeCallbacks(fade);
            handler.postDelayed(fade, 700);
        }
    }
}
