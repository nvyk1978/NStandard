package com.cmyk.nstandard;

import android.app.Activity;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.Gravity;
import android.view.HapticFeedbackConstants;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Space;
import android.widget.TextView;
import android.widget.Toast;

/** Interactive reference for the shared N button/toggle/selection vocabulary. */
public class NButtonSampleActivity extends Activity {
    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        setContentView(buildUi());
    }

    private View buildUi() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(N.BG);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(N.dp(this, 25), N.dp(this, N.PAGE_TITLE_TOP_DP), N.dp(this, 25), N.dp(this, 24));
        scroll.addView(root, new ScrollView.LayoutParams(-1, -2));

        TextView title = text("ボタン見本", 25, N.WHITE, true);
        root.addView(title, new LinearLayout.LayoutParams(-1, N.dp(this, 56)));

        addSectionLabel(root, "基本ボタン");
        TextView capsule = capsule("カプセル型ボタン", N.LBLUE, 16);
        capsule.setOnClickListener(v -> toast("カプセル型ボタン"));
        root.addView(capsule, lp(-1, 48, 0, 8));

        LinearLayout thinRow = new LinearLayout(this);
        thinRow.setGravity(Gravity.START | Gravity.CENTER_VERTICAL);
        TextView thin = NDiagnosticLog.makeDialogAction(this, "細いカプセル型ボタン");
        thin.setGravity(Gravity.CENTER);
        thin.setOnClickListener(v -> toast("細いカプセル型ボタン"));
        thinRow.addView(thin, new LinearLayout.LayoutParams(N.dp(this, 176), N.dp(this, 48)));
        root.addView(thinRow, lp(-1, 48, 0, 8));

        LinearLayout toggleRow = new LinearLayout(this);
        toggleRow.setGravity(Gravity.START | Gravity.CENTER_VERTICAL);
        NToggleSwitch toggle = new NToggleSwitch(this);
        TextView toggleLabel = text("Nトグル", 15, N.TEXT, false);
        toggleRow.addView(toggle, new LinearLayout.LayoutParams(N.dp(this, 58), N.dp(this, 34)));
        LinearLayout.LayoutParams tlp = new LinearLayout.LayoutParams(-2, N.dp(this, 34)); tlp.leftMargin = N.dp(this, 10);
        toggleRow.addView(toggleLabel, tlp);
        root.addView(toggleRow, lp(-1, 42, 0, 8));

        TextView textButton = text("テキストボタン", 15, N.TEXT, true);
        textButton.setGravity(Gravity.START | Gravity.CENTER_VERTICAL);
        textButton.setPadding(N.dp(this, 4), 0, N.dp(this, 4), 0);
        textButton.setOnClickListener(v -> toast("テキストボタン"));
        root.addView(textButton, lp(-1, 42, 0, 16));

        addSectionLabel(root, "色指定のある操作");
        LinearLayout colorList = new LinearLayout(this);
        colorList.setOrientation(LinearLayout.VERTICAL);
        colorList.setPadding(N.dp(this, 12), N.dp(this, 10), N.dp(this, 12), N.dp(this, 10));
        colorList.setBackground(N.round(N.DGRAY, 14, this));
        colorList.addView(colorRow("OK", "#445577", capsule("OK", N.LBLUE, 13)));
        colorList.addView(colorRow("オプションボタン", "#775500", capsule("オプション", N.ORANGE, 13)));
        colorList.addView(colorRow("削除", "#662211", capsule("削除", N.LRED, 13)));
        colorList.addView(colorRow("無効", "#252020 / #656060", disabledCapsule()));
        colorList.addView(colorRow("＋丸", "#445577 / #A9A999", plusCircle()));
        root.addView(colorList, lp(-1, -2, 0, 18));

        addSectionLabel(root, "セル長押し選択");
        TextView hint = text("長押しで選択モード／タップで選択・解除", 12, N.WHITE, false);
        hint.setAlpha(.78f);
        root.addView(hint, lp(-1, 30, 0, 4));
        LinearLayout cellRow = new LinearLayout(this);
        cellRow.setOrientation(LinearLayout.HORIZONTAL);
        cellRow.setGravity(Gravity.TOP);
        for (int i = 1; i <= 3; i++) {
            View cell = selectionCell("セル" + i);
            cellRow.addView(cell, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
            if (i < 3) {
                cellRow.addView(new Space(this), new LinearLayout.LayoutParams(N.dp(this, 8), 1));
            }
        }
        root.addView(cellRow, lp(-1, -2, 0, 8));

        TextView close = capsule("閉じる", N.GRAY, 15);
        close.setOnClickListener(v -> finish());
        root.addView(close, lp(-1, 46, 10, 0));
        return scroll;
    }

    private void addSectionLabel(LinearLayout root, String label) {
        TextView t = text(label, 13, N.WHITE, true);
        t.setAlpha(.88f);
        root.addView(t, lp(-1, 28, 2, 4));
    }

    private View colorRow(String name, String code, View sample) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        TextView label = text(name + "\n" + code, 12, N.TEXT, false);
        label.setGravity(Gravity.CENTER_VERTICAL);
        row.addView(label, new LinearLayout.LayoutParams(0, N.dp(this, 50), 1f));
        row.addView(sample, new LinearLayout.LayoutParams(N.dp(this, 108), N.dp(this, 36)));
        return row;
    }

    private View plusCircle() {
        FrameLayout host = new FrameLayout(this);
        NPlusView plus = new NPlusView(this, N.LBLUE, N.WHITE, 1f);
        host.addView(plus, new FrameLayout.LayoutParams(N.dp(this, 36), N.dp(this, 36), Gravity.CENTER));
        return host;
    }

    private View disabledCapsule() {
        TextView t = capsule("無効", N.DGRAY, 13);
        t.setTextColor(N.LGRAY);
        t.setEnabled(false);
        return t;
    }

    private boolean selectionMode = false;

    private View selectionCell(String label) {
        SquareSelectionCell frame = new SquareSelectionCell();
        frame.setBackground(N.round(N.GRAY, 12, this));
        frame.setPadding(0, 0, 0, 0);
        TextView name = text(label, 15, N.TEXT, false);
        name.setGravity(Gravity.CENTER);
        name.setIncludeFontPadding(false);
        FrameLayout.LayoutParams nameLp = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.CENTER);
        frame.addView(name, nameLp);

        SelectionCheckBadge check = new SelectionCheckBadge();
        check.setVisibility(View.GONE);
        FrameLayout.LayoutParams clp = new FrameLayout.LayoutParams(
                N.dp(this, 24), N.dp(this, 24), Gravity.END | Gravity.TOP);
        clp.topMargin = N.dp(this, 8);
        clp.rightMargin = N.dp(this, 8);
        frame.addView(check, clp);

        final boolean[] selected = {false};
        frame.setOnLongClickListener(v -> {
            selectionMode = true;
            if (!selected[0]) {
                selected[0] = true;
                updateSelectionCell(frame, check, true);
            }
            v.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS);
            return true;
        });
        frame.setOnClickListener(v -> {
            if (!selectionMode) return;
            selected[0] = !selected[0];
            updateSelectionCell(frame, check, selected[0]);
        });
        return frame;
    }


    private final class SquareSelectionCell extends FrameLayout {
        SquareSelectionCell() { super(NButtonSampleActivity.this); }
        @Override protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
            super.onMeasure(widthMeasureSpec, heightMeasureSpec);
            int side = getMeasuredWidth();
            setMeasuredDimension(side, side);
        }
    }

    private void updateSelectionCell(FrameLayout frame, SelectionCheckBadge check, boolean selected) {
        check.setVisibility(selected ? View.VISIBLE : View.GONE);
        frame.setBackground(N.round(selected ? N.BLUE : N.GRAY, 12, this));
    }

    private TextView capsule(String value, int color, float sp) {
        TextView t = text(value, sp, N.TEXT, true);
        t.setGravity(Gravity.CENTER);
        t.setBackground(N.round(color, 999, this));
        return t;
    }

    private TextView text(String value, float sp, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextSize(sp);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }

    private LinearLayout.LayoutParams lp(int w, int hDp, int topDp, int bottomDp) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(w, hDp < 0 ? hDp : N.dp(this, hDp));
        lp.topMargin = N.dp(this, topDp); lp.bottomMargin = N.dp(this, bottomDp);
        return lp;
    }

    private void toast(String msg) { Toast.makeText(this, msg, Toast.LENGTH_SHORT).show(); }

    /** PriceRec StraightCheckBadgeView geometry / N green check. */
    private final class SelectionCheckBadge extends View {
        private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint check = new Paint(Paint.ANTI_ALIAS_FLAG);
        SelectionCheckBadge() {
            super(NButtonSampleActivity.this);
            fill.setColor(N.GREEN); fill.setStyle(Paint.Style.FILL);
            check.setColor(Color.WHITE); check.setStyle(Paint.Style.STROKE);
            check.setStrokeWidth(N.dp(NButtonSampleActivity.this, 2));
            check.setStrokeCap(Paint.Cap.SQUARE); check.setStrokeJoin(Paint.Join.MITER);
        }
        @Override protected void onDraw(Canvas c) {
            float w=getWidth(),h=getHeight(),r=Math.min(w,h)/2f;
            c.drawCircle(w/2f,h/2f,r,fill);
            c.drawLine(w*.27f,h*.53f,w*.44f,h*.69f,check);
            c.drawLine(w*.44f,h*.69f,w*.76f,h*.34f,check);
        }
    }
}
