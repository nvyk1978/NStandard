package com.cmyk.nstandard;

import android.app.Activity;
import android.content.Context;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.res.ColorStateList;
import android.os.Bundle;
import android.text.Editable;
import android.text.InputFilter;
import android.text.InputType;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Locale;

/**
 * N Standard margin live-preview reference.
 * 0dp means the preview edge is exactly on the physical layout edge.
 * Controls are a compact centered overlay so they do not affect preview geometry.
 */
public final class NMarginActivity extends Activity {
    private static final int MAX_DP = 999;
    private static final int MIN_PREVIEW_DP = 8;

    private FrameLayout previewHost;
    private View previewRect;
    // top, bottom, left, right
    private final int[] values = new int[]{50, 30, 25, 25};
    private final SeekBar[] sliders = new SeekBar[4];
    private final EditText[] inputs = new EditText[4];
    private boolean syncing;

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setStatusBarColor(N.BG);
        getWindow().setNavigationBarColor(N.BG);
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
        applyImmersive();
        setContentView(buildUi());
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) applyImmersive();
    }

    private void applyImmersive() {
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                        | View.SYSTEM_UI_FLAG_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
    }

    private View buildUi() {
        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(N.BG);

        // Full-screen measurement host. No padding: 0dp = exact screen edge.
        previewHost = new FrameLayout(this);
        previewHost.setBackgroundColor(N.BG);
        root.addView(previewHost, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT));

        previewRect = new View(this);
        previewRect.setBackground(N.round(N.GRAY, 0, this));
        previewHost.addView(previewRect, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT));

        LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(10), dp(8), dp(10), dp(8));
        panel.setBackground(N.round(N.DGRAY, 14, this));

        String[] labels = {"上", "下", "左", "右"};
        for (int i = 0; i < 4; i++) {
            LinearLayout.LayoutParams rowLp = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, dp(40));
            if (i > 0) rowLp.topMargin = dp(2);
            panel.addView(makeControlRow(i, labels[i]), rowLp);
        }

        LinearLayout actions = new LinearLayout(this);
        actions.setOrientation(LinearLayout.HORIZONTAL);
        actions.setGravity(Gravity.CENTER_VERTICAL);
        TextView copy = NDiagnosticLog.makeDialogAction(this, "コピー");
        TextView defaults = NDiagnosticLog.makeDialogAction(this, "規定値");
        copy.setGravity(Gravity.CENTER);
        defaults.setGravity(Gravity.CENTER);
        copy.setOnClickListener(v -> copyCurrentMargins());
        defaults.setOnClickListener(v -> restoreDefaultMargins());
        LinearLayout.LayoutParams copyLp = new LinearLayout.LayoutParams(0, dp(42), 1f);
        copyLp.rightMargin = dp(5);
        LinearLayout.LayoutParams defaultsLp = new LinearLayout.LayoutParams(0, dp(42), 1f);
        defaultsLp.leftMargin = dp(5);
        actions.addView(copy, copyLp);
        actions.addView(defaults, defaultsLp);
        LinearLayout.LayoutParams actionsLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(42));
        actionsLp.topMargin = dp(6);
        panel.addView(actions, actionsLp);

        FrameLayout.LayoutParams panelLp = new FrameLayout.LayoutParams(
                dp(292), ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.CENTER);
        root.addView(panel, panelLp);

        previewHost.post(this::updatePreview);
        return root;
    }

    private View makeControlRow(int index, String label) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);

        TextView name = new TextView(this);
        name.setText(label);
        name.setTextColor(N.TEXT);
        name.setTextSize(15);
        name.setGravity(Gravity.CENTER);
        row.addView(name, new LinearLayout.LayoutParams(dp(24), dp(36)));

        SeekBar seek = new SeekBar(this);
        seek.setMax(MAX_DP);
        seek.setProgress(values[index]);
        seek.setProgressTintList(ColorStateList.valueOf(N.LBLUE));
        seek.setProgressBackgroundTintList(ColorStateList.valueOf(N.DGRAY));
        seek.setThumbTintList(ColorStateList.valueOf(N.WHITE));
        seek.setSplitTrack(false);
        // Keep at least a thumb radius inside both ends so min/max never clip.
        seek.setPadding(dp(12), 0, dp(12), 0);
        sliders[index] = seek;
        row.addView(seek, new LinearLayout.LayoutParams(dp(150), dp(36)));

        EditText input = new EditText(this);
        input.setSingleLine(true);
        input.setText(format(values[index]));
        input.setTextColor(N.TEXT);
        input.setTextSize(14);
        input.setGravity(Gravity.CENTER);
        input.setSelectAllOnFocus(true);
        input.setInputType(InputType.TYPE_CLASS_NUMBER);
        input.setImeOptions(EditorInfo.IME_ACTION_DONE);
        input.setFilters(new InputFilter[]{new InputFilter.LengthFilter(3)});
        input.setPadding(dp(3), 0, dp(3), 0);
        input.setBackground(N.round(N.GRAY, 8, this));
        inputs[index] = input;
        LinearLayout.LayoutParams inputLp = new LinearLayout.LayoutParams(dp(54), dp(32));
        inputLp.leftMargin = dp(6);
        row.addView(input, inputLp);

        TextView dpLabel = new TextView(this);
        dpLabel.setText("dp");
        dpLabel.setTextColor(N.WHITE);
        dpLabel.setTextSize(12);
        dpLabel.setGravity(Gravity.CENTER_VERTICAL | Gravity.START);
        LinearLayout.LayoutParams unitLp = new LinearLayout.LayoutParams(dp(26), dp(36));
        unitLp.leftMargin = dp(2);
        row.addView(dpLabel, unitLp);

        seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                if (!fromUser || syncing) return;
                values[index] = progress;
                syncing = true;
                input.setText(format(progress));
                syncing = false;
                updatePreview();
            }

            @Override public void onStartTrackingTouch(SeekBar seekBar) { }
            @Override public void onStopTrackingTouch(SeekBar seekBar) { }
        });

        input.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) { }
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) { }

            @Override
            public void afterTextChanged(Editable e) {
                if (syncing) return;
                String raw = e.toString().trim();
                if (raw.isEmpty()) return;
                int value;
                try {
                    value = Integer.parseInt(raw);
                } catch (NumberFormatException ex) {
                    return;
                }
                value = Math.max(0, Math.min(MAX_DP, value));
                values[index] = value;
                syncing = true;
                seek.setProgress(value);
                syncing = false;
                updatePreview();
            }
        });

        input.setOnFocusChangeListener((v, hasFocus) -> {
            if (hasFocus) {
                input.selectAll();
            } else {
                syncing = true;
                input.setText(format(values[index]));
                syncing = false;
            }
        });

        input.setOnEditorActionListener((v, actionId, event) -> {
            if (actionId == EditorInfo.IME_ACTION_DONE) {
                input.clearFocus();
                InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
                if (imm != null) imm.hideSoftInputFromWindow(input.getWindowToken(), 0);
                applyImmersive();
                return true;
            }
            return false;
        });

        return row;
    }

    private void copyCurrentMargins() {
        String value = "上 " + values[0] + "dp / 左 " + values[2] + "dp / 右 " + values[3] + "dp / 下 " + values[1] + "dp";
        ClipboardManager clipboard = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        if (clipboard != null) {
            clipboard.setPrimaryClip(ClipData.newPlainText("N Standard margin", value));
            Toast.makeText(this, "マージン値をコピーしました", Toast.LENGTH_SHORT).show();
        }
    }

    private void restoreDefaultMargins() {
        int[] defaults = {50, 30, 25, 25};
        syncing = true;
        for (int i = 0; i < values.length; i++) {
            values[i] = defaults[i];
            if (sliders[i] != null) sliders[i].setProgress(values[i]);
            if (inputs[i] != null) inputs[i].setText(format(values[i]));
        }
        syncing = false;
        updatePreview();
    }

    private void updatePreview() {
        if (previewHost == null || previewRect == null) return;
        int w = previewHost.getWidth();
        int h = previewHost.getHeight();
        if (w <= 0 || h <= 0) return;

        int top = dp(values[0]);
        int bottom = dp(values[1]);
        int left = dp(values[2]);
        int right = dp(values[3]);
        int min = dp(MIN_PREVIEW_DP);

        int visualLeft = Math.min(left, Math.max(0, w - min));
        int visualTop = Math.min(top, Math.max(0, h - min));
        int visualRight = Math.min(right, Math.max(0, w - visualLeft - min));
        int visualBottom = Math.min(bottom, Math.max(0, h - visualTop - min));

        int width = Math.max(min, w - visualLeft - visualRight);
        int height = Math.max(min, h - visualTop - visualBottom);

        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(width, height);
        lp.leftMargin = visualLeft;
        lp.topMargin = visualTop;
        previewRect.setLayoutParams(lp);
    }

    private String format(int value) {
        return String.format(Locale.US, "%03d", value);
    }

    private int dp(float value) {
        return N.dp(this, value);
    }
}
