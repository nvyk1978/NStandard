package com.cmyk.nstandard;

import android.app.Activity;
import android.content.res.ColorStateList;
import android.os.Bundle;
import android.text.Editable;
import android.text.InputFilter;
import android.text.InputType;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.content.Context;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.TextView;

import java.util.Locale;

/**
 * N Standard margin live-preview reference.
 * Four dp values are editable by slider and numeric input and stay synchronized.
 */
public final class NMarginActivity extends Activity {
    private static final int MAX_DP = 999;
    private static final int MIN_PREVIEW_DP = 8;

    private FrameLayout previewHost;
    private View previewRect;
    private final int[] values = new int[]{0, 0, 0, 0}; // top,bottom,left,right
    private final SeekBar[] sliders = new SeekBar[4];
    private final EditText[] inputs = new EditText[4];
    private boolean syncing;

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(N.BG);
        getWindow().setNavigationBarColor(N.BG);
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        applyImmersive();
        setContentView(buildUi());
    }

    @Override
    protected void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) applyImmersive();
    }

    private void applyImmersive() {
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                        | View.SYSTEM_UI_FLAG_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
    }

    private View buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(N.BG);
        root.setPadding(dp(18), dp(18), dp(18), dp(18));

        previewHost = new FrameLayout(this);
        previewHost.setBackgroundColor(N.BG);
        previewRect = new View(this);
        previewRect.setBackground(N.round(N.GRAY, 0, this));
        previewHost.addView(previewRect, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        LinearLayout.LayoutParams previewLp = new LinearLayout.LayoutParams(-1, 0, 1f);
        previewLp.bottomMargin = dp(16);
        root.addView(previewHost, previewLp);

        String[] labels = {"上", "下", "左", "右"};
        for (int i = 0; i < 4; i++) {
            root.addView(makeControlRow(i, labels[i]), new LinearLayout.LayoutParams(-1, dp(48)));
        }

        previewHost.post(this::updatePreview);
        return root;
    }

    private View makeControlRow(int index, String label) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);

        TextView name = new TextView(this);
        name.setText(label);
        name.setTextColor(N.TEXT);
        name.setTextSize(16);
        name.setGravity(Gravity.START | Gravity.CENTER_VERTICAL);
        row.addView(name, new LinearLayout.LayoutParams(dp(30), -1));

        SeekBar seek = new SeekBar(this);
        seek.setMax(MAX_DP);
        seek.setProgress(values[index]);
        seek.setProgressTintList(ColorStateList.valueOf(N.LBLUE));
        seek.setProgressBackgroundTintList(ColorStateList.valueOf(N.DGRAY));
        seek.setThumbTintList(ColorStateList.valueOf(N.WHITE));
        seek.setPadding(0, 0, 0, 0);
        sliders[index] = seek;
        row.addView(seek, new LinearLayout.LayoutParams(0, dp(42), 1f));

        EditText input = new EditText(this);
        input.setSingleLine(true);
        input.setText(format(values[index]));
        input.setTextColor(N.TEXT);
        input.setTextSize(15);
        input.setGravity(Gravity.CENTER);
        input.setSelectAllOnFocus(true);
        input.setInputType(InputType.TYPE_CLASS_NUMBER);
        input.setImeOptions(EditorInfo.IME_ACTION_DONE);
        input.setFilters(new InputFilter[]{new InputFilter.LengthFilter(3)});
        input.setPadding(dp(4), 0, dp(4), 0);
        input.setBackground(N.round(N.DGRAY, 10, this));
        inputs[index] = input;
        LinearLayout.LayoutParams inputLp = new LinearLayout.LayoutParams(dp(62), dp(38));
        inputLp.leftMargin = dp(8);
        row.addView(input, inputLp);

        TextView dpLabel = new TextView(this);
        dpLabel.setText("dp");
        dpLabel.setTextColor(N.WHITE);
        dpLabel.setTextSize(13);
        dpLabel.setGravity(Gravity.CENTER_VERTICAL | Gravity.END);
        LinearLayout.LayoutParams unitLp = new LinearLayout.LayoutParams(dp(28), -1);
        unitLp.leftMargin = dp(4);
        row.addView(dpLabel, unitLp);

        seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                if (!fromUser || syncing) return;
                values[index] = progress;
                syncing = true;
                input.setText(format(progress));
                syncing = false;
                updatePreview();
            }
            @Override public void onStartTrackingTouch(SeekBar seekBar) { }
            @Override public void onStopTrackingTouch(SeekBar seekBar) { }
        });

        input.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) { }
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) { }
            @Override public void afterTextChanged(Editable e) {
                if (syncing) return;
                String raw = e.toString().trim();
                if (raw.isEmpty()) return;
                int value;
                try { value = Integer.parseInt(raw); }
                catch (NumberFormatException ex) { return; }
                value = Math.max(0, Math.min(MAX_DP, value));
                values[index] = value;
                syncing = true;
                seek.setProgress(value);
                syncing = false;
                updatePreview();
            }
        });

        input.setOnFocusChangeListener((v, hasFocus) -> {
            if (hasFocus) {
                input.selectAll();
            } else {
                syncing = true;
                input.setText(format(values[index]));
                syncing = false;
            }
        });
        input.setOnEditorActionListener((v, actionId, event) -> {
            if (actionId == EditorInfo.IME_ACTION_DONE) {
                input.clearFocus();
                InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
                if (imm != null) imm.hideSoftInputFromWindow(input.getWindowToken(), 0);
                applyImmersive();
                return true;
            }
            return false;
        });

        return row;
    }

    private void updatePreview() {
        if (previewHost == null || previewRect == null) return;
        int w = previewHost.getWidth();
        int h = previewHost.getHeight();
        if (w <= 0 || h <= 0) return;

        int top = dp(values[0]);
        int bottom = dp(values[1]);
        int left = dp(values[2]);
        int right = dp(values[3]);
        int min = dp(MIN_PREVIEW_DP);

        int visualLeft = Math.min(left, Math.max(0, w - min));
        int visualTop = Math.min(top, Math.max(0, h - min));
        int width = Math.max(min, w - visualLeft - Math.min(right, Math.max(0, w - visualLeft - min)));
        int height = Math.max(min, h - visualTop - Math.min(bottom, Math.max(0, h - visualTop - min)));

        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(width, height);
        lp.leftMargin = visualLeft;
        lp.topMargin = visualTop;
        previewRect.setLayoutParams(lp);
    }

    private String format(int value) {
        return String.format(Locale.US, "%03d", value);
    }

    private int dp(float value) {
        return N.dp(this, value);
    }
}
