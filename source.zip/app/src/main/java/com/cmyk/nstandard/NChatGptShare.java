package com.cmyk.nstandard;

import android.app.Activity;
import android.content.ClipData;
import android.content.Intent;
import android.content.res.AssetManager;
import android.net.Uri;
import android.widget.Toast;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

/**
 * Exports ChatGPT canonical packages from the top page. Most items export source snapshots;
 * color settings and margins intentionally export teaching material for their current/default rules.
 */
final class NChatGptShare {
    private static final String ROOT = "chatgpt_source";

    private NChatGptShare() {}

    static void share(Activity activity, String id, String label) {
        try {
            File dir = new File(activity.getCacheDir(), "icon-share");
            if (!dir.exists() && !dir.mkdirs()) throw new IllegalStateException("共有フォルダを作成できません");
            String stamp = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(new Date());
            File zip = new File(dir, "NStandard_" + id + "_ChatGPT_" + stamp + ".zip");
            boolean teachingMaterial = "color_settings".equals(id) || "margin".equals(id);

            try (ZipOutputStream out = new ZipOutputStream(new FileOutputStream(zip))) {
                String version = BuildConfig.VERSION_NAME + " (" + BuildConfig.VERSION_CODE + ")";
                if (teachingMaterial) {
                    String material = "color_settings".equals(id)
                            ? NColorSettingsActivity.buildDefaultPaletteTeachingMaterial(activity)
                            : NMarginActivity.buildDefaultMarginTeachingMaterial();
                    writeText(out, "SHARE_INSTRUCTION.txt",
                            "【重要：この共有内容を現在の正本として扱ってください】\n" +
                            "対象: N Standard / " + label + "\n" +
                            "Version: " + version + "\n" +
                            "applicationId: " + BuildConfig.APPLICATION_ID + "\n\n" +
                            "このZIPは実装ソースではなく、N Standardの規定値をChatGPTへ教えるための教材です。\n" +
                            "TEACHING_MATERIAL.md の値・名称・順序を正本として扱ってください。\n" +
                            "過去の説明と矛盾する場合は、この教材を優先してください。\n");
                    writeText(out, "TEACHING_MATERIAL.md", material);
                } else {
                    writeText(out, "SHARE_INSTRUCTION.txt",
                            "【重要：この共有内容を現在の正本として扱ってください】\n" +
                            "対象: N Standard / " + label + "\n" +
                            "Version: " + version + "\n" +
                            "applicationId: " + BuildConfig.APPLICATION_ID + "\n\n" +
                            "このZIP内の sources/ を、この項目のChatGPT用正本として扱ってください。\n" +
                            "過去の同項目の実装や古いsource.zipと矛盾する場合は、このZIPを優先してください。\n" +
                            "移植時は見た目・寸法・配色・操作挙動を勝手に変更しないでください。\n");
                    writeText(out, "COMPONENT.md",
                            "# N Standard ChatGPT用正本\n\n" +
                            "- 項目: " + label + "\n" +
                            "- ID: " + id + "\n" +
                            "- N Standard: " + version + "\n" +
                            "- applicationId: " + BuildConfig.APPLICATION_ID + "\n" +
                            "- source directory: sources/\n");
                    copyAssetTree(activity.getAssets(), ROOT + "/" + id, "sources", out);
                }
            }

            Uri uri = Uri.parse("content://" + activity.getPackageName() + ".share/" + Uri.encode(zip.getName()));
            Intent share = new Intent(Intent.ACTION_SEND);
            share.setType("application/zip");
            share.putExtra(Intent.EXTRA_STREAM, uri);
            share.putExtra(Intent.EXTRA_TEXT, teachingMaterial
                    ? "N Standard「" + label + "」の規定値を教えるChatGPT用教材です。"
                    : "N Standard「" + label + "」のChatGPT用正本です。ZIP内を現在の正本として扱ってください。");
            share.setClipData(ClipData.newRawUri("N Standard ChatGPT canonical", uri));
            share.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            activity.startActivity(Intent.createChooser(share, label + (teachingMaterial ? "の教材を共有" : "の正本を共有")));
            DiagLog.write(activity, "CHATGPT_CANONICAL_SHARE id=" + id + " label=" + label + " teaching=" + teachingMaterial);
        } catch (Exception e) {
            DiagLog.write(activity, "CHATGPT_CANONICAL_SHARE_ERROR id=" + id + " " +
                    e.getClass().getSimpleName() + ": " + e.getMessage());
            Toast.makeText(activity, "ChatGPT用共有データの作成に失敗しました", Toast.LENGTH_SHORT).show();
        }
    }

    private static void copyAssetTree(AssetManager assets, String assetPath, String zipPath,
                                      ZipOutputStream out) throws Exception {
        String[] children = assets.list(assetPath);
        if (children == null) throw new IllegalStateException("正本ソースがありません: " + assetPath);
        if (children.length == 0) {
            try (InputStream in = assets.open(assetPath)) {
                out.putNextEntry(new ZipEntry(zipPath));
                byte[] buffer = new byte[8192];
                int read;
                while ((read = in.read(buffer)) >= 0) out.write(buffer, 0, read);
                out.closeEntry();
            }
            return;
        }
        for (String child : children) {
            String childAsset = assetPath + "/" + child;
            String childZip = zipPath + "/" + child;
            copyAssetTree(assets, childAsset, childZip, out);
        }
    }

    private static void writeText(ZipOutputStream out, String name, String value) throws Exception {
        out.putNextEntry(new ZipEntry(name));
        out.write(value.getBytes(StandardCharsets.UTF_8));
        out.closeEntry();
    }
}
