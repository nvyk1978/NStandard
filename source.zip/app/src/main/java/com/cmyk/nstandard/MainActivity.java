package com.cmyk.nstandard;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    private static final int REQ_FOLDER = 2001;

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        DiagLog.write(this, "APP_START");
        buildUi();
    }

    private void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(N.dp(this, N.PAGE_SIDE_MARGIN_DP), N.dp(this, N.PAGE_TITLE_TOP_DP),
                N.dp(this, N.PAGE_SIDE_MARGIN_DP), N.dp(this, N.PAGE_BOTTOM_MARGIN_DP));
        root.setBackgroundColor(N.BG);

        TextView title = new TextView(this);
        title.setText("N Standard");
        title.setTextColor(N.WHITE);
        title.setTextSize(25);
        title.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        title.setGravity(Gravity.START | Gravity.CENTER_VERTICAL);
        root.addView(title, new LinearLayout.LayoutParams(-1, N.dp(this, 52)));
        addSpacer(root, 18);

        addMainButton(root, "エクスプローラ", "explorer", () -> {
            DiagLog.write(this, "OPEN_EXPLORER");
            Intent i = new Intent(this, NExplorerActivity.class);
            i.putExtra(NExplorerActivity.EXTRA_TITLE, "エクスプローラ");
            i.putExtra(NExplorerActivity.EXTRA_CONFIRM_LABEL, "このフォルダを選択");
            startActivityForResult(i, REQ_FOLDER);
        });

        addMainButton(root, "ダイアログ", "dialog", () -> {
            DiagLog.write(this, "OPEN_DIALOG_PRODUCT_EDITOR");
            NProductEditorDialog.EditorData data = new NProductEditorDialog.EditorData();
            data.name = "サンプル商品";
            data.price = 500;
            data.volume = 350;
            data.productKey = "prd.サンプル商品.350";
            data.priceType = "税込";
            data.tags.add("ビール");
            NProductEditorDialog.show(this, data,
                    () -> Toast.makeText(this, "保存しました（見本）", Toast.LENGTH_SHORT).show(),
                    () -> Toast.makeText(this, "削除しました（見本）", Toast.LENGTH_SHORT).show());
        });

        // Property belongs directly under the dialog sample.
        addMainButton(root, "プロパティ", "property", () -> {
            DiagLog.write(this, "OPEN_PROPERTY_BOOKMARK_DIALOG");
            NBookmarkPropertyDialog.show(this);
        });

        // Overflow sample belongs directly above the diagnostic-log sample.
        addMainButton(root, "三点リーダー", "overflow", () -> {
            DiagLog.write(this, "OPEN_OVERFLOW_DIALOG");
            NOverflowDialog.show(this,
                    new String[]{"リスト1", "リスト2", "リスト3", "リスト4", "リスト5"},
                    which -> {
                        DiagLog.write(this, "OVERFLOW_DIALOG_SELECT index=" + which);
                        Toast.makeText(this, "リスト" + (which + 1), Toast.LENGTH_SHORT).show();
                    });
        });

        addMainButton(root, "診断ログ", "diagnostic", () -> {
            DiagLog.write(this, "OPEN_DIAGNOSTIC_LOG");
            NDiagnosticLog.show(this);
        });

        addMainButton(root, "グリップ付きリスト", "grip_list", () -> {
            DiagLog.write(this, "OPEN_STORE_LIST");
            startActivity(new Intent(this, NStoreCellActivity.class));
        });

        addMainButton(root, "商品リスト", "product_list", () -> {
            DiagLog.write(this, "OPEN_PRODUCT_LIST");
            Intent i = new Intent(this, NProductListActivity.class);
            i.putExtra(NProductListActivity.EXTRA_TITLE, "商品リスト");
            startActivity(i);
        });

        addMainButton(root, "マージン", "margin", () -> {
            DiagLog.write(this, "OPEN_MARGIN_PREVIEW");
            startActivity(new Intent(this, NMarginActivity.class));
        });

        addMainButton(root, "カラー設定", "color_settings", () -> {
            DiagLog.write(this, "OPEN_COLOR_SETTINGS");
            startActivity(new Intent(this, NColorSettingsActivity.class));
        });

        addMainButton(root, "アイコン見本", "icon_sample", () -> {
            DiagLog.write(this, "OPEN_ICON_SAMPLE");
            startActivity(new Intent(this, NIconSampleActivity.class));
        });

        addMainButton(root, "ボタン見本", "button_sample", () -> {
            DiagLog.write(this, "OPEN_BUTTON_SAMPLE");
            startActivity(new Intent(this, NButtonSampleActivity.class));
        });

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(N.BG);
        scroll.addView(root, new ScrollView.LayoutParams(-1, -2));
        setContentView(scroll);
    }

    private void addMainButton(LinearLayout root, String label, String canonicalId, Runnable action) {
        if (root.getChildCount() > 2) addSpacer(root, 18);

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);

        TextView button = new TextView(this);
        button.setText(label);
        button.setTextColor(N.TEXT);
        button.setTextSize(16);
        button.setGravity(Gravity.CENTER);
        button.setBackground(N.round(N.LBLUE, 24, this));
        button.setClickable(true);
        button.setFocusable(true);
        button.setOnClickListener(v -> action.run());
        row.addView(button, new LinearLayout.LayoutParams(0, N.dp(this, 48), 1f));

        ShareIconView share = new ShareIconView();
        share.setContentDescription(label + "のChatGPT用正本を共有");
        share.setOnClickListener(v -> NChatGptShare.share(this, canonicalId, label));
        LinearLayout.LayoutParams shareLp = new LinearLayout.LayoutParams(N.dp(this, 42), N.dp(this, 42));
        shareLp.leftMargin = N.dp(this, 8);
        row.addView(share, shareLp);

        root.addView(row, new LinearLayout.LayoutParams(-1, N.dp(this, 48)));
    }

    private void addSpacer(LinearLayout root, int dp) {
        root.addView(new View(this), new LinearLayout.LayoutParams(1, N.dp(this, dp)));
    }

    /** Round N-dark-gray share control for ChatGPT canonical source packages. */
    private final class ShareIconView extends View {
        private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint line = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint node = new Paint(Paint.ANTI_ALIAS_FLAG);

        ShareIconView() {
            super(MainActivity.this);
            setClickable(true);
            setFocusable(true);
            fill.setColor(N.DGRAY);
            fill.setStyle(Paint.Style.FILL);
            line.setColor(Color.WHITE);
            line.setStyle(Paint.Style.STROKE);
            line.setStrokeCap(Paint.Cap.ROUND);
            line.setStrokeJoin(Paint.Join.ROUND);
            node.setColor(Color.WHITE);
            node.setStyle(Paint.Style.FILL);
        }

        @Override protected void onDraw(Canvas c) {
            float w = getWidth(), h = getHeight();
            float size = Math.min(w, h);
            float cx = w / 2f, cy = h / 2f;
            c.drawCircle(cx, cy, size * .5f, fill);
            float x1 = cx - size * .18f, y1 = cy;
            float x2 = cx + size * .18f, y2 = cy - size * .18f;
            float x3 = cx + size * .18f, y3 = cy + size * .18f;
            line.setStrokeWidth(Math.max(2f, size * .065f));
            c.drawLine(x1, y1, x2, y2, line);
            c.drawLine(x1, y1, x3, y3, line);
            float r = size * .105f;
            c.drawCircle(x1, y1, r, node);
            c.drawCircle(x2, y2, r, node);
            c.drawCircle(x3, y3, r, node);
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_FOLDER && resultCode == RESULT_OK && data != null) {
            String path = data.getStringExtra(NExplorerActivity.RESULT_PATH);
            DiagLog.write(this, "EXPLORER_RESULT path=" + (path == null ? "" : path));
            Toast.makeText(this, path == null ? "選択しました" : path, Toast.LENGTH_LONG).show();
        }
    }
}
