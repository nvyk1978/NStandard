package com.cmyk.nstandard;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    private static final int REQ_FOLDER = 2001;

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        buildUi();
    }

    private void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(N.dp(this, 25), N.dp(this, 28), N.dp(this, 25), N.dp(this, 24));
        root.setBackgroundColor(N.BG);

        TextView title = new TextView(this);
        title.setText("N Standard");
        title.setTextColor(N.TEXT);
        title.setTextSize(24);
        title.setGravity(Gravity.START | Gravity.CENTER_VERTICAL);
        LinearLayout.LayoutParams titleParams = new LinearLayout.LayoutParams(-1, N.dp(this, 52));
        titleParams.topMargin = N.dp(this, 50);
        root.addView(title, titleParams);

        View spacer = new View(this);
        root.addView(spacer, new LinearLayout.LayoutParams(1, N.dp(this, 18)));

        TextView explorer = new TextView(this);
        explorer.setText("Nエクスプローラ");
        explorer.setTextColor(N.TEXT);
        explorer.setTextSize(16);
        explorer.setGravity(Gravity.CENTER);
        explorer.setBackground(N.round(N.LBLUE, 24, this));
        explorer.setClickable(true);
        explorer.setFocusable(true);
        explorer.setOnClickListener(v -> {
            Intent i = new Intent(this, NExplorerActivity.class);
            i.putExtra(NExplorerActivity.EXTRA_TITLE, "Nエクスプローラ");
            i.putExtra(NExplorerActivity.EXTRA_CONFIRM_LABEL, "このフォルダを選択");
            startActivityForResult(i, REQ_FOLDER);
        });
        root.addView(explorer, new LinearLayout.LayoutParams(-1, N.dp(this, 48)));

        setContentView(root);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_FOLDER && resultCode == RESULT_OK && data != null) {
            String path = data.getStringExtra(NExplorerActivity.RESULT_PATH);
            Toast.makeText(this, path == null ? "選択しました" : path, Toast.LENGTH_LONG).show();
        }
    }
}
