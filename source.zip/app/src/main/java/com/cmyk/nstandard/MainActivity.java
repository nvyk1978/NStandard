package com.cmyk.nstandard;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    private static final int REQ_FOLDER = 2001;

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        DiagLog.write(this, "APP_START");
        buildUi();
    }

    private void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(N.dp(this, 25), N.dp(this, 28), N.dp(this, 25), N.dp(this, 24));
        root.setBackgroundColor(N.BG);

        TextView title = new TextView(this);
        title.setText("N Standard");
        title.setTextColor(N.TEXT);
        title.setTextSize(24);
        title.setGravity(Gravity.START | Gravity.CENTER_VERTICAL);
        LinearLayout.LayoutParams titleParams = new LinearLayout.LayoutParams(-1, N.dp(this, 52));
        titleParams.topMargin = N.dp(this, 50);
        root.addView(title, titleParams);

        View spacer = new View(this);
        root.addView(spacer, new LinearLayout.LayoutParams(1, N.dp(this, 18)));

        TextView explorer = new TextView(this);
        explorer.setText("エクスプローラ");
        explorer.setTextColor(N.TEXT);
        explorer.setTextSize(16);
        explorer.setGravity(Gravity.CENTER);
        explorer.setBackground(N.round(N.LBLUE, 24, this));
        explorer.setClickable(true);
        explorer.setFocusable(true);
        explorer.setOnClickListener(v -> {
            DiagLog.write(this, "OPEN_EXPLORER");
            Intent i = new Intent(this, NExplorerActivity.class);
            i.putExtra(NExplorerActivity.EXTRA_TITLE, "エクスプローラ");
            i.putExtra(NExplorerActivity.EXTRA_CONFIRM_LABEL, "このフォルダを選択");
            startActivityForResult(i, REQ_FOLDER);
        });
        root.addView(explorer, new LinearLayout.LayoutParams(-1, N.dp(this, 48)));

        View dialogSpacer = new View(this);
        root.addView(dialogSpacer, new LinearLayout.LayoutParams(1, N.dp(this, 18)));

        TextView dialogButton = new TextView(this);
        dialogButton.setText("ダイアログ");
        dialogButton.setTextColor(N.TEXT);
        dialogButton.setTextSize(16);
        dialogButton.setGravity(Gravity.CENTER);
        dialogButton.setBackground(N.round(N.LBLUE, 24, this));
        dialogButton.setClickable(true);
        dialogButton.setFocusable(true);
        dialogButton.setOnClickListener(v -> {
            DiagLog.write(this, "OPEN_DIALOG_SAMPLES");
            NDialog.showChoices(
                this,
                "ダイアログ",
                new String[]{"通常", "メニュー", "メッセージ", "入力"},
                -1,
                which -> {
                    if (which == 0) {
                        NDialog.showChoices(this, "選択ダイアログ",
                                new String[]{"項目1", "項目2", "削除"}, 2, null);
                    } else if (which == 1) {
                        NDialog.showPlainMenu(this, "メニュー",
                                new String[]{"項目1", "項目2", "項目3"}, null);
                    } else if (which == 2) {
                        NDialog.showMessage(this, "メッセージ",
                                "BookmarkLauncherから抽出したNダイアログの表示見本です。");
                    } else if (which == 3) {
                        NDialog.showInput(this, "入力", "テキスト", "", false, "保存",
                                text -> Toast.makeText(this, text.isEmpty() ? "未入力" : text, Toast.LENGTH_SHORT).show());
                    }
                });
        });
        root.addView(dialogButton, new LinearLayout.LayoutParams(-1, N.dp(this, 48)));

        View logSpacer = new View(this);
        root.addView(logSpacer, new LinearLayout.LayoutParams(1, N.dp(this, 18)));

        TextView logButton = new TextView(this);
        logButton.setText("診断ログ");
        logButton.setTextColor(N.TEXT);
        logButton.setTextSize(16);
        logButton.setGravity(Gravity.CENTER);
        logButton.setBackground(N.round(N.LBLUE, 24, this));
        logButton.setClickable(true);
        logButton.setFocusable(true);
        logButton.setOnClickListener(v -> {
            DiagLog.write(this, "OPEN_DIAGNOSTIC_LOG");
            NDiagnosticLog.show(this);
        });
        root.addView(logButton, new LinearLayout.LayoutParams(-1, N.dp(this, 48)));

        View thumbnailSpacer = new View(this);
        root.addView(thumbnailSpacer, new LinearLayout.LayoutParams(1, N.dp(this, 18)));

        TextView thumbnailButton = new TextView(this);
        thumbnailButton.setText("店舗セル");
        thumbnailButton.setTextColor(N.TEXT);
        thumbnailButton.setTextSize(16);
        thumbnailButton.setGravity(Gravity.CENTER);
        thumbnailButton.setBackground(N.round(N.LBLUE, 24, this));
        thumbnailButton.setClickable(true);
        thumbnailButton.setFocusable(true);
        thumbnailButton.setOnClickListener(v -> {
            DiagLog.write(this, "OPEN_STORE_CELL");
            startActivity(new Intent(this, NStoreCellActivity.class));
        });
        root.addView(thumbnailButton, new LinearLayout.LayoutParams(-1, N.dp(this, 48)));

        View overflowSpacer = new View(this);
        root.addView(overflowSpacer, new LinearLayout.LayoutParams(1, N.dp(this, 18)));

        TextView overflowButton = new TextView(this);
        overflowButton.setText("三点リーダー");
        overflowButton.setTextColor(N.TEXT);
        overflowButton.setTextSize(16);
        overflowButton.setGravity(Gravity.CENTER);
        overflowButton.setBackground(N.round(N.LBLUE, 24, this));
        overflowButton.setClickable(true);
        overflowButton.setFocusable(true);
        overflowButton.setOnClickListener(v -> {
            DiagLog.write(this, "OPEN_OVERFLOW_DIALOG");
            NOverflowDialog.show(this,
                    new String[]{"リスト1", "リスト2", "リスト3", "リスト4", "リスト5"},
                    which -> {
                        DiagLog.write(this, "OVERFLOW_DIALOG_SELECT index=" + which);
                        Toast.makeText(this, "リスト" + (which + 1), Toast.LENGTH_SHORT).show();
                    });
        });
        root.addView(overflowButton, new LinearLayout.LayoutParams(-1, N.dp(this, 48)));

        setContentView(root);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_FOLDER && resultCode == RESULT_OK && data != null) {
            String path = data.getStringExtra(NExplorerActivity.RESULT_PATH);
            DiagLog.write(this, "EXPLORER_RESULT path=" + (path == null ? "" : path));
            Toast.makeText(this, path == null ? "選択しました" : path, Toast.LENGTH_LONG).show();
        }
    }
}
