package com.cmyk.nstandard;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    private static final int REQ_FOLDER = 2001;

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        DiagLog.write(this, "APP_START");
        buildUi();
    }

    private void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(N.dp(this, 25), N.dp(this, N.PAGE_TITLE_TOP_DP), N.dp(this, 25), N.dp(this, 24));
        root.setBackgroundColor(N.BG);

        TextView title = new TextView(this);
        title.setText("N Standard");
        title.setTextColor(N.WHITE);
        title.setTextSize(25);
        title.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        title.setGravity(Gravity.START | Gravity.CENTER_VERTICAL);
        root.addView(title, new LinearLayout.LayoutParams(-1, N.dp(this, 52)));
        addSpacer(root, 18);

        addMainButton(root, "エクスプローラ", () -> {
            DiagLog.write(this, "OPEN_EXPLORER");
            Intent i = new Intent(this, NExplorerActivity.class);
            i.putExtra(NExplorerActivity.EXTRA_TITLE, "エクスプローラ");
            i.putExtra(NExplorerActivity.EXTRA_CONFIRM_LABEL, "このフォルダを選択");
            startActivityForResult(i, REQ_FOLDER);
        });

        addMainButton(root, "ダイアログ", () -> {
            DiagLog.write(this, "OPEN_DIALOG_PRODUCT_EDITOR");
            NProductEditorDialog.EditorData data = new NProductEditorDialog.EditorData();
            data.name = "サンプル商品";
            data.price = 500;
            data.volume = 350;
            data.productKey = "prd.サンプル商品.350";
            data.priceType = "税込";
            data.tags.add("ビール");
            NProductEditorDialog.show(this, data,
                    () -> Toast.makeText(this, "保存しました（見本）", Toast.LENGTH_SHORT).show(),
                    () -> Toast.makeText(this, "削除しました（見本）", Toast.LENGTH_SHORT).show());
        });

        // Property belongs directly under the dialog sample.
        addMainButton(root, "プロパティ", () -> {
            DiagLog.write(this, "OPEN_PROPERTY_BOOKMARK_DIALOG");
            NBookmarkPropertyDialog.show(this);
        });

        // Overflow sample belongs directly above the diagnostic-log sample.
        addMainButton(root, "三点リーダー", () -> {
            DiagLog.write(this, "OPEN_OVERFLOW_DIALOG");
            NOverflowDialog.show(this,
                    new String[]{"リスト1", "リスト2", "リスト3", "リスト4", "リスト5"},
                    which -> {
                        DiagLog.write(this, "OVERFLOW_DIALOG_SELECT index=" + which);
                        Toast.makeText(this, "リスト" + (which + 1), Toast.LENGTH_SHORT).show();
                    });
        });

        addMainButton(root, "診断ログ", () -> {
            DiagLog.write(this, "OPEN_DIAGNOSTIC_LOG");
            NDiagnosticLog.show(this);
        });

        addMainButton(root, "グリップ付きリスト", () -> {
            DiagLog.write(this, "OPEN_STORE_LIST");
            startActivity(new Intent(this, NStoreCellActivity.class));
        });

        addMainButton(root, "商品リスト", () -> {
            DiagLog.write(this, "OPEN_PRODUCT_LIST");
            Intent i = new Intent(this, NProductListActivity.class);
            i.putExtra(NProductListActivity.EXTRA_TITLE, "商品リスト");
            startActivity(i);
        });

        addMainButton(root, "マージン", () -> {
            DiagLog.write(this, "OPEN_MARGIN_PREVIEW");
            startActivity(new Intent(this, NMarginActivity.class));
        });

        addMainButton(root, "カラー設定", () -> {
            DiagLog.write(this, "OPEN_COLOR_SETTINGS");
            startActivity(new Intent(this, NColorSettingsActivity.class));
        });

        addMainButton(root, "アイコン見本", () -> {
            DiagLog.write(this, "OPEN_ICON_SAMPLE");
            startActivity(new Intent(this, NIconSampleActivity.class));
        });

        addMainButton(root, "ボタン見本", () -> {
            DiagLog.write(this, "OPEN_BUTTON_SAMPLE");
            startActivity(new Intent(this, NButtonSampleActivity.class));
        });

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(N.BG);
        scroll.addView(root, new ScrollView.LayoutParams(-1, -2));
        setContentView(scroll);
    }

    private void addMainButton(LinearLayout root, String label, Runnable action) {
        if (root.getChildCount() > 2) addSpacer(root, 18);
        TextView button = new TextView(this);
        button.setText(label);
        button.setTextColor(N.TEXT);
        button.setTextSize(16);
        button.setGravity(Gravity.CENTER);
        button.setBackground(N.round(N.LBLUE, 24, this));
        button.setClickable(true);
        button.setFocusable(true);
        button.setOnClickListener(v -> action.run());
        root.addView(button, new LinearLayout.LayoutParams(-1, N.dp(this, 48)));
    }

    private void addSpacer(LinearLayout root, int dp) {
        root.addView(new View(this), new LinearLayout.LayoutParams(1, N.dp(this, dp)));
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_FOLDER && resultCode == RESULT_OK && data != null) {
            String path = data.getStringExtra(NExplorerActivity.RESULT_PATH);
            DiagLog.write(this, "EXPLORER_RESULT path=" + (path == null ? "" : path));
            Toast.makeText(this, path == null ? "選択しました" : path, Toast.LENGTH_LONG).show();
        }
    }
}
