package com.cmyk.nstandard;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Insets;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.DragEvent;
import android.view.Gravity;
import android.view.HapticFeedbackConstants;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowInsets;
import android.view.inputmethod.EditorInfo;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import android.view.animation.DecelerateInterpolator;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

/**
 * Price Rec. store-screen reference transplanted into N Standard.
 *
 * This screen intentionally keeps the Price Rec. layout/interaction model while
 * replacing production DB/media work with local demo state so it can be used as
 * a self-contained UI/behaviour reference.
 */
public final class NStoreCellActivity extends Activity {
    private static final int BG = Color.parseColor("#303030");
    private static final int DGRAY = Color.parseColor("#252020");
    private static final int GRAY = Color.parseColor("#454040");
    private static final int LGRAY = Color.parseColor("#656060");
    private static final int BLUE = Color.parseColor("#223355");
    private static final int LBLUE = Color.parseColor("#445577");
    private static final int RED = Color.parseColor("#441100");
    private static final int ORANGE = Color.parseColor("#775500");
    private static final int WHITE = Color.WHITE;
    private static final int NWHITE = Color.parseColor("#A9A999");
    private static final int SECONDARY = NWHITE;
    private static final int CHECK_GREEN = Color.parseColor("#227733");

    private static final int UI_SCREEN_MARGIN_DP = 14;
    private static final int UI_CARD_MARGIN_DP = 12;
    private static final int UI_DIALOG_MARGIN_DP = 14;
    private static final int UI_DIALOG_EDGE_MARGIN_DP = 14;
    private static final int UI_SPACING_DP = 8;
    private static final int UI_TIGHT_SPACING_DP = 4;
    private static final int UI_ACTION_GAP_DP = 5;

    private final List<DemoStore> stores = new ArrayList<>();
    private final Set<Long> expandedStoreIds = new HashSet<>();
    private final Map<Long, LinearLayout> storeCardViews = new HashMap<>();
    private final Map<Long, LinearLayout> storeDetailViews = new HashMap<>();
    private final List<String> searchCandidates = new ArrayList<>();
    private final Set<String> selectedSearchCandidates = new HashSet<>();

    private LinearLayout storeContainer;
    private ScrollView storeScroll;
    private EditText searchInput;
    private LinearLayout searchCandidateRow;
    private LinearLayout searchCandidateChips;
    private TextView searchCandidateDelete;
    private boolean searchCandidateSelectionMode;

    private long nextStoreId = 1L;
    private long nextPhotoId = 1L;
    private long photoSelectionStoreId = -1L;
    private final Set<Long> selectedPhotoIds = new HashSet<>();

    private View draggingStoreCard;
    private long draggingStoreId = -1L;
    private int draggingStoreSourceIndex = -1;
    private int draggingStoreTargetIndex = -1;
    private float draggingStoreGrabOffsetY;
    private int draggingStoreSlotHeight;
    private boolean draggingStoreDropCommitted;

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        DiagLog.write(this, "OPEN_PRICEREC_STORE_REFERENCE");
        seedDemoStores();
        setContentView(buildUi());
    }

    private void seedDemoStores() {
        DemoStore a = new DemoStore(nextStoreId++, "店舗名", true, true);
        for (int i = 0; i < 6; i++) a.photos.add(new DemoPhoto(nextPhotoId++, "タグ" + ((i % 3) + 1), i % 2 == 0));
        DemoStore b = new DemoStore(nextStoreId++, "店舗 02", true, false);
        for (int i = 0; i < 3; i++) b.photos.add(new DemoPhoto(nextPhotoId++, "タグなし", i == 0));
        DemoStore c = new DemoStore(nextStoreId++, "店舗 03", false, true);
        stores.add(a);
        stores.add(b);
        stores.add(c);
    }

    private View buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(BG);
        root.setPadding(dp(UI_SCREEN_MARGIN_DP), dp(N.PAGE_TITLE_TOP_DP), dp(UI_SCREEN_MARGIN_DP), dp(UI_SPACING_DP));
        root.setOnApplyWindowInsetsListener((v, insets) -> {
            int top = 0;
            int bottom = 0;
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                Insets bars = insets.getInsets(WindowInsets.Type.systemBars());
                Insets ime = insets.getInsets(WindowInsets.Type.ime());
                top = bars.top;
                bottom = Math.max(bars.bottom, ime.bottom);
            } else {
                top = insets.getSystemWindowInsetTop();
                bottom = insets.getSystemWindowInsetBottom();
            }
            v.setPadding(dp(UI_SCREEN_MARGIN_DP), top + dp(N.PAGE_TITLE_TOP_DP),
                    dp(UI_SCREEN_MARGIN_DP), bottom + dp(UI_SPACING_DP));
            return insets;
        });

        LinearLayout titleRow = new LinearLayout(this);
        titleRow.setGravity(Gravity.CENTER_VERTICAL);
        titleRow.setPadding(0, 0, 0, dp(UI_SPACING_DP));

        TextView title = text("グリップ付きリスト", 25, NWHITE, true);
        title.setGravity(Gravity.CENTER_VERTICAL);
        title.setIncludeFontPadding(false);
        title.setContentDescription("展開中のカードをすべて閉じる");
        title.setOnClickListener(v -> collapseAllExpandedStores());
        titleRow.addView(title, new LinearLayout.LayoutParams(0, dp(48), 1f));

        TextView menu = text("⋮", 26, NWHITE, true);
        menu.setGravity(Gravity.CENTER);
        menu.setIncludeFontPadding(false);
        menu.setBackground(circle(DGRAY));
        menu.setContentDescription("アプリメニュー");
        menu.setOnClickListener(v -> showReferenceMenu());
        titleRow.addView(menu, new LinearLayout.LayoutParams(dp(48), dp(48)));
        root.addView(titleRow);

        storeScroll = new ScrollView(this);
        storeScroll.setVerticalScrollBarEnabled(false);
        storeScroll.setFillViewport(true);
        storeContainer = new LinearLayout(this);
        storeContainer.setOrientation(LinearLayout.VERTICAL);
        storeScroll.addView(storeContainer, new ScrollView.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        storeScroll.setOnDragListener(this::handleStoreScrollDrag);
        root.addView(storeScroll, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        root.addView(makeBottomBar());
        reloadStores();
        root.requestApplyInsets();
        return root;
    }

    private View makeBottomBar() {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(0, dp(UI_SPACING_DP), 0, 0);

        searchCandidateRow = new LinearLayout(this);
        searchCandidateRow.setGravity(Gravity.CENTER_VERTICAL);
        searchCandidateRow.setPadding(0, 0, 0, dp(UI_SPACING_DP));

        HorizontalScrollView candidateScroll = new HorizontalScrollView(this);
        candidateScroll.setHorizontalScrollBarEnabled(false);
        candidateScroll.setFillViewport(false);
        searchCandidateChips = new LinearLayout(this);
        searchCandidateChips.setOrientation(LinearLayout.HORIZONTAL);
        searchCandidateChips.setGravity(Gravity.CENTER_VERTICAL);
        candidateScroll.addView(searchCandidateChips, new HorizontalScrollView.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, dp(36)));
        searchCandidateRow.addView(candidateScroll, new LinearLayout.LayoutParams(0, dp(36), 1f));

        searchCandidateDelete = button("削除", RED, 13);
        searchCandidateDelete.setVisibility(View.GONE);
        searchCandidateDelete.setOnClickListener(v -> deleteSelectedSearchCandidates());
        LinearLayout.LayoutParams deleteLp = new LinearLayout.LayoutParams(dp(72), dp(36));
        deleteLp.leftMargin = dp(8);
        searchCandidateRow.addView(searchCandidateDelete, deleteLp);
        box.addView(searchCandidateRow, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);

        searchInput = new EditText(this);
        searchInput.setSingleLine(true);
        searchInput.setTextColor(DGRAY);
        searchInput.setTextSize(16);
        searchInput.setHint("商品名検索");
        searchInput.setHintTextColor(GRAY);
        searchInput.setGravity(Gravity.CENTER_VERTICAL);
        searchInput.setIncludeFontPadding(false);
        searchInput.setPadding(dp(16), 0, dp(16), 0);
        searchInput.setBackground(roundRect(NWHITE, 999));
        searchInput.setImeOptions(EditorInfo.IME_ACTION_SEARCH);
        searchInput.setOnFocusChangeListener((v, focused) -> searchInput.setBackground(roundRect(NWHITE, 999)));
        searchInput.setOnEditorActionListener((v, actionId, event) -> {
            if (actionId == EditorInfo.IME_ACTION_SEARCH) {
                runSearch(searchInput.getText().toString());
                return true;
            }
            return false;
        });
        LinearLayout.LayoutParams searchLp = new LinearLayout.LayoutParams(0, dp(48), 1f);
        searchLp.rightMargin = dp(12);
        row.addView(productSearchInputHolder(searchInput), searchLp);

        ImageView add = roundPlusIcon(LBLUE, NWHITE, "新規店舗");
        add.setOnClickListener(v -> showAddStoreDialog());
        row.addView(add, new LinearLayout.LayoutParams(dp(48), dp(48)));
        box.addView(row, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        refreshSearchCandidates();
        return box;
    }

    private void reloadStores() {
        if (storeContainer == null) return;
        storeCardViews.clear();
        storeDetailViews.clear();
        storeContainer.removeAllViews();
        if (stores.isEmpty()) {
            TextView empty = text("右下の＋から店舗を追加", 16, SECONDARY, false);
            empty.setGravity(Gravity.CENTER);
            empty.setPadding(0, dp(80), 0, 0);
            storeContainer.addView(empty);
            return;
        }
        for (DemoStore store : stores) storeContainer.addView(makeStoreCard(store));
    }

    private View makeStoreCard(DemoStore store) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setBackground(roundRect(GRAY, 18));
        LinearLayout.LayoutParams cardLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        cardLp.bottomMargin = dp(12);
        card.setLayoutParams(cardLp);
        storeCardViews.put(store.id, card);
        card.setTag(Long.valueOf(store.id));

        LinearLayout header = new LinearLayout(this);
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.setPadding(dp(UI_CARD_MARGIN_DP), dp(UI_SPACING_DP),
                dp(UI_CARD_MARGIN_DP), dp(UI_SPACING_DP));

        TextView handle = text("☰", 22, SECONDARY, false);
        handle.setGravity(Gravity.CENTER);
        handle.setContentDescription("店舗を並べ替え");
        final float[] handleTouchY = {dp(24)};
        handle.setOnTouchListener((v, event) -> {
            if (event.getActionMasked() == MotionEvent.ACTION_DOWN ||
                    event.getActionMasked() == MotionEvent.ACTION_MOVE) {
                handleTouchY[0] = event.getY();
            }
            return false;
        });
        handle.setOnLongClickListener(v -> {
            v.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS);
            draggingStoreCard = card;
            draggingStoreId = store.id;
            draggingStoreSourceIndex = storeContainer.indexOfChild(card);
            draggingStoreTargetIndex = draggingStoreSourceIndex;
            draggingStoreGrabOffsetY = header.getTop() + handle.getTop() + handleTouchY[0];
            ViewGroup.MarginLayoutParams mlp = (ViewGroup.MarginLayoutParams) card.getLayoutParams();
            draggingStoreSlotHeight = card.getHeight() + mlp.topMargin + mlp.bottomMargin;
            draggingStoreDropCommitted = false;
            card.setElevation(dp(12));
            card.animate().scaleX(1.015f).scaleY(1.015f).alpha(0.94f).setDuration(90).start();
            DragPayload payload = new DragPayload(store.id);
            ClipData data = ClipData.newPlainText("store_id", String.valueOf(store.id));
            DiagLog.write(this, "STORE_DRAG_START id=" + store.id + " name=" + store.name + " axis=y");
            v.startDragAndDrop(data, new InvisibleDragShadowBuilder(v), payload, 0);
            return true;
        });

        TextView name = text(store.name, 18, store.enabled ? WHITE : LGRAY, true);
        name.setGravity(Gravity.CENTER_VERTICAL);

        header.addView(handle, new LinearLayout.LayoutParams(dp(48), dp(48)));
        header.addView(name, new LinearLayout.LayoutParams(0, dp(48), 1f));
        if (store.mapAnalyzed) {
            StraightCheckBadgeView mapCheck = new StraightCheckBadgeView(this);
            mapCheck.setContentDescription("Googleマップ解析済み");
            LinearLayout.LayoutParams checkLp = new LinearLayout.LayoutParams(dp(22), dp(22));
            checkLp.rightMargin = dp(6);
            header.addView(mapCheck, checkLp);
        }

        FrameLayout toggleHit = new FrameLayout(this);
        toggleHit.setClickable(true);
        toggleHit.setFocusable(true);
        toggleHit.setClipChildren(false);
        toggleHit.setClipToPadding(false);
        toggleHit.setContentDescription(store.enabled ? "Nトグル オン" : "Nトグル オフ");
        NToggleSwitch nToggle = new NToggleSwitch(this);
        nToggle.setChecked(store.enabled);
        nToggle.setNColors(ORANGE, NWHITE);
        nToggle.setContentDescription(store.enabled ? "Nトグル オン" : "Nトグル オフ");
        nToggle.setOnCheckedChangeListener((buttonView, checked) -> {
            if (checked == store.enabled) return;
            store.enabled = checked;
            buttonView.performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK);
            DiagLog.write(this, "STORE_N_TOGGLE id=" + store.id + " enabled=" + checked);
            buttonView.postDelayed(this::reloadStores, 130L);
        });
        toggleHit.addView(nToggle, new FrameLayout.LayoutParams(dp(44), dp(26), Gravity.CENTER));
        toggleHit.setOnClickListener(v -> nToggle.performClick());
        LinearLayout.LayoutParams toggleLp = new LinearLayout.LayoutParams(dp(58), dp(48));
        toggleLp.leftMargin = dp(8);
        header.addView(toggleHit, toggleLp);

        View.OnLongClickListener storeMenuLongPress = v -> {
            if (draggingStoreId >= 0) return true;
            card.setBackground(roundRect(LGRAY, 18));
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                card.performHapticFeedback(HapticFeedbackConstants.CONFIRM);
            } else {
                card.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS);
            }
            DiagLog.write(this, "STORE_MENU_LONG_PRESS id=" + store.id + " name=" + store.name);
            showStoreMenu(store, card);
            return true;
        };
        header.setOnLongClickListener(storeMenuLongPress);
        card.setOnLongClickListener(storeMenuLongPress);
        card.addView(header);

        if (expandedStoreIds.contains(store.id)) {
            LinearLayout details = buildStoreDetails(store);
            card.addView(details);
            storeDetailViews.put(store.id, details);
        }

        header.setOnClickListener(v -> {
            if (draggingStoreId >= 0) return;
            if (expandedStoreIds.contains(store.id)) animateCollapseStore(store.id, null);
            else animateExpandStore(store, card);
        });
        return card;
    }

    private LinearLayout buildStoreDetails(DemoStore store) {
        LinearLayout details = new LinearLayout(this);
        details.setOrientation(LinearLayout.VERTICAL);
        details.setPadding(dp(UI_CARD_MARGIN_DP), 0, dp(UI_CARD_MARGIN_DP), dp(UI_CARD_MARGIN_DP));
        details.addView(makeActionRow(store));
        details.addView(makePhotoGrid(store));
        return details;
    }

    private View makeActionRow(DemoStore store) {
        LinearLayout outer = new LinearLayout(this);
        outer.setOrientation(LinearLayout.VERTICAL);
        outer.setPadding(0, dp(8), 0, dp(8));

        LinearLayout row1 = new LinearLayout(this);
        TextView camera = button("撮影", BLUE, 16);
        TextView addImage = button("画像追加", BLUE, 15);
        if (store.enabled) {
            camera.setOnClickListener(v -> addDemoPhoto(store, "撮影"));
            addImage.setOnClickListener(v -> addDemoPhoto(store, "画像"));
        } else {
            setButtonEnabledStyle(camera, false, BLUE);
            setButtonEnabledStyle(addImage, false, BLUE);
        }
        LinearLayout.LayoutParams r1a = new LinearLayout.LayoutParams(0, dp(44), 1f);
        r1a.rightMargin = dp(4);
        LinearLayout.LayoutParams r1b = new LinearLayout.LayoutParams(0, dp(44), 1f);
        r1b.leftMargin = dp(4);
        row1.addView(camera, r1a);
        row1.addView(addImage, r1b);
        outer.addView(row1);

        LinearLayout row2 = new LinearLayout(this);
        row2.setPadding(0, dp(8), 0, 0);
        TextView list = button("商品リスト", DGRAY, 15);
        list.setOnClickListener(v -> {
            android.content.Intent i = new android.content.Intent(this, NProductListActivity.class);
            i.putExtra(NProductListActivity.EXTRA_TITLE, "商品リスト");
            startActivity(i);
        });
        TextView csv = button("CSV一覧", DGRAY, 15);
        csv.setOnClickListener(v -> NCsvHistoryDialog.show(this, store.name));
        LinearLayout.LayoutParams r2a = new LinearLayout.LayoutParams(0, dp(44), 1f);
        r2a.rightMargin = dp(4);
        LinearLayout.LayoutParams r2b = new LinearLayout.LayoutParams(0, dp(44), 1f);
        r2b.leftMargin = dp(4);
        row2.addView(list, r2a);
        row2.addView(csv, r2b);
        outer.addView(row2);
        return outer;
    }

    private View makePhotoGrid(DemoStore store) {
        LinearLayout outer = new LinearLayout(this);
        outer.setOrientation(LinearLayout.VERTICAL);
        boolean selecting = photoSelectionStoreId == store.id;

        LinearLayout bar = new LinearLayout(this);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setPadding(0, 0, 0, dp(UI_SPACING_DP));
        if (selecting) {
            boolean canEdit = store.enabled && !selectedPhotoIds.isEmpty();
            TextView delete = button("削除", canEdit ? RED : DGRAY, 12);
            setButtonEnabledStyle(delete, canEdit, RED);
            delete.setOnClickListener(v -> {
                if (!canEdit) return;
                store.photos.removeIf(p -> selectedPhotoIds.contains(p.id));
                selectedPhotoIds.clear();
                photoSelectionStoreId = -1L;
                refreshExpandedStoreDetails(store);
            });

            TextView share = button("共有", selectedPhotoIds.isEmpty() ? DGRAY : ORANGE, 12);
            setButtonEnabledStyle(share, !selectedPhotoIds.isEmpty(), ORANGE);
            share.setOnClickListener(v -> {
                if (!selectedPhotoIds.isEmpty()) Toast.makeText(this,
                        selectedPhotoIds.size() + "枚を共有（見本）", Toast.LENGTH_SHORT).show();
            });

            TextView cancel = button("キャンセル", DGRAY, 12);
            cancel.setOnClickListener(v -> {
                photoSelectionStoreId = -1L;
                selectedPhotoIds.clear();
                refreshExpandedStoreDetails(store);
            });

            TextView tag = button("タグ編集", canEdit ? BLUE : DGRAY, 12);
            setButtonEnabledStyle(tag, canEdit, BLUE);
            tag.setOnClickListener(v -> {
                if (canEdit) Toast.makeText(this, "タグ編集（見本）", Toast.LENGTH_SHORT).show();
            });

            bar.addView(delete, new LinearLayout.LayoutParams(0, dp(38), 1f));
            LinearLayout.LayoutParams shareLp = new LinearLayout.LayoutParams(0, dp(38), 1f);
            shareLp.leftMargin = dp(UI_ACTION_GAP_DP);
            bar.addView(share, shareLp);
            LinearLayout.LayoutParams cancelLp = new LinearLayout.LayoutParams(0, dp(38), 1f);
            cancelLp.leftMargin = dp(UI_ACTION_GAP_DP);
            bar.addView(cancel, cancelLp);
            LinearLayout.LayoutParams tagLp = new LinearLayout.LayoutParams(dp(96), dp(38));
            tagLp.leftMargin = dp(UI_ACTION_GAP_DP);
            bar.addView(tag, tagLp);
        } else {
            bar.setGravity(Gravity.CENTER_VERTICAL | Gravity.END);
            bar.addView(new View(this), new LinearLayout.LayoutParams(0, dp(38), 1f));
            TextView selectAll = button("全て選択", DGRAY, 13);
            selectAll.setOnClickListener(v -> {
                if (store.photos.isEmpty()) {
                    Toast.makeText(this, "選択する画像がありません", Toast.LENGTH_SHORT).show();
                    return;
                }
                photoSelectionStoreId = store.id;
                selectedPhotoIds.clear();
                for (DemoPhoto p : store.photos) selectedPhotoIds.add(p.id);
                refreshExpandedStoreDetails(store);
            });
            LinearLayout.LayoutParams allLp = new LinearLayout.LayoutParams(dp(96), dp(38));
            allLp.rightMargin = dp(UI_ACTION_GAP_DP);
            bar.addView(selectAll, allLp);

            TextView select = button("選択", BLUE, 13);
            select.setOnClickListener(v -> {
                if (store.photos.isEmpty()) {
                    Toast.makeText(this, "共有する画像がありません", Toast.LENGTH_SHORT).show();
                    return;
                }
                photoSelectionStoreId = store.id;
                selectedPhotoIds.clear();
                refreshExpandedStoreDetails(store);
            });
            bar.addView(select, new LinearLayout.LayoutParams(dp(96), dp(38)));
        }
        outer.addView(bar, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(46)));

        if (store.photos.isEmpty()) {
            TextView empty = text("画像はまだありません", 14, SECONDARY, false);
            empty.setGravity(Gravity.CENTER);
            empty.setPadding(dp(8), dp(22), dp(8), dp(22));
            outer.addView(empty);
            return outer;
        }

        List<DemoPhoto> preview = store.photos.size() > 6
                ? new ArrayList<>(store.photos.subList(0, 6)) : store.photos;
        LinearLayout grid = buildPhotoGridRows(preview, store, selecting);
        outer.addView(grid, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        LinearLayout footer = new LinearLayout(this);
        footer.setGravity(Gravity.CENTER_VERTICAL);
        footer.setPadding(0, dp(UI_TIGHT_SPACING_DP), 0, 0);
        TextView count = text(selecting ? (selectedPhotoIds.size() + "枚選択") : "", 13, SECONDARY, true);
        count.setGravity(Gravity.START | Gravity.CENTER_VERTICAL);
        count.setVisibility(selecting ? View.VISIBLE : View.INVISIBLE);
        footer.addView(count, new LinearLayout.LayoutParams(dp(92), dp(54)));
        footer.addView(new View(this), new LinearLayout.LayoutParams(0, dp(54), 1f));
        TextView all = text("全て表示", 14, WHITE, true);
        all.setGravity(Gravity.END | Gravity.CENTER_VERTICAL);
        all.setOnClickListener(v -> demoDialog("全て表示", store.photos.size() + "枚の画像（見本）"));
        footer.addView(all, new LinearLayout.LayoutParams(dp(92), dp(54)));
        outer.addView(footer, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(58)));
        return outer;
    }

    private LinearLayout buildPhotoGridRows(List<DemoPhoto> photos, DemoStore store, boolean selecting) {
        LinearLayout grid = new LinearLayout(this);
        grid.setOrientation(LinearLayout.VERTICAL);
        LinearLayout row = null;
        for (int i = 0; i < photos.size(); i++) {
            if (i % 3 == 0) {
                row = new LinearLayout(this);
                row.setGravity(Gravity.TOP | Gravity.START);
                grid.addView(row, new LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
            }
            DemoPhoto photo = photos.get(i);
            LinearLayout tile = makePhotoTile(photo, store, selecting, selectedPhotoIds.contains(photo.id));
            row.addView(tile, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        }
        int remainder = photos.size() % 3;
        if (row != null && remainder != 0) {
            for (int i = remainder; i < 3; i++) row.addView(new View(this), new LinearLayout.LayoutParams(0, dp(1), 1f));
        }
        return grid;
    }

    private LinearLayout makePhotoTile(DemoPhoto photo, DemoStore store, boolean selecting, boolean selected) {
        LinearLayout tile = new LinearLayout(this);
        tile.setOrientation(LinearLayout.VERTICAL);
        tile.setPadding(dp(3), dp(3), dp(3), dp(5));

        SquareFrameLayout frame = new SquareFrameLayout(this);
        frame.setBackground(roundRect(selected ? LBLUE : DGRAY, 6));
        frame.setClipToOutline(true);
        TextView placeholder = text("画像", 14, SECONDARY, true);
        placeholder.setGravity(Gravity.CENTER);
        frame.addView(placeholder, new FrameLayout.LayoutParams(-1, -1));
        if (photo.csvImported) {
            StraightCheckBadgeView badge = new StraightCheckBadgeView(this);
            FrameLayout.LayoutParams badgeLp = new FrameLayout.LayoutParams(dp(22), dp(22), Gravity.TOP | Gravity.END);
            badgeLp.topMargin = dp(5);
            badgeLp.rightMargin = dp(5);
            frame.addView(badge, badgeLp);
        }
        tile.addView(frame, new LinearLayout.LayoutParams(-1, -2));

        TextView tag = text(photo.tag, 11, SECONDARY, false);
        tag.setGravity(Gravity.CENTER);
        tag.setSingleLine(true);
        tile.addView(tag, new LinearLayout.LayoutParams(-1, dp(24)));

        View.OnClickListener click = v -> {
            if (photoSelectionStoreId == store.id) {
                if (!selectedPhotoIds.add(photo.id)) selectedPhotoIds.remove(photo.id);
                refreshExpandedStoreDetails(store);
            } else {
                Toast.makeText(this, "画像を開く（見本）", Toast.LENGTH_SHORT).show();
            }
        };
        tile.setOnClickListener(click);
        frame.setOnClickListener(click);
        View.OnLongClickListener longClick = v -> {
            v.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS);
            photoSelectionStoreId = store.id;
            selectedPhotoIds.add(photo.id);
            refreshExpandedStoreDetails(store);
            return true;
        };
        tile.setOnLongClickListener(longClick);
        frame.setOnLongClickListener(longClick);
        return tile;
    }

    private void addDemoPhoto(DemoStore store, String tag) {
        store.photos.add(0, new DemoPhoto(nextPhotoId++, tag, false));
        DiagLog.write(this, "STORE_DEMO_PHOTO_ADD store=" + store.id + " via=" + tag);
        refreshExpandedStoreDetails(store);
    }

    private void animateExpandStore(DemoStore store, LinearLayout card) {
        if (expandedStoreIds.contains(store.id) && storeDetailViews.containsKey(store.id)) return;
        expandedStoreIds.add(store.id);
        DiagLog.write(this, "STORE_EXPAND id=" + store.id + " mode=lightweight");
        LinearLayout details = buildStoreDetails(store);
        storeDetailViews.put(store.id, details);
        details.setAlpha(0f);
        details.setTranslationY(-dp(5));
        card.addView(details, new LinearLayout.LayoutParams(-1, -2));
        details.animate().alpha(1f).translationY(0f).setDuration(145)
                .setInterpolator(new DecelerateInterpolator(1.4f)).start();
    }

    private void animateCollapseStore(long storeId, Runnable after) {
        LinearLayout card = storeCardViews.get(storeId);
        LinearLayout details = storeDetailViews.get(storeId);
        if (card == null || details == null) {
            expandedStoreIds.remove(storeId);
            if (after != null) after.run();
            return;
        }
        details.animate().alpha(0f).translationY(-dp(5)).setDuration(120)
                .setInterpolator(new DecelerateInterpolator(1.25f))
                .withEndAction(() -> {
                    card.removeView(details);
                    storeDetailViews.remove(storeId);
                    expandedStoreIds.remove(storeId);
                    if (photoSelectionStoreId == storeId) {
                        photoSelectionStoreId = -1L;
                        selectedPhotoIds.clear();
                    }
                    DiagLog.write(this, "STORE_COLLAPSE id=" + storeId + " mode=lightweight");
                    if (after != null) after.run();
                }).start();
    }

    private void collapseAllExpandedStores() {
        if (expandedStoreIds.isEmpty()) return;
        ArrayList<Long> ids = new ArrayList<>(expandedStoreIds);
        DiagLog.write(this, "STORE_COLLAPSE_ALL count=" + ids.size());
        for (Long id : ids) if (id != null) animateCollapseStore(id, null);
    }

    private void refreshExpandedStoreDetails(DemoStore store) {
        if (store == null) return;
        LinearLayout card = storeCardViews.get(store.id);
        LinearLayout old = storeDetailViews.get(store.id);
        if (card == null || old == null || !expandedStoreIds.contains(store.id)) {
            reloadStores();
            return;
        }
        int index = card.indexOfChild(old);
        if (index < 0) {
            reloadStores();
            return;
        }
        LinearLayout fresh = buildStoreDetails(store);
        card.removeViewAt(index);
        card.addView(fresh, index, new LinearLayout.LayoutParams(-1, -2));
        storeDetailViews.put(store.id, fresh);
    }

    private boolean handleStoreScrollDrag(View targetView, DragEvent event) {
        Object local = event.getLocalState();
        if (!(local instanceof DragPayload)) return event.getAction() != DragEvent.ACTION_DRAG_STARTED;
        ScrollView scroll = targetView instanceof ScrollView ? (ScrollView) targetView : storeScroll;
        switch (event.getAction()) {
            case DragEvent.ACTION_DRAG_STARTED:
                return true;
            case DragEvent.ACTION_DRAG_LOCATION:
                if (draggingStoreCard == null || draggingStoreId < 0 || scroll == null) return true;
                float localY = event.getY();
                int edge = dp(72);
                int step = dp(24);
                if (localY < edge) scroll.scrollBy(0, -step);
                else if (localY > scroll.getHeight() - edge) scroll.scrollBy(0, step);
                float contentY = scroll.getScrollY() + localY;
                float translationY = contentY - draggingStoreCard.getTop() - draggingStoreGrabOffsetY;
                draggingStoreCard.setTranslationX(0f);
                draggingStoreCard.setTranslationY(translationY);
                float center = draggingStoreCard.getTop() + translationY + draggingStoreCard.getHeight() / 2f;
                int nextTarget = computeStoreDragTargetIndex(center);
                if (nextTarget != draggingStoreTargetIndex) {
                    draggingStoreTargetIndex = nextTarget;
                    animateStoreDragSlots(nextTarget);
                }
                return true;
            case DragEvent.ACTION_DROP:
                draggingStoreDropCommitted = true;
                finishStoreDrag(true);
                return true;
            case DragEvent.ACTION_DRAG_ENDED:
                if (!draggingStoreDropCommitted) finishStoreDrag(false);
                return true;
            default:
                return true;
        }
    }

    private int computeStoreDragTargetIndex(float draggedCenterY) {
        int count = storeContainer.getChildCount();
        int candidate = 0;
        for (int i = 0; i < count; i++) {
            if (i == draggingStoreSourceIndex) continue;
            View child = storeContainer.getChildAt(i);
            float mid = child.getTop() + child.getHeight() / 2f;
            if (draggedCenterY > mid) candidate++;
        }
        return Math.max(0, Math.min(count - 1, candidate));
    }

    private void animateStoreDragSlots(int targetIndex) {
        if (draggingStoreCard == null || draggingStoreSourceIndex < 0) return;
        for (int i = 0; i < storeContainer.getChildCount(); i++) {
            View child = storeContainer.getChildAt(i);
            if (child == draggingStoreCard) continue;
            float targetY = 0f;
            if (targetIndex > draggingStoreSourceIndex && i > draggingStoreSourceIndex && i <= targetIndex) {
                targetY = -draggingStoreSlotHeight;
            } else if (targetIndex < draggingStoreSourceIndex && i >= targetIndex && i < draggingStoreSourceIndex) {
                targetY = draggingStoreSlotHeight;
            }
            child.animate().translationY(targetY).setDuration(150)
                    .setInterpolator(new DecelerateInterpolator(1.55f)).start();
        }
    }

    private void finishStoreDrag(boolean commit) {
        if (draggingStoreCard == null || draggingStoreId < 0) return;
        View source = draggingStoreCard;
        int sourceIndex = draggingStoreSourceIndex;
        int targetIndex = draggingStoreTargetIndex;
        if (commit && sourceIndex >= 0 && targetIndex >= 0 && targetIndex < stores.size() && targetIndex != sourceIndex) {
            DemoStore moved = stores.remove(sourceIndex);
            stores.add(Math.max(0, Math.min(targetIndex, stores.size())), moved);
            DiagLog.write(this, "STORE_REORDER dragged=" + moved.id + " from=" + sourceIndex + " to=" + targetIndex);
            clearStoreDragState();
            reloadStores();
            return;
        }
        for (int i = 0; i < storeContainer.getChildCount(); i++) {
            View child = storeContainer.getChildAt(i);
            if (child != source) child.animate().translationY(0f).setDuration(130).start();
        }
        source.animate().translationX(0f).translationY(0f).scaleX(1f).scaleY(1f).alpha(1f)
                .setDuration(145).withEndAction(this::clearStoreDragState).start();
    }

    private void clearStoreDragState() {
        if (draggingStoreCard != null) draggingStoreCard.setElevation(0f);
        draggingStoreCard = null;
        draggingStoreId = -1L;
        draggingStoreSourceIndex = -1;
        draggingStoreTargetIndex = -1;
        draggingStoreGrabOffsetY = 0f;
        draggingStoreSlotHeight = 0;
        draggingStoreDropCommitted = false;
    }

    private void showStoreMenu(DemoStore store, View card) {
        LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(UI_DIALOG_MARGIN_DP), 0, dp(UI_DIALOG_MARGIN_DP), dp(UI_DIALOG_EDGE_MARGIN_DP));
        AlertDialog dialog = new AlertDialog.Builder(this).setTitle(store.name).setView(panel).create();

        TextView manual = storeMenuRow("手入力商品リスト", true);
        TextView map = storeMenuRow("マップを開く", store.mapAnalyzed);
        TextView info = storeMenuRow("店舗情報変更", true);
        TextView delete = storeMenuRow("店舗削除", true);
        TextView export = storeMenuRow("エクスポート", true);
        panel.addView(manual); panel.addView(map); panel.addView(info); panel.addView(delete); panel.addView(export);

        manual.setOnClickListener(v -> {
            dialog.dismiss();
            android.content.Intent i = new android.content.Intent(this, NProductListActivity.class);
            i.putExtra(NProductListActivity.EXTRA_TITLE, "商品リスト");
            startActivity(i);
        });
        if (store.mapAnalyzed) map.setOnClickListener(v -> { dialog.dismiss(); Toast.makeText(this, "マップを開く（見本）", Toast.LENGTH_SHORT).show(); });
        info.setOnClickListener(v -> {
            dialog.dismiss();
            if (!store.enabled) Toast.makeText(this, "NトグルOFF中は編集できません", Toast.LENGTH_SHORT).show();
            else showRenameStoreDialog(store);
        });
        delete.setOnClickListener(v -> {
            dialog.dismiss();
            if (!store.enabled) Toast.makeText(this, "NトグルOFF中は編集できません", Toast.LENGTH_SHORT).show();
            else showDeleteStoreDialog(store);
        });
        export.setOnClickListener(v -> { dialog.dismiss(); Toast.makeText(this, "エクスポート（見本）", Toast.LENGTH_SHORT).show(); });
        dialog.setOnDismissListener(d -> {
            View current = storeCardViews.get(store.id);
            if (current != null) current.setBackground(roundRect(GRAY, 18));
        });
        N.showDialogStable(this, dialog);
    }

    private TextView storeMenuRow(String label, boolean enabled) {
        TextView row = text(label, 15, enabled ? WHITE : LGRAY, false);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(8), 0, dp(8), 0);
        row.setEnabled(enabled);
        row.setAlpha(1f);
        row.setBackgroundColor(Color.TRANSPARENT);
        row.setLayoutParams(new LinearLayout.LayoutParams(-1, dp(46)));
        return row;
    }

    private void showRenameStoreDialog(DemoStore store) {
        EditText name = dialogInput("店舗名");
        name.setText(store.name);
        name.setSelection(name.length());
        EditText map = dialogInput("GoogleマップURL（任意）");
        map.setText(store.mapAnalyzed ? "https://maps.google.com/…" : "");

        LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(UI_DIALOG_MARGIN_DP), dp(UI_SPACING_DP), dp(UI_DIALOG_MARGIN_DP), dp(UI_DIALOG_EDGE_MARGIN_DP));
        panel.addView(text("店舗名", 12, SECONDARY, true));
        panel.addView(name, new LinearLayout.LayoutParams(-1, dp(48)));
        TextView mapLabel = text("GoogleマップURL（任意）", 12, SECONDARY, true);
        mapLabel.setPadding(0, dp(8), 0, dp(4));
        panel.addView(mapLabel);
        panel.addView(map, new LinearLayout.LayoutParams(-1, dp(48)));

        AlertDialog dialog = new AlertDialog.Builder(this).setTitle("店舗情報変更").setView(panel)
                .setNegativeButton("キャンセル", null)
                .setPositiveButton("変更", null).create();
        dialog.setOnShowListener(d -> dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
            String value = name.getText().toString().trim();
            if (value.isEmpty()) return;
            store.name = value;
            store.mapAnalyzed = !map.getText().toString().trim().isEmpty();
            dialog.dismiss();
            reloadStores();
        }));
        N.showDialogStable(this, dialog);
    }

    private void showDeleteStoreDialog(DemoStore store) {
        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("店舗削除")
                .setMessage(store.name + " を削除しますか？")
                .setNegativeButton("キャンセル", null)
                .setPositiveButton("削除", (d, w) -> {
                    stores.remove(store);
                    expandedStoreIds.remove(store.id);
                    reloadStores();
                }).create();
        N.showDialogStable(this, dialog);
    }

    private void showAddStoreDialog() {
        EditText nameInput = dialogInput("店舗名");
        EditText mapInput = dialogInput("GoogleマップURL（任意）");
        LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(UI_DIALOG_MARGIN_DP), dp(UI_SPACING_DP), dp(UI_DIALOG_MARGIN_DP), dp(UI_DIALOG_EDGE_MARGIN_DP));
        TextView nameLabel = text("店舗名", 12, SECONDARY, true);
        nameLabel.setPadding(0, 0, 0, dp(UI_TIGHT_SPACING_DP));
        panel.addView(nameLabel);
        panel.addView(nameInput, new LinearLayout.LayoutParams(-1, dp(48)));
        TextView mapLabel = text("GoogleマップURL（任意）", 12, SECONDARY, true);
        mapLabel.setPadding(0, dp(UI_SPACING_DP), 0, dp(UI_TIGHT_SPACING_DP));
        panel.addView(mapLabel);
        panel.addView(mapInput, new LinearLayout.LayoutParams(-1, dp(48)));

        LinearLayout actions = new LinearLayout(this);
        actions.setPadding(0, dp(18), 0, 0);
        TextView mapButton = button("マップ解析", ORANGE, 13);
        TextView cancel = button("キャンセル", DGRAY, 13);
        TextView add = button("追加", BLUE, 13);
        actions.addView(mapButton, new LinearLayout.LayoutParams(0, dp(38), 1f));
        LinearLayout.LayoutParams cancelLp = new LinearLayout.LayoutParams(0, dp(38), 1f);
        cancelLp.leftMargin = dp(5);
        actions.addView(cancel, cancelLp);
        LinearLayout.LayoutParams addLp = new LinearLayout.LayoutParams(0, dp(38), 1f);
        addLp.leftMargin = dp(5);
        actions.addView(add, addLp);
        panel.addView(actions);

        AlertDialog dialog = new AlertDialog.Builder(this).setTitle("店舗カード追加").setView(panel).create();
        final boolean[] mapAnalyzed = {false};
        mapButton.setOnClickListener(v -> {
            if (mapInput.getText().toString().trim().isEmpty()) {
                Toast.makeText(this, "GoogleマップURLを入力", Toast.LENGTH_SHORT).show();
                return;
            }
            mapAnalyzed[0] = true;
            mapButton.setText("解析済");
            Toast.makeText(this, "マップ解析（見本）", Toast.LENGTH_SHORT).show();
        });
        cancel.setOnClickListener(v -> dialog.cancel());
        add.setOnClickListener(v -> {
            String name = nameInput.getText().toString().trim();
            if (name.isEmpty()) {
                Toast.makeText(this, "店舗名を入力", Toast.LENGTH_SHORT).show();
                return;
            }
            DemoStore store = new DemoStore(nextStoreId++, name, true,
                    mapAnalyzed[0] || !mapInput.getText().toString().trim().isEmpty());
            stores.add(store);
            expandedStoreIds.add(store.id);
            dialog.dismiss();
            reloadStores();
        });
        N.showDialogStable(this, dialog);
    }

    private void runSearch(String query) {
        String q = query == null ? "" : query.trim();
        if (q.isEmpty()) return;
        if (!searchCandidates.contains(q)) searchCandidates.add(q);
        refreshSearchCandidates();
        Toast.makeText(this, "「" + q + "」を検索（見本）", Toast.LENGTH_SHORT).show();
        DiagLog.write(this, "PRODUCT_SEARCH_DEMO q=" + q);
    }

    private void refreshSearchCandidates() {
        if (searchCandidateRow == null || searchCandidateChips == null) return;
        searchCandidateChips.removeAllViews();
        for (String value : searchCandidates) {
            boolean selected = selectedSearchCandidates.contains(value);
            TextView chip = text(value, 13, WHITE, true);
            chip.setGravity(Gravity.CENTER);
            chip.setPadding(dp(13), 0, dp(13), 0);
            chip.setBackground(roundRect(selected ? LBLUE : DGRAY, 999));
            chip.setOnClickListener(v -> {
                if (searchCandidateSelectionMode) {
                    if (!selectedSearchCandidates.add(value)) selectedSearchCandidates.remove(value);
                    refreshSearchCandidates();
                } else {
                    searchInput.setText(value);
                    searchInput.setSelection(searchInput.length());
                }
            });
            chip.setOnLongClickListener(v -> {
                v.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS);
                searchCandidateSelectionMode = true;
                selectedSearchCandidates.add(value);
                refreshSearchCandidates();
                return true;
            });
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, dp(34));
            lp.rightMargin = dp(6);
            searchCandidateChips.addView(chip, lp);
        }
        searchCandidateDelete.setVisibility(searchCandidateSelectionMode ? View.VISIBLE : View.GONE);
        searchCandidateDelete.setAlpha(selectedSearchCandidates.isEmpty() ? 0.45f : 1f);
        searchCandidateRow.setVisibility(searchCandidates.isEmpty() && !searchCandidateSelectionMode ? View.GONE : View.VISIBLE);
    }

    private void deleteSelectedSearchCandidates() {
        if (selectedSearchCandidates.isEmpty()) return;
        searchCandidates.removeIf(selectedSearchCandidates::contains);
        selectedSearchCandidates.clear();
        searchCandidateSelectionMode = false;
        refreshSearchCandidates();
    }

    private View productSearchInputHolder(EditText input) {
        FrameLayout holder = new FrameLayout(this);
        holder.addView(input, new FrameLayout.LayoutParams(-1, -1));
        int left = input.getPaddingLeft();
        int top = input.getPaddingTop();
        int bottom = input.getPaddingBottom();
        input.setPadding(left, top, dp(46), bottom);

        TextView clear = text("×", 24, DGRAY, true);
        clear.setGravity(Gravity.CENTER);
        clear.setContentDescription("検索文字を消去");
        clear.setVisibility(input.length() == 0 ? View.GONE : View.VISIBLE);
        clear.setOnClickListener(v -> {
            input.setText("");
            input.requestFocus();
        });
        FrameLayout.LayoutParams clearLp = new FrameLayout.LayoutParams(dp(40), dp(40), Gravity.END | Gravity.CENTER_VERTICAL);
        clearLp.rightMargin = dp(3);
        holder.addView(clear, clearLp);
        input.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) {
                clear.setVisibility(s.length() == 0 ? View.GONE : View.VISIBLE);
            }
            @Override public void afterTextChanged(Editable s) {}
        });
        return holder;
    }

    private void showReferenceMenu() {
        String[] rows = {"店舗全体リスト", "CSVインポート", "履歴", "診断ログ"};
        new AlertDialog.Builder(this).setItems(rows, (d, which) ->
                Toast.makeText(this, rows[which] + "（見本）", Toast.LENGTH_SHORT).show()).show();
    }

    private void demoDialog(String title, String message) {
        new AlertDialog.Builder(this).setTitle(title).setMessage(message).setPositiveButton("閉じる", null).show();
    }

    private EditText dialogInput(String hint) {
        EditText e = new EditText(this);
        e.setHint(hint);
        e.setTextColor(DGRAY);
        e.setHintTextColor(GRAY);
        e.setTextSize(15);
        e.setSingleLine(true);
        e.setGravity(Gravity.CENTER_VERTICAL);
        e.setIncludeFontPadding(false);
        e.setPadding(dp(10), 0, dp(10), 0);
        e.setBackground(roundRect(NWHITE, 999));
        return e;
    }

    private ImageView roundPlusIcon(int backgroundColor, int iconColor, String contentDescription) {
        ImageView icon = new ImageView(this);
        icon.setImageResource(R.drawable.ic_plus_geometric);
        icon.setScaleType(ImageView.ScaleType.CENTER);
        icon.setColorFilter(iconColor);
        icon.setBackground(circle(backgroundColor));
        icon.setContentDescription(contentDescription);
        return icon;
    }

    private TextView text(String value, float sp, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextSize(sp);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }

    private TextView button(String value, int color, float sp) {
        TextView t = text(value, sp, WHITE, true);
        t.setGravity(Gravity.CENTER);
        t.setBackground(roundRect(color, 999));
        return t;
    }

    private void setButtonEnabledStyle(TextView button, boolean enabled, int enabledColor) {
        button.setEnabled(enabled);
        button.setAlpha(1f);
        button.setTextColor(enabled ? WHITE : LGRAY);
        button.setBackground(roundRect(enabled ? enabledColor : DGRAY, 999));
    }

    private GradientDrawable roundRect(int color, float radiusDp) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(radiusDp));
        return g;
    }

    private GradientDrawable circle(int color) {
        GradientDrawable g = new GradientDrawable();
        g.setShape(GradientDrawable.OVAL);
        g.setColor(color);
        return g;
    }

    private int dp(float value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    private static final class DemoStore {
        final long id;
        String name;
        boolean enabled;
        boolean mapAnalyzed;
        final List<DemoPhoto> photos = new ArrayList<>();
        DemoStore(long id, String name, boolean enabled, boolean mapAnalyzed) {
            this.id = id;
            this.name = name;
            this.enabled = enabled;
            this.mapAnalyzed = mapAnalyzed;
        }
    }

    private static final class DemoPhoto {
        final long id;
        final String tag;
        final boolean csvImported;
        DemoPhoto(long id, String tag, boolean csvImported) {
            this.id = id;
            this.tag = tag;
            this.csvImported = csvImported;
        }
    }

    private static final class DragPayload {
        final long storeId;
        DragPayload(long storeId) { this.storeId = storeId; }
    }

    private static final class InvisibleDragShadowBuilder extends View.DragShadowBuilder {
        InvisibleDragShadowBuilder(View view) { super(view); }
        @Override public void onProvideShadowMetrics(android.graphics.Point outSize, android.graphics.Point outTouchPoint) {
            outSize.set(1, 1);
            outTouchPoint.set(0, 0);
        }
        @Override public void onDrawShadow(Canvas canvas) {}
    }

    private static final class SquareFrameLayout extends FrameLayout {
        SquareFrameLayout(Context context) { super(context); }
        @Override protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
            super.onMeasure(widthMeasureSpec, widthMeasureSpec);
            int size = getMeasuredWidth();
            setMeasuredDimension(size, size);
        }
    }

    private static final class StraightCheckBadgeView extends View {
        private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint mark = new Paint(Paint.ANTI_ALIAS_FLAG);
        StraightCheckBadgeView(Context context) {
            super(context);
            fill.setColor(CHECK_GREEN);
            fill.setStyle(Paint.Style.FILL);
            mark.setColor(WHITE);
            mark.setStyle(Paint.Style.STROKE);
            mark.setStrokeWidth(dpStatic(context, 2.2f));
            mark.setStrokeCap(Paint.Cap.SQUARE);
            mark.setStrokeJoin(Paint.Join.MITER);
        }
        @Override protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            float w = getWidth();
            float h = getHeight();
            canvas.drawCircle(w / 2f, h / 2f, Math.min(w, h) / 2f, fill);
            android.graphics.Path p = new android.graphics.Path();
            p.moveTo(w * 0.27f, h * 0.52f);
            p.lineTo(w * 0.44f, h * 0.69f);
            p.lineTo(w * 0.75f, h * 0.34f);
            canvas.drawPath(p, mark);
        }
        private static int dpStatic(Context c, float v) {
            return Math.round(v * c.getResources().getDisplayMetrics().density);
        }
    }
}
