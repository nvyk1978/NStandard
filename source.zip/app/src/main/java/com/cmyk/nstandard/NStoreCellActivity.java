package com.cmyk.nstandard;

import android.app.Activity;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.os.Build;
import android.os.Bundle;
import android.view.Gravity;
import android.view.HapticFeedbackConstants;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/**
 * N Standard store-cell sandbox.
 *
 * The actual store-card header is transplanted from Price Rec. 0.1.81.
 * N Standard only supplies surrounding demo state: add/confirm, timestamp,
 * and ImgStalker-style selection behaviour.
 */
public final class NStoreCellActivity extends Activity {
    private static final int UI_CARD_MARGIN_DP = 12;
    private static final int UI_SPACING_DP = 8;

    private final List<DemoStore> cells = new ArrayList<>();
    private LinearLayout cellContainer;
    private TextView selectionButton;
    private TextView selectionCount;
    private boolean selectionMode;
    private int selectionAnchorPosition = -1;
    private int draftCellIndex = -1;
    private int nextCellNumber = 1;

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        DiagLog.write(this, "OPEN_STORE_CELL_DEMO");
        cells.add(new DemoStore("店舗名", true, true, System.currentTimeMillis()));
        setContentView(buildUi());
    }

    private View buildUi() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setVerticalScrollBarEnabled(false);
        scroll.setBackgroundColor(N.BG);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(0, N.dp(this, 24), 0, N.dp(this, 24));
        root.setBackgroundColor(N.BG);
        scroll.addView(root, new ScrollView.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        TextView title = text("店舗セル", 24, N.TEXT, false);
        title.setGravity(Gravity.START | Gravity.CENTER_VERTICAL);
        LinearLayout.LayoutParams titleLp = new LinearLayout.LayoutParams(-1, N.dp(this, 52));
        titleLp.topMargin = N.dp(this, 50);
        titleLp.leftMargin = N.dp(this, 25);
        titleLp.rightMargin = N.dp(this, 25);
        root.addView(title, titleLp);

        LinearLayout fieldHeader = new LinearLayout(this);
        fieldHeader.setOrientation(LinearLayout.HORIZONTAL);
        fieldHeader.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout.LayoutParams fieldHeaderLp = new LinearLayout.LayoutParams(-1, N.dp(this, 42));
        fieldHeaderLp.topMargin = N.dp(this, 10);
        fieldHeaderLp.leftMargin = N.dp(this, 14);
        fieldHeaderLp.rightMargin = N.dp(this, 14);
        root.addView(fieldHeader, fieldHeaderLp);

        TextView fieldTitle = text("セルフィールド", 14, N.TEXT, false);
        fieldHeader.addView(fieldTitle, new LinearLayout.LayoutParams(0, -1, 1f));

        selectionCount = text("選択 0", 13, N.WHITE, true);
        selectionCount.setGravity(Gravity.CENTER_VERTICAL | Gravity.END);
        selectionCount.setVisibility(View.GONE);
        fieldHeader.addView(selectionCount, new LinearLayout.LayoutParams(N.dp(this, 72), -1));

        selectionButton = smallButton("選択", N.DGRAY);
        selectionButton.setOnClickListener(v -> handleSelectionButton());
        LinearLayout.LayoutParams selectionLp = new LinearLayout.LayoutParams(N.dp(this, 86), N.dp(this, 38));
        selectionLp.leftMargin = N.dp(this, 8);
        fieldHeader.addView(selectionButton, selectionLp);

        cellContainer = new LinearLayout(this);
        cellContainer.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams containerLp = new LinearLayout.LayoutParams(-1, -2);
        containerLp.leftMargin = N.dp(this, 14);
        containerLp.rightMargin = N.dp(this, 14);
        root.addView(cellContainer, containerLp);
        renderCells();

        NEmulatorArea emulatorArea = new NEmulatorArea(this);
        emulatorArea.setListener(new NEmulatorArea.Listener() {
            @Override public void onAddCell() { addDraftCell(); }
            @Override public void onConfirmCell() { confirmDraftCell(); }
        });
        LinearLayout.LayoutParams emulatorLp = new LinearLayout.LayoutParams(-1, -2);
        emulatorLp.topMargin = N.dp(this, 18);
        emulatorLp.leftMargin = N.dp(this, 25);
        emulatorLp.rightMargin = N.dp(this, 25);
        root.addView(emulatorArea, emulatorLp);

        TextView close = smallButton("閉じる", N.LBLUE);
        close.setOnClickListener(v -> finish());
        LinearLayout.LayoutParams closeLp = new LinearLayout.LayoutParams(-1, N.dp(this, 48));
        closeLp.topMargin = N.dp(this, 10);
        closeLp.leftMargin = N.dp(this, 25);
        closeLp.rightMargin = N.dp(this, 25);
        root.addView(close, closeLp);

        return scroll;
    }

    private void addDraftCell() {
        DemoStore item = new DemoStore("店舗 " + String.format(Locale.US, "%02d", nextCellNumber++), true, false,
                System.currentTimeMillis());
        cells.add(item);
        draftCellIndex = cells.size() - 1;
        DiagLog.write(this, "STORE_CELL_ADD position=" + draftCellIndex);
        renderCells();
    }

    private void confirmDraftCell() {
        if (draftCellIndex < 0 || draftCellIndex >= cells.size()) {
            Toast.makeText(this, "確定するセルがありません", Toast.LENGTH_SHORT).show();
            return;
        }
        DemoStore item = cells.get(draftCellIndex);
        item.analyzed = true;
        item.timestamp = System.currentTimeMillis();
        int confirmed = draftCellIndex;
        draftCellIndex = -1;
        DiagLog.write(this, "STORE_CELL_CONFIRM position=" + confirmed);
        renderCells();
    }

    private void renderCells() {
        if (cellContainer == null) return;
        cellContainer.removeAllViews();
        if (cells.isEmpty()) {
            TextView empty = text("セルはここに追加されます", 13, N.LGRAY, false);
            empty.setGravity(Gravity.CENTER);
            cellContainer.addView(empty, new LinearLayout.LayoutParams(-1, N.dp(this, 72)));
            updateSelectionControls();
            return;
        }

        for (int i = 0; i < cells.size(); i++) {
            final int position = i;
            DemoStore store = cells.get(i);

            LinearLayout wrapper = new LinearLayout(this);
            wrapper.setOrientation(LinearLayout.VERTICAL);
            LinearLayout.LayoutParams wrapperLp = new LinearLayout.LayoutParams(-1, -2);
            wrapperLp.bottomMargin = N.dp(this, 12);
            cellContainer.addView(wrapper, wrapperLp);

            View card = makeStoreCard(store, position);
            wrapper.addView(card);

            Date date = new Date(store.timestamp);
            TextView day = text(new SimpleDateFormat("yyyy/MM/dd", Locale.JAPAN).format(date), 10, N.WHITE, false);
            day.setGravity(Gravity.CENTER);
            LinearLayout.LayoutParams dayLp = new LinearLayout.LayoutParams(-1, N.dp(this, 18));
            dayLp.topMargin = N.dp(this, 4);
            wrapper.addView(day, dayLp);

            TextView time = text(new SimpleDateFormat("HH:mm:ss", Locale.JAPAN).format(date), 10, N.LGRAY, false);
            time.setGravity(Gravity.CENTER);
            wrapper.addView(time, new LinearLayout.LayoutParams(-1, N.dp(this, 17)));

            bindSelectionTouch(day, position);
            bindSelectionTouch(time, position);
        }
        updateSelectionControls();
    }

    /** Price Rec. 0.1.81 store card header transplanted here with only data wiring replaced. */
    private View makeStoreCard(DemoStore store, int position) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setBackground(N.round(selectionMode && store.selected ? N.LBLUE : N.GRAY, 18, this));
        card.setTag(Integer.valueOf(position));

        LinearLayout header = new LinearLayout(this);
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.setPadding(N.dp(this, UI_CARD_MARGIN_DP), N.dp(this, UI_SPACING_DP),
                N.dp(this, UI_CARD_MARGIN_DP), N.dp(this, UI_SPACING_DP));

        TextView handle = text("☰", 22, N.WHITE, false);
        handle.setGravity(Gravity.CENTER);
        handle.setContentDescription("店舗を並べ替え");

        TextView name = text(store.name, 18, store.enabled ? N.TEXT : N.LGRAY, true);
        name.setGravity(Gravity.CENTER_VERTICAL);

        header.addView(handle, new LinearLayout.LayoutParams(N.dp(this, 48), N.dp(this, 48)));
        header.addView(name, new LinearLayout.LayoutParams(0, N.dp(this, 48), 1f));

        if (store.analyzed) {
            StraightCheckBadgeView mapCheck = new StraightCheckBadgeView(this);
            mapCheck.setContentDescription("Googleマップ解析済み");
            LinearLayout.LayoutParams checkLp = new LinearLayout.LayoutParams(N.dp(this, 22), N.dp(this, 22));
            checkLp.rightMargin = N.dp(this, 6);
            header.addView(mapCheck, checkLp);
        }

        FrameLayout toggleHit = new FrameLayout(this);
        toggleHit.setClickable(true);
        toggleHit.setFocusable(true);
        toggleHit.setClipChildren(false);
        toggleHit.setClipToPadding(false);
        toggleHit.setContentDescription(store.enabled ? "Nトグル オン" : "Nトグル オフ");
        NToggleSwitch nToggle = new NToggleSwitch(this);
        nToggle.setChecked(store.enabled);
        nToggle.setNColors(N.ORANGE, N.WHITE);
        nToggle.setContentDescription(store.enabled ? "Nトグル オン" : "Nトグル オフ");
        nToggle.setOnCheckedChangeListener((buttonView, checked) -> {
            if (checked == store.enabled) return;
            store.enabled = checked;
            buttonView.performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK);
            DiagLog.write(this, "STORE_CELL_N_TOGGLE position=" + position + " enabled=" + checked);
            buttonView.postDelayed(this::renderCells, 130L);
        });
        FrameLayout.LayoutParams switchLp = new FrameLayout.LayoutParams(N.dp(this, 44), N.dp(this, 26), Gravity.CENTER);
        toggleHit.addView(nToggle, switchLp);
        toggleHit.setOnClickListener(v -> nToggle.performClick());
        LinearLayout.LayoutParams toggleLp = new LinearLayout.LayoutParams(N.dp(this, 58), N.dp(this, 48));
        toggleLp.leftMargin = N.dp(this, 8);
        header.addView(toggleHit, toggleLp);

        card.addView(header);

        View.OnClickListener tap = v -> {
            if (selectionMode) toggleSelectionAt(position);
        };
        View.OnLongClickListener longPress = v -> {
            if (!selectionMode) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                    card.performHapticFeedback(HapticFeedbackConstants.CONFIRM);
                } else {
                    card.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS);
                }
                enterSelectionModeWithItem(position);
                return true;
            }
            if (selectRangeFromAnchor(position)) return true;
            if (!cells.get(position).selected) {
                cells.get(position).selected = true;
                selectionAnchorPosition = position;
                DiagLog.write(this, "STORE_CELL_SELECT_LONG position=" + position);
                renderCells();
            }
            return true;
        };

        card.setOnClickListener(tap);
        card.setOnLongClickListener(longPress);
        header.setOnClickListener(tap);
        header.setOnLongClickListener(longPress);
        handle.setOnClickListener(tap);
        handle.setOnLongClickListener(longPress);
        name.setOnClickListener(tap);
        name.setOnLongClickListener(longPress);
        // The toggle keeps its own Price Rec. behaviour even while the card is selectable.
        return card;
    }

    private void bindSelectionTouch(View view, int position) {
        view.setOnClickListener(v -> {
            if (selectionMode) toggleSelectionAt(position);
        });
        view.setOnLongClickListener(v -> {
            if (!selectionMode) {
                enterSelectionModeWithItem(position);
                return true;
            }
            if (selectRangeFromAnchor(position)) return true;
            if (!cells.get(position).selected) {
                cells.get(position).selected = true;
                selectionAnchorPosition = position;
                renderCells();
            }
            return true;
        });
    }

    // ImgStalker selection behaviour: enter, tap toggle, long-press range, select-all/all-clear.
    private void handleSelectionButton() {
        if (!selectionMode) {
            selectionMode = true;
            selectionAnchorPosition = -1;
            DiagLog.write(this, "STORE_CELL_SELECTION_MODE_ENTER source=button");
            renderCells();
            return;
        }
        if (areAllCellsSelected()) {
            exitSelectionMode(true, "select_all_toggle_clear");
            return;
        }
        for (DemoStore item : cells) item.selected = true;
        DiagLog.write(this, "STORE_CELL_SELECT_ALL count=" + cells.size());
        renderCells();
    }

    private void enterSelectionModeWithItem(int position) {
        if (position < 0 || position >= cells.size()) return;
        if (!selectionMode) {
            selectionMode = true;
            DiagLog.write(this, "STORE_CELL_SELECTION_MODE_ENTER source=long_press position=" + position);
        }
        cells.get(position).selected = true;
        selectionAnchorPosition = position;
        renderCells();
    }

    private void toggleSelectionAt(int position) {
        if (position < 0 || position >= cells.size()) return;
        DemoStore item = cells.get(position);
        item.selected = !item.selected;
        if (item.selected) selectionAnchorPosition = position;
        else if (selectionAnchorPosition == position) selectionAnchorPosition = -1;
        DiagLog.write(this, "STORE_CELL_SELECT position=" + position + " selected=" + item.selected);
        if (selectionMode && countSelectedCells() == 0) {
            exitSelectionMode(false, "all_deselected_by_tap");
        } else {
            renderCells();
        }
    }

    private boolean selectRangeFromAnchor(int position) {
        if (!selectionMode || selectionAnchorPosition < 0 || position < 0 || position >= cells.size()) return false;
        int anchor = selectionAnchorPosition;
        if (anchor == position || anchor >= cells.size() || !cells.get(anchor).selected) return false;

        int from = Math.min(anchor, position);
        int to = Math.max(anchor, position);
        for (int i = from + 1; i < to; i++) {
            if (cells.get(i).selected) return false;
        }
        for (int i = from; i <= to; i++) cells.get(i).selected = true;
        selectionAnchorPosition = position;
        DiagLog.write(this, "STORE_CELL_RANGE_SELECT anchor=" + anchor + " target=" + position
                + " range=" + from + "-" + to);
        renderCells();
        return true;
    }

    private void exitSelectionMode(boolean clearSelection, String reason) {
        if (clearSelection) for (DemoStore item : cells) item.selected = false;
        selectionMode = false;
        selectionAnchorPosition = -1;
        DiagLog.write(this, "STORE_CELL_SELECTION_MODE_EXIT reason=" + reason + " clear=" + clearSelection);
        renderCells();
    }

    private boolean areAllCellsSelected() {
        if (cells.isEmpty()) return false;
        for (DemoStore item : cells) if (!item.selected) return false;
        return true;
    }

    private int countSelectedCells() {
        int count = 0;
        for (DemoStore item : cells) if (item.selected) count++;
        return count;
    }

    private void updateSelectionControls() {
        if (selectionButton == null || selectionCount == null) return;
        int selected = countSelectedCells();
        selectionCount.setText("選択 " + selected);
        selectionCount.setVisibility(selectionMode ? View.VISIBLE : View.GONE);
        selectionButton.setText(!selectionMode ? "選択" : (areAllCellsSelected() ? "全解除" : "全選択"));
        selectionButton.setBackground(N.round(selectionMode ? N.LBLUE : N.DGRAY, 19, this));
    }

    private TextView text(String value, float sp, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextSize(sp);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }

    private TextView smallButton(String label, int color) {
        TextView t = text(label, 14, N.TEXT, false);
        t.setGravity(Gravity.CENTER);
        t.setBackground(N.round(color, 24, this));
        t.setClickable(true);
        t.setFocusable(true);
        return t;
    }

    private static final class DemoStore {
        final String name;
        boolean enabled;
        boolean analyzed;
        long timestamp;
        boolean selected;

        DemoStore(String name, boolean enabled, boolean analyzed, long timestamp) {
            this.name = name;
            this.enabled = enabled;
            this.analyzed = analyzed;
            this.timestamp = timestamp;
        }
    }

    /** Exact Price Rec. straight green check badge geometry. */
    private final class StraightCheckBadgeView extends View {
        private final Paint fillPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint checkPaint = new Paint(Paint.ANTI_ALIAS_FLAG);

        StraightCheckBadgeView(android.content.Context context) {
            super(context);
            fillPaint.setColor(N.GREEN);
            fillPaint.setStyle(Paint.Style.FILL);
            checkPaint.setColor(N.TEXT);
            checkPaint.setStyle(Paint.Style.STROKE);
            checkPaint.setStrokeWidth(N.dp(context, 2));
            checkPaint.setStrokeCap(Paint.Cap.SQUARE);
            checkPaint.setStrokeJoin(Paint.Join.MITER);
        }

        @Override
        protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            float w = getWidth();
            float h = getHeight();
            float r = Math.min(w, h) / 2f;
            canvas.drawCircle(w / 2f, h / 2f, r, fillPaint);
            canvas.drawLine(w * 0.27f, h * 0.53f, w * 0.44f, h * 0.69f, checkPaint);
            canvas.drawLine(w * 0.44f, h * 0.69f, w * 0.76f, h * 0.34f, checkPaint);
        }
    }
}
