package com.cmyk.nstandard;

import android.app.Activity;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.text.InputType;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.net.URL;

/** Demo/sandbox for the reusable thumbnail component extracted from ImgStalker. */
public class NThumbnailActivity extends Activity {
    private NThumbnailLoader loader;
    private NThumbnailLoader.Kind kind = NThumbnailLoader.Kind.IMAGE;
    private NThumbnailLoader.Item currentItem;
    private ImageView preview;
    private PlayIcon playIcon;
    private TextView resolution;
    private TextView duration;
    private TextView imageType;
    private TextView videoType;

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        DiagLog.write(this, "OPEN_THUMBNAIL_DEMO");
        loader = new NThumbnailLoader(this, item -> {
            if (item != currentItem) return;
            updateMetadata(item);
        });
        setContentView(buildUi());
    }

    private View buildUi() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(N.BG);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(N.dp(this, 25), N.dp(this, 24), N.dp(this, 25), N.dp(this, 24));
        root.setBackgroundColor(N.BG);
        scroll.addView(root, new ScrollView.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        TextView title = text("サムネイル", 24, N.TEXT);
        title.setGravity(Gravity.START | Gravity.CENTER_VERTICAL);
        root.addView(title, new LinearLayout.LayoutParams(-1, N.dp(this, 52)));

        TextView note = text(
                "ImgStalkerのサムネイル処理を汎用化。画像は最大辺320pxへ縮小、動画は一時MP4からフレーム抽出します。",
                13, N.WHITE);
        note.setLineSpacing(0f, 1.15f);
        LinearLayout.LayoutParams noteLp = new LinearLayout.LayoutParams(-1, -2);
        noteLp.topMargin = N.dp(this, 8);
        root.addView(note, noteLp);

        EditText url = new EditText(this);
        url.setHint("画像または動画URL");
        url.setHintTextColor(N.LGRAY);
        url.setTextColor(N.TEXT);
        url.setTextSize(14);
        url.setSingleLine(true);
        url.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        url.setPadding(N.dp(this, 16), 0, N.dp(this, 16), 0);
        url.setBackground(N.round(N.GRAY, 12, this));
        LinearLayout.LayoutParams urlLp = new LinearLayout.LayoutParams(-1, N.dp(this, 48));
        urlLp.topMargin = N.dp(this, 18);
        root.addView(url, urlLp);

        LinearLayout typeRow = new LinearLayout(this);
        typeRow.setOrientation(LinearLayout.HORIZONTAL);
        typeRow.setGravity(Gravity.START | Gravity.CENTER_VERTICAL);
        imageType = capsule("画像", true);
        videoType = capsule("動画", false);
        imageType.setOnClickListener(v -> setKind(NThumbnailLoader.Kind.IMAGE));
        videoType.setOnClickListener(v -> setKind(NThumbnailLoader.Kind.VIDEO));
        typeRow.addView(imageType, new LinearLayout.LayoutParams(N.dp(this, 92), N.dp(this, 42)));
        LinearLayout.LayoutParams videoLp = new LinearLayout.LayoutParams(N.dp(this, 92), N.dp(this, 42));
        videoLp.leftMargin = N.dp(this, 10);
        typeRow.addView(videoType, videoLp);
        LinearLayout.LayoutParams typeLp = new LinearLayout.LayoutParams(-1, N.dp(this, 42));
        typeLp.topMargin = N.dp(this, 12);
        root.addView(typeRow, typeLp);

        TextView load = button("読み込み");
        load.setOnClickListener(v -> {
            String value = url.getText().toString().trim();
            if (!looksLikeHttpUrl(value)) {
                Toast.makeText(this, "http/https URLを入力してください", Toast.LENGTH_SHORT).show();
                return;
            }
            currentItem = new NThumbnailLoader.Item(value, kind);
            resolution.setText("—");
            duration.setText("");
            playIcon.setVisibility(kind == NThumbnailLoader.Kind.VIDEO ? View.VISIBLE : View.GONE);
            DiagLog.write(this, "THUMB_DEMO_LOAD kind=" + kind + " url=" + value);
            loader.load(preview, currentItem);
        });
        LinearLayout.LayoutParams loadLp = new LinearLayout.LayoutParams(-1, N.dp(this, 48));
        loadLp.topMargin = N.dp(this, 12);
        root.addView(load, loadLp);

        SquareFrameLayout frame = new SquareFrameLayout(this);
        frame.setBackground(N.round(N.DGRAY, 12, this));
        frame.setClipToOutline(true);
        LinearLayout.LayoutParams frameLp = new LinearLayout.LayoutParams(-1, -2);
        frameLp.topMargin = N.dp(this, 18);
        root.addView(frame, frameLp);

        preview = new ImageView(this);
        preview.setScaleType(ImageView.ScaleType.CENTER_CROP);
        preview.setBackground(N.round(N.DGRAY, 12, this));
        preview.setClipToOutline(true);
        preview.setAlpha(0.55f);
        frame.addView(preview, new FrameLayout.LayoutParams(-1, -1));

        playIcon = new PlayIcon(this);
        playIcon.setVisibility(View.GONE);
        FrameLayout.LayoutParams playLp = new FrameLayout.LayoutParams(
                N.dp(this, 52), N.dp(this, 52), Gravity.CENTER);
        frame.addView(playIcon, playLp);

        duration = text("", 11, N.TEXT);
        duration.setGravity(Gravity.CENTER);
        duration.setSingleLine(true);
        duration.setPadding(N.dp(this, 7), 0, N.dp(this, 7), 0);
        duration.setBackground(round(0xAA252020, 5));
        duration.setVisibility(View.GONE);
        FrameLayout.LayoutParams durationLp = new FrameLayout.LayoutParams(-2, N.dp(this, 24),
                Gravity.BOTTOM | Gravity.START);
        durationLp.setMargins(N.dp(this, 8), 0, 0, N.dp(this, 8));
        frame.addView(duration, durationLp);

        resolution = text("—", 13, N.WHITE);
        resolution.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams resLp = new LinearLayout.LayoutParams(-1, N.dp(this, 34));
        resLp.topMargin = N.dp(this, 6);
        root.addView(resolution, resLp);

        LinearLayout actions = new LinearLayout(this);
        actions.setOrientation(LinearLayout.HORIZONTAL);
        actions.setGravity(Gravity.CENTER_VERTICAL);

        TextView clear = smallButton("キャッシュ消去", N.DGRAY);
        clear.setOnClickListener(v -> {
            loader.cancelPending();
            loader.clearCache();
            loader.clear(preview);
            currentItem = null;
            resolution.setText("—");
            duration.setText("");
            duration.setVisibility(View.GONE);
            playIcon.setVisibility(View.GONE);
            Toast.makeText(this, "サムネイルキャッシュを消去しました", Toast.LENGTH_SHORT).show();
        });
        actions.addView(clear, new LinearLayout.LayoutParams(N.dp(this, 132), N.dp(this, 48)));

        View flexible = new View(this);
        actions.addView(flexible, new LinearLayout.LayoutParams(0, 1, 1f));

        TextView close = smallButton("閉じる", N.LBLUE);
        close.setOnClickListener(v -> finish());
        actions.addView(close, new LinearLayout.LayoutParams(N.dp(this, 92), N.dp(this, 48)));

        LinearLayout.LayoutParams actionsLp = new LinearLayout.LayoutParams(-1, N.dp(this, 48));
        actionsLp.topMargin = N.dp(this, 10);
        root.addView(actions, actionsLp);

        return scroll;
    }

    private void setKind(NThumbnailLoader.Kind next) {
        if (kind == next) return;
        kind = next;
        imageType.setBackground(N.round(kind == NThumbnailLoader.Kind.IMAGE ? N.LBLUE : N.DGRAY, 21, this));
        videoType.setBackground(N.round(kind == NThumbnailLoader.Kind.VIDEO ? N.LBLUE : N.DGRAY, 21, this));
        DiagLog.write(this, "THUMB_DEMO_KIND kind=" + kind);
    }

    private void updateMetadata(NThumbnailLoader.Item item) {
        if (item == null) return;
        String size = item.width > 0 && item.height > 0 ? item.width + " × " + item.height : "—";
        resolution.setText(size);
        if (item.kind == NThumbnailLoader.Kind.VIDEO && item.durationMs > 0L) {
            duration.setText(formatDuration(item.durationMs));
            duration.setVisibility(View.VISIBLE);
        } else {
            duration.setText("");
            duration.setVisibility(View.GONE);
        }
    }

    private TextView button(String label) {
        TextView t = text(label, 16, N.TEXT);
        t.setGravity(Gravity.CENTER);
        t.setBackground(N.round(N.LBLUE, 24, this));
        t.setClickable(true);
        t.setFocusable(true);
        return t;
    }

    private TextView capsule(String label, boolean selected) {
        TextView t = text(label, 14, N.TEXT);
        t.setGravity(Gravity.CENTER);
        t.setBackground(N.round(selected ? N.LBLUE : N.DGRAY, 21, this));
        t.setClickable(true);
        t.setFocusable(true);
        return t;
    }

    private TextView smallButton(String label, int color) {
        TextView t = text(label, 14, N.TEXT);
        t.setGravity(Gravity.CENTER);
        t.setBackground(N.round(color, 24, this));
        t.setClickable(true);
        t.setFocusable(true);
        return t;
    }

    private TextView text(String value, float sp, int color) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextColor(color);
        t.setTextSize(sp);
        return t;
    }

    private GradientDrawable round(int color, float radiusDp) {
        return N.round(color, radiusDp, this);
    }

    private static boolean looksLikeHttpUrl(String value) {
        if (TextUtils.isEmpty(value)) return false;
        try {
            URL u = new URL(value);
            return "http".equalsIgnoreCase(u.getProtocol()) || "https".equalsIgnoreCase(u.getProtocol());
        } catch (Exception ignored) {
            return false;
        }
    }

    private static String formatDuration(long durationMs) {
        long totalSeconds = Math.max(0L, durationMs / 1000L);
        long minutes = totalSeconds / 60L;
        long seconds = totalSeconds % 60L;
        return String.format(java.util.Locale.US, "%d:%02d", minutes, seconds);
    }

    @Override
    protected void onDestroy() {
        if (loader != null) loader.shutdown();
        super.onDestroy();
    }

    private static final class SquareFrameLayout extends FrameLayout {
        SquareFrameLayout(android.content.Context context) {
            super(context);
        }

        @Override
        protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
            int width = MeasureSpec.getSize(widthMeasureSpec);
            int size = Math.max(1, width);
            super.onMeasure(
                    MeasureSpec.makeMeasureSpec(size, MeasureSpec.EXACTLY),
                    MeasureSpec.makeMeasureSpec(size, MeasureSpec.EXACTLY));
        }
    }

    private static final class PlayIcon extends View {
        private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);

        PlayIcon(android.content.Context context) {
            super(context);
            paint.setStyle(Paint.Style.FILL);
        }

        @Override
        protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            float w = getWidth();
            float h = getHeight();
            float cx = w / 2f;
            float cy = h / 2f;
            paint.setColor(0xAA252020);
            canvas.drawCircle(cx, cy, Math.min(w, h) * 0.47f, paint);
            paint.setColor(N.TEXT);
            android.graphics.Path path = new android.graphics.Path();
            float s = Math.min(w, h) * 0.22f;
            path.moveTo(cx - s * 0.55f, cy - s);
            path.lineTo(cx + s, cy);
            path.lineTo(cx - s * 0.55f, cy + s);
            path.close();
            canvas.drawPath(path, paint);
        }
    }
}
