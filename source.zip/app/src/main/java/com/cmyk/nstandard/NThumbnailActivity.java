package com.cmyk.nstandard;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.GridLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

/**
 * Thumbnail/UI sandbox for N Standard.
 *
 * This screen intentionally concentrates image controls inside the image panel,
 * while the cell emulator remains an independent component below it.
 */
public class NThumbnailActivity extends Activity {
    private static final int REQ_CAPTURE_IMAGE = 3002;

    private final List<ThumbnailCell> thumbnailCells = new ArrayList<>();
    private GridLayout thumbnailGrid;
    private boolean selectionMode = false;

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        DiagLog.write(this, "OPEN_THUMBNAIL_DEMO");
        setContentView(buildUi());
    }

    private View buildUi() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(N.BG);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(N.dp(this, 25), N.dp(this, 24), N.dp(this, 25), N.dp(this, 24));
        root.setBackgroundColor(N.BG);
        scroll.addView(root, new ScrollView.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        TextView title = text("サムネイル", 24, N.TEXT);
        title.setGravity(Gravity.START | Gravity.CENTER_VERTICAL);
        LinearLayout.LayoutParams titleLp = new LinearLayout.LayoutParams(-1, N.dp(this, 52));
        titleLp.topMargin = N.dp(this, 50);
        root.addView(title, titleLp);

        LinearLayout imageArea = new LinearLayout(this);
        imageArea.setOrientation(LinearLayout.VERTICAL);
        imageArea.setPadding(N.dp(this, 14), N.dp(this, 14), N.dp(this, 14), N.dp(this, 14));
        imageArea.setBackground(N.round(N.GRAY, 18, this));
        LinearLayout.LayoutParams imageAreaLp = new LinearLayout.LayoutParams(-1, -2);
        imageAreaLp.topMargin = N.dp(this, 18);
        root.addView(imageArea, imageAreaLp);

        TextView imageAreaTitle = text("画像エリア", 14, N.TEXT);
        imageAreaTitle.setGravity(Gravity.START | Gravity.CENTER_VERTICAL);
        imageArea.addView(imageAreaTitle, new LinearLayout.LayoutParams(-1, N.dp(this, 28)));

        TextView capture = button("撮影");
        capture.setOnClickListener(v -> openCamera());
        LinearLayout.LayoutParams captureLp = new LinearLayout.LayoutParams(-1, N.dp(this, 48));
        captureLp.topMargin = N.dp(this, 10);
        imageArea.addView(capture, captureLp);

        LinearLayout selectionRow = new LinearLayout(this);
        selectionRow.setOrientation(LinearLayout.HORIZONTAL);
        selectionRow.setGravity(Gravity.CENTER_VERTICAL | Gravity.END);

        View selectionSpacer = new View(this);
        selectionRow.addView(selectionSpacer, new LinearLayout.LayoutParams(0, 1, 1f));

        TextView selectAll = smallButton("全て選択", N.DGRAY);
        selectAll.setOnClickListener(v -> {
            selectionMode = true;
            for (ThumbnailCell cell : thumbnailCells) cell.setSelectedState(true);
            DiagLog.write(this, "THUMB_SELECT_ALL count=" + thumbnailCells.size());
        });
        selectionRow.addView(selectAll,
                new LinearLayout.LayoutParams(N.dp(this, 116), N.dp(this, 44)));

        TextView select = smallButton("選択", N.LBLUE);
        select.setOnClickListener(v -> {
            selectionMode = !selectionMode;
            if (!selectionMode) {
                for (ThumbnailCell cell : thumbnailCells) cell.setSelectedState(false);
            }
            DiagLog.write(this, "THUMB_SELECTION_MODE enabled=" + selectionMode);
        });
        LinearLayout.LayoutParams selectLp = new LinearLayout.LayoutParams(
                N.dp(this, 92), N.dp(this, 44));
        selectLp.leftMargin = N.dp(this, 10);
        selectionRow.addView(select, selectLp);

        LinearLayout.LayoutParams selectionRowLp = new LinearLayout.LayoutParams(-1, N.dp(this, 44));
        selectionRowLp.topMargin = N.dp(this, 12);
        imageArea.addView(selectionRow, selectionRowLp);

        thumbnailGrid = new GridLayout(this);
        thumbnailGrid.setColumnCount(3);
        thumbnailGrid.setAlignmentMode(GridLayout.ALIGN_BOUNDS);
        thumbnailGrid.setUseDefaultMargins(false);
        thumbnailGrid.setPadding(0, N.dp(this, 14), 0, N.dp(this, 4));
        thumbnailGrid.setMinimumHeight(N.dp(this, 210));
        imageArea.addView(thumbnailGrid, new LinearLayout.LayoutParams(-1, -2));

        // Independent sandbox: no thumbnail state is passed into this component.
        NEmulatorArea emulatorArea = new NEmulatorArea(this);
        LinearLayout.LayoutParams emulatorLp = new LinearLayout.LayoutParams(-1, -2);
        emulatorLp.topMargin = N.dp(this, 18);
        root.addView(emulatorArea, emulatorLp);

        LinearLayout actions = new LinearLayout(this);
        actions.setOrientation(LinearLayout.HORIZONTAL);
        actions.setGravity(Gravity.CENTER_VERTICAL);

        TextView clear = smallButton("キャッシュ消去", N.DGRAY);
        clear.setOnClickListener(v -> {
            thumbnailCells.clear();
            thumbnailGrid.removeAllViews();
            selectionMode = false;
            Toast.makeText(this, "サムネイル表示を消去しました", Toast.LENGTH_SHORT).show();
            DiagLog.write(this, "THUMB_DEMO_CLEAR");
        });
        actions.addView(clear, new LinearLayout.LayoutParams(N.dp(this, 132), N.dp(this, 48)));

        View flexible = new View(this);
        actions.addView(flexible, new LinearLayout.LayoutParams(0, 1, 1f));

        TextView close = smallButton("閉じる", N.LBLUE);
        close.setOnClickListener(v -> finish());
        actions.addView(close, new LinearLayout.LayoutParams(N.dp(this, 92), N.dp(this, 48)));

        LinearLayout.LayoutParams actionsLp = new LinearLayout.LayoutParams(-1, N.dp(this, 48));
        actionsLp.topMargin = N.dp(this, 10);
        root.addView(actions, actionsLp);

        return scroll;
    }

    private void openCamera() {
        Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        if (intent.resolveActivity(getPackageManager()) == null) {
            Toast.makeText(this, "カメラを起動できません", Toast.LENGTH_SHORT).show();
            return;
        }
        DiagLog.write(this, "THUMB_DEMO_CAMERA_OPEN");
        startActivityForResult(intent, REQ_CAPTURE_IMAGE);
    }

    @Override
    @SuppressWarnings("deprecation")
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != REQ_CAPTURE_IMAGE || resultCode != RESULT_OK || data == null) return;

        Object value = data.getExtras() == null ? null : data.getExtras().get("data");
        if (!(value instanceof Bitmap)) {
            Toast.makeText(this, "撮影画像を取得できませんでした", Toast.LENGTH_SHORT).show();
            DiagLog.write(this, "THUMB_DEMO_CAMERA_NO_BITMAP");
            return;
        }

        addThumbnailCell((Bitmap) value);
        DiagLog.write(this, "THUMB_DEMO_CAMERA_ADD count=" + thumbnailCells.size());
    }

    private void addThumbnailCell(Bitmap bitmap) {
        final int screenWidth = getResources().getDisplayMetrics().widthPixels;
        final int gap = N.dp(this, 8);
        final int horizontalSpace = N.dp(this, 50 + 28) + gap * 2;
        final int cellSize = Math.max(N.dp(this, 72), (screenWidth - horizontalSpace) / 3);

        ThumbnailCell cell = new ThumbnailCell(this, bitmap);
        cell.setOnClickListener(v -> {
            if (!selectionMode) return;
            cell.setSelectedState(!cell.isSelectedState());
        });
        thumbnailCells.add(cell);

        GridLayout.LayoutParams lp = new GridLayout.LayoutParams();
        lp.width = cellSize;
        lp.height = cellSize;
        int column = (thumbnailCells.size() - 1) % 3;
        lp.setMargins(column == 0 ? 0 : gap / 2, 0, column == 2 ? 0 : gap / 2, gap);
        thumbnailGrid.addView(cell, lp);
    }

    private TextView button(String label) {
        TextView t = text(label, 16, N.TEXT);
        t.setGravity(Gravity.CENTER);
        t.setBackground(N.round(N.LBLUE, 24, this));
        t.setClickable(true);
        t.setFocusable(true);
        return t;
    }

    private TextView smallButton(String label, int color) {
        TextView t = text(label, 14, N.TEXT);
        t.setGravity(Gravity.CENTER);
        t.setBackground(N.round(color, 24, this));
        t.setClickable(true);
        t.setFocusable(true);
        return t;
    }

    private TextView text(String value, float sp, int color) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextColor(color);
        t.setTextSize(sp);
        return t;
    }

    private static final class ThumbnailCell extends FrameLayout {
        private final CheckView check;
        private boolean selected;

        ThumbnailCell(android.content.Context context, Bitmap bitmap) {
            super(context);
            setBackground(N.round(N.DGRAY, 12, context));
            setClipToOutline(true);

            ImageView image = new ImageView(context);
            image.setImageBitmap(bitmap);
            image.setScaleType(ImageView.ScaleType.CENTER_CROP);
            addView(image, new FrameLayout.LayoutParams(-1, -1));

            check = new CheckView(context);
            check.setVisibility(GONE);
            FrameLayout.LayoutParams checkLp = new FrameLayout.LayoutParams(
                    N.dp(context, 34), N.dp(context, 34), Gravity.TOP | Gravity.END);
            checkLp.setMargins(0, N.dp(context, 6), N.dp(context, 6), 0);
            addView(check, checkLp);
        }

        boolean isSelectedState() {
            return selected;
        }

        void setSelectedState(boolean selected) {
            this.selected = selected;
            check.setVisibility(selected ? VISIBLE : GONE);
        }
    }

    private static final class CheckView extends View {
        private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);

        CheckView(android.content.Context context) {
            super(context);
            paint.setStrokeCap(Paint.Cap.SQUARE);
            paint.setStrokeJoin(Paint.Join.MITER);
        }

        @Override
        protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            float w = getWidth();
            float h = getHeight();
            float r = Math.min(w, h) * 0.48f;
            float cx = w / 2f;
            float cy = h / 2f;

            paint.setStyle(Paint.Style.FILL);
            paint.setColor(N.GREEN);
            canvas.drawCircle(cx, cy, r, paint);

            paint.setStyle(Paint.Style.STROKE);
            paint.setStrokeWidth(Math.max(3f, Math.min(w, h) * 0.10f));
            paint.setColor(N.TEXT);
            android.graphics.Path p = new android.graphics.Path();
            p.moveTo(w * 0.26f, h * 0.52f);
            p.lineTo(w * 0.43f, h * 0.69f);
            p.lineTo(w * 0.76f, h * 0.34f);
            canvas.drawPath(p, paint);
        }
    }
}
