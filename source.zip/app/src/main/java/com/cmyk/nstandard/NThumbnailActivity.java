package com.cmyk.nstandard;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.text.InputType;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.GridLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.InputStream;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/** Demo/sandbox for N Standard thumbnail, cell and selection behaviour. */
public class NThumbnailActivity extends Activity {
    private static final int REQ_PICK_IMAGE = 3001;
    private static final int REQ_CAPTURE_IMAGE = 3002;

    private final List<CellItem> cells = new ArrayList<>();
    private boolean selectionMode = false;
    private int selectionAnchorPosition = -1;
    private int nextCellNumber = 1;
    private int draftCellIndex = -1;

    private NThumbnailLoader loader;
    private NThumbnailLoader.Kind kind = NThumbnailLoader.Kind.IMAGE;
    private NThumbnailLoader.Item currentItem;
    private ImageView preview;
    private PlayIcon playIcon;
    private TextView resolution;
    private TextView duration;
    private TextView imageType;
    private TextView videoType;
    private GridLayout cellGrid;
    private TextView selectionButton;
    private TextView selectionCount;

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        DiagLog.write(this, "OPEN_THUMBNAIL_DEMO");
        loader = new NThumbnailLoader(this, item -> {
            if (item != currentItem) return;
            updateMetadata(item);
        });
        setContentView(buildUi());
    }

    private View buildUi() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(N.BG);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(N.dp(this, 25), N.dp(this, 24), N.dp(this, 25), N.dp(this, 24));
        root.setBackgroundColor(N.BG);
        scroll.addView(root, new ScrollView.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        TextView title = text("サムネイル", 24, N.TEXT);
        title.setGravity(Gravity.START | Gravity.CENTER_VERTICAL);
        LinearLayout.LayoutParams titleLp = new LinearLayout.LayoutParams(-1, N.dp(this, 52));
        titleLp.topMargin = N.dp(this, 50);
        root.addView(title, titleLp);

        // Cell field is deliberately above the image/emulator demo areas.
        LinearLayout cellField = new LinearLayout(this);
        cellField.setOrientation(LinearLayout.VERTICAL);
        cellField.setPadding(N.dp(this, 14), N.dp(this, 14), N.dp(this, 14), N.dp(this, 14));
        cellField.setBackground(N.round(N.GRAY, 18, this));
        LinearLayout.LayoutParams fieldLp = new LinearLayout.LayoutParams(-1, -2);
        fieldLp.topMargin = N.dp(this, 18);
        root.addView(cellField, fieldLp);

        LinearLayout fieldHeader = new LinearLayout(this);
        fieldHeader.setOrientation(LinearLayout.HORIZONTAL);
        fieldHeader.setGravity(Gravity.CENTER_VERTICAL);
        TextView fieldTitle = text("セルフィールド", 14, N.TEXT);
        fieldHeader.addView(fieldTitle, new LinearLayout.LayoutParams(0, N.dp(this, 38), 1f));

        selectionCount = text("選択 0", 13, N.WHITE);
        selectionCount.setGravity(Gravity.CENTER_VERTICAL | Gravity.END);
        selectionCount.setVisibility(View.GONE);
        fieldHeader.addView(selectionCount, new LinearLayout.LayoutParams(N.dp(this, 72), N.dp(this, 38)));

        selectionButton = smallButton("選択", N.DGRAY);
        selectionButton.setOnClickListener(v -> handleSelectionButton());
        LinearLayout.LayoutParams selectLp = new LinearLayout.LayoutParams(N.dp(this, 86), N.dp(this, 38));
        selectLp.leftMargin = N.dp(this, 8);
        fieldHeader.addView(selectionButton, selectLp);
        cellField.addView(fieldHeader, new LinearLayout.LayoutParams(-1, N.dp(this, 38)));

        cellGrid = new GridLayout(this);
        cellGrid.setColumnCount(3);
        cellGrid.setAlignmentMode(GridLayout.ALIGN_BOUNDS);
        cellGrid.setUseDefaultMargins(false);
        LinearLayout.LayoutParams gridLp = new LinearLayout.LayoutParams(-1, -2);
        gridLp.topMargin = N.dp(this, 10);
        cellField.addView(cellGrid, gridLp);
        renderCells();

        // Image-related controls stay inside this panel.
        LinearLayout imageArea = new LinearLayout(this);
        imageArea.setOrientation(LinearLayout.VERTICAL);
        imageArea.setPadding(N.dp(this, 14), N.dp(this, 14), N.dp(this, 14), N.dp(this, 14));
        imageArea.setBackground(N.round(N.GRAY, 18, this));
        LinearLayout.LayoutParams imageAreaLp = new LinearLayout.LayoutParams(-1, -2);
        imageAreaLp.topMargin = N.dp(this, 18);
        root.addView(imageArea, imageAreaLp);

        TextView imageAreaTitle = text("画像エリア", 14, N.TEXT);
        imageAreaTitle.setGravity(Gravity.START | Gravity.CENTER_VERTICAL);
        imageArea.addView(imageAreaTitle, new LinearLayout.LayoutParams(-1, N.dp(this, 28)));

        EditText url = new EditText(this);
        url.setHint("画像または動画URL");
        url.setHintTextColor(N.LGRAY);
        url.setTextColor(N.TEXT);
        url.setTextSize(14);
        url.setSingleLine(true);
        url.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        url.setPadding(N.dp(this, 16), 0, N.dp(this, 16), 0);
        url.setBackground(N.round(N.DGRAY, 12, this));
        LinearLayout.LayoutParams urlLp = new LinearLayout.LayoutParams(-1, N.dp(this, 48));
        urlLp.topMargin = N.dp(this, 8);
        imageArea.addView(url, urlLp);

        LinearLayout typeRow = new LinearLayout(this);
        typeRow.setOrientation(LinearLayout.HORIZONTAL);
        typeRow.setGravity(Gravity.START | Gravity.CENTER_VERTICAL);
        imageType = capsule("画像", true);
        videoType = capsule("動画", false);
        imageType.setOnClickListener(v -> setKind(NThumbnailLoader.Kind.IMAGE));
        videoType.setOnClickListener(v -> setKind(NThumbnailLoader.Kind.VIDEO));
        typeRow.addView(imageType, new LinearLayout.LayoutParams(N.dp(this, 92), N.dp(this, 42)));
        LinearLayout.LayoutParams videoLp = new LinearLayout.LayoutParams(N.dp(this, 92), N.dp(this, 42));
        videoLp.leftMargin = N.dp(this, 10);
        typeRow.addView(videoType, videoLp);
        LinearLayout.LayoutParams typeLp = new LinearLayout.LayoutParams(-1, N.dp(this, 42));
        typeLp.topMargin = N.dp(this, 12);
        imageArea.addView(typeRow, typeLp);

        TextView load = button("読み込み");
        load.setOnClickListener(v -> {
            String value = url.getText().toString().trim();
            if (!looksLikeHttpUrl(value)) {
                Toast.makeText(this, "http/https URLを入力してください", Toast.LENGTH_SHORT).show();
                return;
            }
            currentItem = new NThumbnailLoader.Item(value, kind);
            resolution.setText("—");
            duration.setText("");
            duration.setVisibility(View.GONE);
            preview.setAlpha(0.55f);
            playIcon.setVisibility(kind == NThumbnailLoader.Kind.VIDEO ? View.VISIBLE : View.GONE);
            DiagLog.write(this, "THUMB_DEMO_LOAD kind=" + kind + " url=" + value);
            loader.load(preview, currentItem);
        });
        LinearLayout.LayoutParams loadLp = new LinearLayout.LayoutParams(-1, N.dp(this, 48));
        loadLp.topMargin = N.dp(this, 12);
        imageArea.addView(load, loadLp);

        LinearLayout imageButtons = new LinearLayout(this);
        imageButtons.setOrientation(LinearLayout.HORIZONTAL);
        TextView capture = button("撮影");
        capture.setOnClickListener(v -> openCamera());
        imageButtons.addView(capture, new LinearLayout.LayoutParams(0, N.dp(this, 48), 1f));

        TextView addImage = button("画像追加");
        addImage.setOnClickListener(v -> openImagePicker());
        LinearLayout.LayoutParams addImageLp = new LinearLayout.LayoutParams(0, N.dp(this, 48), 1f);
        addImageLp.leftMargin = N.dp(this, 10);
        imageButtons.addView(addImage, addImageLp);
        LinearLayout.LayoutParams imageButtonsLp = new LinearLayout.LayoutParams(-1, N.dp(this, 48));
        imageButtonsLp.topMargin = N.dp(this, 10);
        imageArea.addView(imageButtons, imageButtonsLp);

        SquareFrameLayout frame = new SquareFrameLayout(this);
        frame.setBackground(N.round(N.DGRAY, 12, this));
        frame.setClipToOutline(true);
        LinearLayout.LayoutParams frameLp = new LinearLayout.LayoutParams(-1, -2);
        frameLp.topMargin = N.dp(this, 18);
        imageArea.addView(frame, frameLp);

        preview = new ImageView(this);
        preview.setScaleType(ImageView.ScaleType.CENTER_CROP);
        preview.setBackground(N.round(N.DGRAY, 12, this));
        preview.setClipToOutline(true);
        preview.setAlpha(0.55f);
        frame.addView(preview, new FrameLayout.LayoutParams(-1, -1));

        playIcon = new PlayIcon(this);
        playIcon.setVisibility(View.GONE);
        FrameLayout.LayoutParams playLp = new FrameLayout.LayoutParams(
                N.dp(this, 52), N.dp(this, 52), Gravity.CENTER);
        frame.addView(playIcon, playLp);

        duration = text("", 11, N.TEXT);
        duration.setGravity(Gravity.CENTER);
        duration.setSingleLine(true);
        duration.setPadding(N.dp(this, 7), 0, N.dp(this, 7), 0);
        duration.setBackground(round(0xAA252020, 5));
        duration.setVisibility(View.GONE);
        FrameLayout.LayoutParams durationLp = new FrameLayout.LayoutParams(-2, N.dp(this, 24),
                Gravity.BOTTOM | Gravity.START);
        durationLp.setMargins(N.dp(this, 8), 0, 0, N.dp(this, 8));
        frame.addView(duration, durationLp);

        resolution = text("—", 13, N.WHITE);
        resolution.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams resLp = new LinearLayout.LayoutParams(-1, N.dp(this, 34));
        resLp.topMargin = N.dp(this, 6);
        imageArea.addView(resolution, resLp);

        // Standalone emulator: exactly two actions, no image/cell state owned here.
        NEmulatorArea emulatorArea = new NEmulatorArea(this);
        emulatorArea.setListener(new NEmulatorArea.Listener() {
            @Override public void onAddCell() { addDraftCell(); }
            @Override public void onConfirmCell() { confirmDraftCell(); }
        });
        LinearLayout.LayoutParams emulatorLp = new LinearLayout.LayoutParams(-1, -2);
        emulatorLp.topMargin = N.dp(this, 18);
        root.addView(emulatorArea, emulatorLp);

        LinearLayout actions = new LinearLayout(this);
        actions.setOrientation(LinearLayout.HORIZONTAL);
        actions.setGravity(Gravity.CENTER_VERTICAL);

        TextView clear = smallButton("キャッシュ消去", N.DGRAY);
        clear.setOnClickListener(v -> {
            loader.cancelPending();
            loader.clearCache();
            loader.clear(preview);
            currentItem = null;
            resolution.setText("—");
            duration.setText("");
            duration.setVisibility(View.GONE);
            playIcon.setVisibility(View.GONE);
            preview.setAlpha(0.55f);
            Toast.makeText(this, "サムネイルキャッシュを消去しました", Toast.LENGTH_SHORT).show();
        });
        actions.addView(clear, new LinearLayout.LayoutParams(N.dp(this, 132), N.dp(this, 48)));

        View flexible = new View(this);
        actions.addView(flexible, new LinearLayout.LayoutParams(0, 1, 1f));

        TextView close = smallButton("閉じる", N.LBLUE);
        close.setOnClickListener(v -> finish());
        actions.addView(close, new LinearLayout.LayoutParams(N.dp(this, 92), N.dp(this, 48)));

        LinearLayout.LayoutParams actionsLp = new LinearLayout.LayoutParams(-1, N.dp(this, 48));
        actionsLp.topMargin = N.dp(this, 10);
        root.addView(actions, actionsLp);

        return scroll;
    }

    private void openImagePicker() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("image/*");
        DiagLog.write(this, "THUMB_DEMO_PICK_IMAGE_OPEN");
        startActivityForResult(intent, REQ_PICK_IMAGE);
    }

    private void openCamera() {
        Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        if (intent.resolveActivity(getPackageManager()) == null) {
            Toast.makeText(this, "カメラを起動できません", Toast.LENGTH_SHORT).show();
            return;
        }
        DiagLog.write(this, "THUMB_DEMO_CAPTURE_OPEN");
        startActivityForResult(intent, REQ_CAPTURE_IMAGE);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != RESULT_OK) return;

        if (requestCode == REQ_PICK_IMAGE && data != null) {
            Uri uri = data.getData();
            if (uri == null) return;
            try {
                getContentResolver().takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION);
            } catch (Exception ignored) {
                // Persistable permission is optional for this UI demo.
            }
            showLocalImage(uri);
            addImageCell(uri, null);
            DiagLog.write(this, "THUMB_DEMO_PICK_IMAGE uri=" + uri);
            return;
        }

        if (requestCode == REQ_CAPTURE_IMAGE && data != null && data.getExtras() != null) {
            Object value = data.getExtras().get("data");
            if (value instanceof Bitmap) {
                Bitmap bitmap = (Bitmap) value;
                loader.cancelPending();
                currentItem = null;
                kind = NThumbnailLoader.Kind.IMAGE;
                imageType.setBackground(N.round(N.LBLUE, 21, this));
                videoType.setBackground(N.round(N.DGRAY, 21, this));
                playIcon.setVisibility(View.GONE);
                duration.setText("");
                duration.setVisibility(View.GONE);
                preview.setAlpha(1f);
                preview.setImageBitmap(bitmap);
                resolution.setText(bitmap.getWidth() + " × " + bitmap.getHeight());
                addImageCell(null, bitmap.copy(bitmap.getConfig() == null ? Bitmap.Config.ARGB_8888 : bitmap.getConfig(), false));
                DiagLog.write(this, "THUMB_DEMO_CAPTURE_OK " + bitmap.getWidth() + "x" + bitmap.getHeight());
            }
        }
    }

    private void showLocalImage(Uri uri) {
        loader.cancelPending();
        currentItem = null;
        kind = NThumbnailLoader.Kind.IMAGE;
        imageType.setBackground(N.round(N.LBLUE, 21, this));
        videoType.setBackground(N.round(N.DGRAY, 21, this));
        playIcon.setVisibility(View.GONE);
        duration.setText("");
        duration.setVisibility(View.GONE);
        preview.setAlpha(1f);
        preview.setImageURI(uri);
        updateLocalImageResolution(uri);
    }

    private void addImageCell(Uri uri, Bitmap bitmap) {
        cells.add(CellItem.image(uri, bitmap, System.currentTimeMillis()));
        renderCells();
        DiagLog.write(this, "CELL_IMAGE_ADD count=" + cells.size());
    }

    private void addDraftCell() {
        CellItem item = CellItem.placeholder("CELL " + String.format(Locale.US, "%03d", nextCellNumber++), System.currentTimeMillis());
        cells.add(item);
        draftCellIndex = cells.size() - 1;
        renderCells();
        DiagLog.write(this, "CELL_ADD position=" + draftCellIndex);
    }

    private void confirmDraftCell() {
        if (draftCellIndex < 0 || draftCellIndex >= cells.size()) {
            Toast.makeText(this, "確定するセルがありません", Toast.LENGTH_SHORT).show();
            return;
        }
        CellItem item = cells.get(draftCellIndex);
        item.confirmed = true;
        item.timestamp = System.currentTimeMillis();
        int confirmed = draftCellIndex;
        draftCellIndex = -1;
        renderCells();
        DiagLog.write(this, "CELL_CONFIRM position=" + confirmed);
    }

    private void renderCells() {
        if (cellGrid == null) return;
        cellGrid.removeAllViews();
        if (cells.isEmpty()) {
            TextView empty = text("画像／セルはここに追加されます", 13, N.LGRAY);
            empty.setGravity(Gravity.CENTER);
            GridLayout.LayoutParams emptyLp = new GridLayout.LayoutParams();
            emptyLp.width = GridLayout.LayoutParams.MATCH_PARENT;
            emptyLp.height = N.dp(this, 72);
            emptyLp.columnSpec = GridLayout.spec(0, 3, 1f);
            cellGrid.addView(empty, emptyLp);
            updateSelectionControls();
            return;
        }

        int gap = N.dp(this, 8);
        int screenWidth = getResources().getDisplayMetrics().widthPixels;
        int contentWidth = screenWidth - N.dp(this, 50 + 28); // root 25x2 + field padding 14x2
        int cellWidth = Math.max(N.dp(this, 86), (contentWidth - gap * 2) / 3);

        for (int i = 0; i < cells.size(); i++) {
            final int position = i;
            CellItem item = cells.get(i);
            LinearLayout card = buildCellCard(item, position, cellWidth);
            GridLayout.LayoutParams lp = new GridLayout.LayoutParams();
            lp.width = cellWidth;
            lp.height = GridLayout.LayoutParams.WRAP_CONTENT;
            lp.columnSpec = GridLayout.spec(i % 3, 1f);
            lp.rowSpec = GridLayout.spec(i / 3);
            if (i % 3 != 0) lp.leftMargin = gap;
            lp.bottomMargin = gap;
            cellGrid.addView(card, lp);
        }
        updateSelectionControls();
    }

    private LinearLayout buildCellCard(CellItem item, int position, int width) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(N.dp(this, 5), N.dp(this, 5), N.dp(this, 5), N.dp(this, 6));
        card.setBackground(N.round(selectionMode && item.selected ? N.LBLUE : N.DGRAY, 10, this));
        card.setClickable(true);
        card.setFocusable(true);

        FrameLayout visual = new FrameLayout(this);
        visual.setBackground(N.round(N.BG, 7, this));
        visual.setClipToOutline(true);
        card.addView(visual, new LinearLayout.LayoutParams(-1, Math.max(N.dp(this, 68), width - N.dp(this, 10))));

        if (item.uri != null || item.bitmap != null) {
            ImageView image = new ImageView(this);
            image.setScaleType(ImageView.ScaleType.CENTER_CROP);
            if (item.bitmap != null) image.setImageBitmap(item.bitmap);
            else image.setImageURI(item.uri);
            visual.addView(image, new FrameLayout.LayoutParams(-1, -1));
        } else {
            TextView label = text(item.label + (item.confirmed ? " ✓" : ""), 13, N.TEXT);
            label.setGravity(Gravity.CENTER);
            visual.addView(label, new FrameLayout.LayoutParams(-1, -1));
        }

        if (selectionMode && item.selected) {
            TextView check = text("✓", 18, N.TEXT);
            check.setGravity(Gravity.CENTER);
            check.setBackground(N.round(N.GREEN, 15, this));
            FrameLayout.LayoutParams checkLp = new FrameLayout.LayoutParams(N.dp(this, 30), N.dp(this, 30), Gravity.TOP | Gravity.END);
            checkLp.setMargins(0, N.dp(this, 5), N.dp(this, 5), 0);
            visual.addView(check, checkLp);
        }

        Date date = new Date(item.timestamp);
        TextView day = text(new SimpleDateFormat("yyyy/MM/dd", Locale.JAPAN).format(date), 10, N.WHITE);
        day.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams dayLp = new LinearLayout.LayoutParams(-1, N.dp(this, 18));
        dayLp.topMargin = N.dp(this, 4);
        card.addView(day, dayLp);

        TextView time = text(new SimpleDateFormat("HH:mm:ss", Locale.JAPAN).format(date), 10, N.LGRAY);
        time.setGravity(Gravity.CENTER);
        card.addView(time, new LinearLayout.LayoutParams(-1, N.dp(this, 17)));

        View.OnClickListener tap = v -> {
            if (selectionMode) toggleSelectionAt(position);
        };
        View.OnLongClickListener longPress = v -> {
            if (!selectionMode) {
                enterSelectionModeWithItem(position);
                return true;
            }
            if (selectRangeFromAnchor(position)) return true;
            if (!cells.get(position).selected) {
                cells.get(position).selected = true;
                selectionAnchorPosition = position;
                DiagLog.write(this, "CELL_SELECT_LONG position=" + position);
                renderCells();
            }
            return true;
        };
        card.setOnClickListener(tap);
        card.setOnLongClickListener(longPress);
        visual.setOnClickListener(tap);
        visual.setOnLongClickListener(longPress);
        day.setOnClickListener(tap);
        day.setOnLongClickListener(longPress);
        time.setOnClickListener(tap);
        time.setOnLongClickListener(longPress);
        return card;
    }

    private void handleSelectionButton() {
        if (!selectionMode) {
            selectionMode = true;
            selectionAnchorPosition = -1;
            DiagLog.write(this, "CELL_SELECTION_MODE_ENTER source=button");
            renderCells();
            return;
        }
        if (areAllCellsSelected()) {
            exitSelectionMode(true, "select_all_toggle_clear");
        } else {
            for (CellItem item : cells) item.selected = true;
            DiagLog.write(this, "CELL_SELECT_ALL count=" + cells.size());
            renderCells();
        }
    }

    private void enterSelectionModeWithItem(int position) {
        if (position < 0 || position >= cells.size()) return;
        selectionMode = true;
        CellItem item = cells.get(position);
        item.selected = true;
        selectionAnchorPosition = position;
        DiagLog.write(this, "CELL_SELECTION_MODE_ENTER source=long_press position=" + position);
        renderCells();
    }

    private void toggleSelectionAt(int position) {
        if (position < 0 || position >= cells.size()) return;
        CellItem item = cells.get(position);
        item.selected = !item.selected;
        if (item.selected) selectionAnchorPosition = position;
        else if (selectionAnchorPosition == position) selectionAnchorPosition = -1;
        DiagLog.write(this, "CELL_SELECT position=" + position + " selected=" + item.selected);
        if (selectionMode && countSelectedCells() == 0) {
            exitSelectionMode(false, "all_deselected_by_tap");
        } else {
            renderCells();
        }
    }

    private boolean selectRangeFromAnchor(int position) {
        if (!selectionMode || selectionAnchorPosition < 0 || position < 0 || position >= cells.size()) return false;
        int anchor = selectionAnchorPosition;
        if (anchor == position || anchor >= cells.size()) return false;
        if (!cells.get(anchor).selected) return false;

        int from = Math.min(anchor, position);
        int to = Math.max(anchor, position);
        for (int i = from + 1; i < to; i++) {
            if (cells.get(i).selected) return false;
        }
        for (int i = from; i <= to; i++) cells.get(i).selected = true;
        selectionAnchorPosition = position;
        DiagLog.write(this, "CELL_RANGE_SELECT anchor=" + anchor + " target=" + position + " range=" + from + "-" + to);
        renderCells();
        return true;
    }

    private void exitSelectionMode(boolean clearSelection, String reason) {
        if (clearSelection) for (CellItem item : cells) item.selected = false;
        selectionMode = false;
        selectionAnchorPosition = -1;
        DiagLog.write(this, "CELL_SELECTION_MODE_EXIT reason=" + reason + " clear=" + clearSelection);
        renderCells();
    }

    private boolean areAllCellsSelected() {
        if (cells.isEmpty()) return false;
        for (CellItem item : cells) if (!item.selected) return false;
        return true;
    }

    private int countSelectedCells() {
        int count = 0;
        for (CellItem item : cells) if (item.selected) count++;
        return count;
    }

    private void updateSelectionControls() {
        if (selectionButton == null || selectionCount == null) return;
        int selected = countSelectedCells();
        selectionCount.setText("選択 " + selected);
        selectionCount.setVisibility(selectionMode ? View.VISIBLE : View.GONE);
        selectionButton.setText(!selectionMode ? "選択" : (areAllCellsSelected() ? "全解除" : "全選択"));
        selectionButton.setBackground(N.round(selectionMode ? N.LBLUE : N.DGRAY, 19, this));
    }

    private void updateLocalImageResolution(Uri uri) {
        BitmapFactory.Options options = new BitmapFactory.Options();
        options.inJustDecodeBounds = true;
        try (InputStream in = getContentResolver().openInputStream(uri)) {
            BitmapFactory.decodeStream(in, null, options);
            if (options.outWidth > 0 && options.outHeight > 0) {
                resolution.setText(options.outWidth + " × " + options.outHeight);
            } else {
                resolution.setText("—");
            }
        } catch (Exception e) {
            resolution.setText("—");
            DiagLog.write(this, "THUMB_DEMO_PICK_IMAGE_META_ERROR " + e.getClass().getSimpleName());
        }
    }

    private void setKind(NThumbnailLoader.Kind next) {
        if (kind == next) return;
        kind = next;
        imageType.setBackground(N.round(kind == NThumbnailLoader.Kind.IMAGE ? N.LBLUE : N.DGRAY, 21, this));
        videoType.setBackground(N.round(kind == NThumbnailLoader.Kind.VIDEO ? N.LBLUE : N.DGRAY, 21, this));
        DiagLog.write(this, "THUMB_DEMO_KIND kind=" + kind);
    }

    private void updateMetadata(NThumbnailLoader.Item item) {
        if (item == null) return;
        String size = item.width > 0 && item.height > 0 ? item.width + " × " + item.height : "—";
        resolution.setText(size);
        if (item.kind == NThumbnailLoader.Kind.VIDEO && item.durationMs > 0L) {
            duration.setText(formatDuration(item.durationMs));
            duration.setVisibility(View.VISIBLE);
        } else {
            duration.setText("");
            duration.setVisibility(View.GONE);
        }
    }

    private TextView button(String label) {
        TextView t = text(label, 16, N.TEXT);
        t.setGravity(Gravity.CENTER);
        t.setBackground(N.round(N.LBLUE, 24, this));
        t.setClickable(true);
        t.setFocusable(true);
        return t;
    }

    private TextView capsule(String label, boolean selected) {
        TextView t = text(label, 14, N.TEXT);
        t.setGravity(Gravity.CENTER);
        t.setBackground(N.round(selected ? N.LBLUE : N.DGRAY, 21, this));
        t.setClickable(true);
        t.setFocusable(true);
        return t;
    }

    private TextView smallButton(String label, int color) {
        TextView t = text(label, 14, N.TEXT);
        t.setGravity(Gravity.CENTER);
        t.setBackground(N.round(color, 24, this));
        t.setClickable(true);
        t.setFocusable(true);
        return t;
    }

    private TextView text(String value, float sp, int color) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextColor(color);
        t.setTextSize(sp);
        return t;
    }

    private GradientDrawable round(int color, float radiusDp) {
        return N.round(color, radiusDp, this);
    }

    private static boolean looksLikeHttpUrl(String value) {
        if (TextUtils.isEmpty(value)) return false;
        try {
            URL u = new URL(value);
            return "http".equalsIgnoreCase(u.getProtocol()) || "https".equalsIgnoreCase(u.getProtocol());
        } catch (Exception ignored) {
            return false;
        }
    }

    private static String formatDuration(long durationMs) {
        long totalSeconds = Math.max(0L, durationMs / 1000L);
        long minutes = totalSeconds / 60L;
        long seconds = totalSeconds % 60L;
        return String.format(Locale.US, "%d:%02d", minutes, seconds);
    }

    @Override
    protected void onDestroy() {
        if (loader != null) loader.shutdown();
        super.onDestroy();
    }

    private static final class CellItem {
        Uri uri;
        Bitmap bitmap;
        String label;
        long timestamp;
        boolean selected;
        boolean confirmed;

        static CellItem image(Uri uri, Bitmap bitmap, long timestamp) {
            CellItem item = new CellItem();
            item.uri = uri;
            item.bitmap = bitmap;
            item.label = "IMAGE";
            item.timestamp = timestamp;
            item.confirmed = true;
            return item;
        }

        static CellItem placeholder(String label, long timestamp) {
            CellItem item = new CellItem();
            item.label = label;
            item.timestamp = timestamp;
            item.confirmed = false;
            return item;
        }
    }

    private static final class SquareFrameLayout extends FrameLayout {
        SquareFrameLayout(android.content.Context context) {
            super(context);
        }

        @Override
        protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
            int width = MeasureSpec.getSize(widthMeasureSpec);
            int size = Math.max(1, width);
            super.onMeasure(
                    MeasureSpec.makeMeasureSpec(size, MeasureSpec.EXACTLY),
                    MeasureSpec.makeMeasureSpec(size, MeasureSpec.EXACTLY));
        }
    }

    private static final class PlayIcon extends View {
        private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);

        PlayIcon(android.content.Context context) {
            super(context);
            paint.setStyle(Paint.Style.FILL);
        }

        @Override
        protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            float w = getWidth();
            float h = getHeight();
            float cx = w / 2f;
            float cy = h / 2f;
            paint.setColor(0xAA252020);
            canvas.drawCircle(cx, cy, Math.min(w, h) * 0.47f, paint);
            paint.setColor(N.TEXT);
            android.graphics.Path path = new android.graphics.Path();
            float s = Math.min(w, h) * 0.22f;
            path.moveTo(cx - s * 0.55f, cy - s);
            path.lineTo(cx + s, cy);
            path.lineTo(cx - s * 0.55f, cy + s);
            path.close();
            canvas.drawPath(path, paint);
        }
    }
}
