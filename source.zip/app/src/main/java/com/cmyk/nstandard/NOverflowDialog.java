package com.cmyk.nstandard;

import android.app.Activity;
import android.app.AlertDialog;
import android.graphics.drawable.GradientDrawable;
import android.view.Window;

/**
 * Three-dot / overflow list dialog extracted from PriceRec v0.1.81.
 * Uses the same system AlertDialog item-list structure and N-gray rounded chrome.
 */
public final class NOverflowDialog {
    public interface ItemListener { void onItem(int which); }

    private NOverflowDialog() {}

    public static void show(Activity activity, String[] items, ItemListener listener) {
        AlertDialog dialog = new AlertDialog.Builder(activity)
                .setItems(items, (d, which) -> {
                    if (listener != null) listener.onItem(which);
                })
                .create();

        dialog.show();
        Window window = dialog.getWindow();
        if (window == null) return;

        // PriceRec v0.1.81 showRoundedDialog() behavior for an item-only menu.
        window.setBackgroundDrawable(roundRect(activity, N.GRAY, 20));
    }

    private static GradientDrawable roundRect(Activity activity, int color, int radiusDp) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(N.dp(activity, radiusDp));
        return d;
    }
}
