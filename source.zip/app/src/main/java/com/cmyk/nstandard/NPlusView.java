package com.cmyk.nstandard;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.view.View;

/**
 * Shared N plus control. Geometry is sourced from BookmarkLauncher's UrlAddWidgetView.
 * Parent layouts choose the rendered size; callers may override colors while keeping the same geometry.
 */
final class NPlusView extends View {
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private int circleColor;
    private int iconColor;
    private float diameterFraction;
    private int strokeColor = Color.TRANSPARENT;
    private float strokeWidthDp = 0f;

    NPlusView(Context context) {
        this(context, N.LBLUE, N.WHITE, 0.78f);
    }

    NPlusView(Context context, int circleColor, int iconColor, float diameterFraction) {
        super(context);
        this.circleColor = circleColor;
        this.iconColor = iconColor;
        this.diameterFraction = Math.max(0.1f, Math.min(1f, diameterFraction));
    }

    void setCircleStroke(int color, float widthDp) {
        strokeColor = color;
        strokeWidthDp = Math.max(0f, widthDp);
        invalidate();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        float diameter = Math.min(getWidth(), getHeight()) * diameterFraction;
        float cx = getWidth() / 2f;
        float cy = getHeight() / 2f;
        float radius = diameter / 2f;

        paint.reset();
        paint.setAntiAlias(true);
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(circleColor);
        canvas.drawCircle(cx, cy, radius, paint);

        if (strokeWidthDp > 0f && Color.alpha(strokeColor) > 0) {
            paint.setStyle(Paint.Style.STROKE);
            paint.setStrokeWidth(dp(strokeWidthDp));
            paint.setColor(strokeColor);
            canvas.drawCircle(cx, cy, Math.max(0f, radius - paint.getStrokeWidth() / 2f), paint);
        }

        paint.setStyle(Paint.Style.STROKE);
        paint.setColor(iconColor);
        paint.setStrokeWidth(Math.max(dp(2f), diameter * 0.055f));
        paint.setStrokeCap(Paint.Cap.SQUARE);
        float arm = diameter * 0.22f;
        canvas.drawLine(cx - arm, cy, cx + arm, cy, paint);
        canvas.drawLine(cx, cy - arm, cx, cy + arm, paint);
    }

    private float dp(float value) {
        return value * getResources().getDisplayMetrics().density;
    }
}
