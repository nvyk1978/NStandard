package com.cmyk.nstandard;

import android.content.Context;
import android.view.Gravity;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

/**
 * Standalone emulator controls for N Standard.
 *
 * This component intentionally owns no store-cell state. It only emits
 * UI actions to its listener, keeping the emulator area detachable from the
 * surrounding demo screen for future specification-sharing use.
 */
public final class NEmulatorArea extends LinearLayout {
    public interface Listener {
        void onAddCell();
        void onConfirmCell();
    }

    private Listener listener;

    public NEmulatorArea(Context context) {
        super(context);
        setOrientation(HORIZONTAL);
        setGravity(Gravity.CENTER_VERTICAL);
        setPadding(N.dp(context, 14), N.dp(context, 14), N.dp(context, 14), N.dp(context, 14));
        setBackground(N.round(N.GRAY, 18, context));

        TextView add = button(context, "セル追加");
        add.setOnClickListener(v -> {
            if (listener != null) listener.onAddCell();
        });
        addView(add, new LayoutParams(0, N.dp(context, 48), 1f));

        TextView confirm = button(context, "セル確定");
        confirm.setOnClickListener(v -> {
            if (listener != null) listener.onConfirmCell();
        });
        LayoutParams confirmLp = new LayoutParams(0, N.dp(context, 48), 1f);
        confirmLp.leftMargin = N.dp(context, 10);
        addView(confirm, confirmLp);
    }

    public void setListener(Listener listener) {
        this.listener = listener;
    }

    private TextView button(Context context, String label) {
        TextView t = new TextView(context);
        t.setText(label);
        t.setTextColor(N.TEXT);
        t.setTextSize(15);
        t.setGravity(Gravity.CENTER);
        t.setBackground(N.round(N.LBLUE, 24, context));
        t.setClickable(true);
        t.setFocusable(true);
        t.setLayoutParams(new LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, N.dp(context, 48)));
        return t;
    }
}
