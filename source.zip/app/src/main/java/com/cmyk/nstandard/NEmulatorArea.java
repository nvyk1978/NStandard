package com.cmyk.nstandard;

import android.content.Context;
import android.view.Gravity;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

/**
 * Standalone emulator placeholder for N Standard.
 *
 * Keep this component independent from thumbnail/image state so it can evolve
 * into a reusable specification-preview/share area without coupling to the
 * surrounding demo screen.
 */
public final class NEmulatorArea extends LinearLayout {
    public NEmulatorArea(Context context) {
        super(context);
        setOrientation(VERTICAL);
        setPadding(N.dp(context, 14), N.dp(context, 14), N.dp(context, 14), N.dp(context, 14));
        setBackground(N.round(N.GRAY, 18, context));

        TextView title = new TextView(context);
        title.setText("エミュレータ");
        title.setTextColor(N.TEXT);
        title.setTextSize(14);
        title.setGravity(Gravity.START | Gravity.CENTER_VERTICAL);
        addView(title, new LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, N.dp(context, 28)));

        FrameLayout stage = new FrameLayout(context);
        stage.setBackground(N.round(N.DGRAY, 12, context));

        TextView placeholder = new TextView(context);
        placeholder.setText("エミュレータエリア");
        placeholder.setTextColor(N.WHITE);
        placeholder.setTextSize(14);
        placeholder.setGravity(Gravity.CENTER);
        stage.addView(placeholder, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT));

        LayoutParams stageLp = new LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, N.dp(context, 190));
        stageLp.topMargin = N.dp(context, 8);
        addView(stage, stageLp);
    }
}
