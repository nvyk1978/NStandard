package com.cmyk.nstandard;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.GridLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

/**
 * Standalone cell-emulator sandbox for N Standard.
 * It deliberately has no dependency on the thumbnail/image area above it.
 */
public final class NEmulatorArea extends LinearLayout {
    private final Context context;
    private final GridLayout grid;
    private final List<CellView> cells = new ArrayList<>();
    private CellView selectedCell;

    public NEmulatorArea(Context context) {
        super(context);
        this.context = context;
        setOrientation(VERTICAL);
        setPadding(N.dp(context, 14), N.dp(context, 14), N.dp(context, 14), N.dp(context, 14));
        setBackground(N.round(N.GRAY, 18, context));

        TextView title = text("エミュレータ", 14);
        title.setGravity(Gravity.START | Gravity.CENTER_VERTICAL);
        addView(title, new LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, N.dp(context, 28)));

        LinearLayout controls = new LinearLayout(context);
        controls.setOrientation(HORIZONTAL);
        controls.setGravity(Gravity.CENTER_VERTICAL);

        TextView addCell = button("セル追加");
        addCell.setOnClickListener(v -> addEmptyCell());
        controls.addView(addCell, new LinearLayout.LayoutParams(0, N.dp(context, 48), 1f));

        TextView confirmCell = button("セル確定");
        confirmCell.setOnClickListener(v -> confirmSelectedCell());
        LinearLayout.LayoutParams confirmLp = new LinearLayout.LayoutParams(0, N.dp(context, 48), 1f);
        confirmLp.leftMargin = N.dp(context, 10);
        controls.addView(confirmCell, confirmLp);

        LayoutParams controlsLp = new LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, N.dp(context, 48));
        controlsLp.topMargin = N.dp(context, 10);
        addView(controls, controlsLp);

        grid = new GridLayout(context);
        grid.setColumnCount(4);
        grid.setAlignmentMode(GridLayout.ALIGN_BOUNDS);
        grid.setUseDefaultMargins(false);
        grid.setPadding(N.dp(context, 10), N.dp(context, 10), N.dp(context, 10), N.dp(context, 10));
        grid.setBackground(N.round(N.DGRAY, 12, context));
        grid.setMinimumHeight(N.dp(context, 190));

        LayoutParams gridLp = new LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        gridLp.topMargin = N.dp(context, 12);
        addView(grid, gridLp);
    }

    private void addEmptyCell() {
        int screenWidth = getResources().getDisplayMetrics().widthPixels;
        int gap = N.dp(context, 8);
        int outer = N.dp(context, 50 + 28 + 20);
        int size = Math.max(N.dp(context, 56), (screenWidth - outer - gap * 3) / 4);

        CellView cell = new CellView(context);
        cell.setOnClickListener(v -> selectCell(cell));
        cells.add(cell);
        selectCell(cell);

        GridLayout.LayoutParams lp = new GridLayout.LayoutParams();
        lp.width = size;
        lp.height = size;
        int col = (cells.size() - 1) % 4;
        lp.setMargins(col == 0 ? 0 : gap / 2, 0, col == 3 ? 0 : gap / 2, gap);
        grid.addView(cell, lp);

        DiagLog.write(context, "EMULATOR_CELL_ADD count=" + cells.size());
    }

    private void selectCell(CellView cell) {
        if (selectedCell == cell) return;
        if (selectedCell != null) selectedCell.setCurrent(false);
        selectedCell = cell;
        selectedCell.setCurrent(true);
        DiagLog.write(context, "EMULATOR_CELL_SELECT index=" + cells.indexOf(cell));
    }

    private void confirmSelectedCell() {
        if (selectedCell == null) {
            Toast.makeText(context, "セルを選択してください", Toast.LENGTH_SHORT).show();
            return;
        }
        selectedCell.setConfirmed(true);
        DiagLog.write(context, "EMULATOR_CELL_CONFIRM index=" + cells.indexOf(selectedCell));
    }

    private TextView button(String label) {
        TextView t = text(label, 15);
        t.setGravity(Gravity.CENTER);
        t.setBackground(N.round(N.LBLUE, 24, context));
        t.setClickable(true);
        t.setFocusable(true);
        return t;
    }

    private TextView text(String value, float sp) {
        TextView t = new TextView(context);
        t.setText(value);
        t.setTextColor(N.TEXT);
        t.setTextSize(sp);
        return t;
    }

    private static final class CellView extends FrameLayout {
        private final ConfirmCheckView check;
        private boolean current;

        CellView(Context context) {
            super(context);
            updateBackground();

            check = new ConfirmCheckView(context);
            check.setVisibility(GONE);
            LayoutParams checkLp = new LayoutParams(
                    N.dp(context, 30), N.dp(context, 30), Gravity.TOP | Gravity.END);
            checkLp.setMargins(0, N.dp(context, 5), N.dp(context, 5), 0);
            addView(check, checkLp);
        }

        void setCurrent(boolean current) {
            this.current = current;
            updateBackground();
        }

        void setConfirmed(boolean confirmed) {
            check.setVisibility(confirmed ? VISIBLE : GONE);
        }

        private void updateBackground() {
            GradientDrawable g = new GradientDrawable();
            g.setColor(N.GRAY);
            g.setCornerRadius(N.dp(getContext(), 10));
            if (current) {
                g.setStroke(N.dp(getContext(), 2), N.LBLUE);
            }
            setBackground(g);
        }
    }

    private static final class ConfirmCheckView extends View {
        private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);

        ConfirmCheckView(Context context) {
            super(context);
            paint.setStrokeCap(Paint.Cap.SQUARE);
            paint.setStrokeJoin(Paint.Join.MITER);
        }

        @Override
        protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            float w = getWidth();
            float h = getHeight();
            float cx = w / 2f;
            float cy = h / 2f;
            float radius = Math.min(w, h) * 0.48f;

            paint.setStyle(Paint.Style.FILL);
            paint.setColor(N.GREEN);
            canvas.drawCircle(cx, cy, radius, paint);

            paint.setStyle(Paint.Style.STROKE);
            paint.setStrokeWidth(Math.max(3f, Math.min(w, h) * 0.10f));
            paint.setColor(N.TEXT);
            android.graphics.Path path = new android.graphics.Path();
            path.moveTo(w * 0.25f, h * 0.52f);
            path.lineTo(w * 0.43f, h * 0.69f);
            path.lineTo(w * 0.76f, h * 0.34f);
            canvas.drawPath(path, paint);
        }
    }
}
