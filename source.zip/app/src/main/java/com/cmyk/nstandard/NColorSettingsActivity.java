package com.cmyk.nstandard;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.SharedPreferences;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.ComposeShader;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.RectF;
import android.graphics.Shader;
import android.os.Bundle;
import android.text.Editable;
import android.text.InputFilter;
import android.text.InputType;
import android.text.TextWatcher;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class NColorSettingsActivity extends Activity {
    private static final String PREFS = "nstandard_color_settings";
    private static final String KEY_LISTS = "lists";

    private final List<ColorListModel> lists = new ArrayList<>();
    private LinearLayout listContainer;

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        loadState();
        setContentView(buildUi());
        renderLists();
    }

    private View buildUi() {
        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(N.BG);

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        FrameLayout.LayoutParams scrollLp = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
        root.addView(scroll, scrollLp);

        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(N.dp(this, 25), N.dp(this, 28), N.dp(this, 25), N.dp(this, 110));
        scroll.addView(content, new ScrollView.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        TextView title = new TextView(this);
        title.setText("カラー設定");
        title.setTextColor(N.WHITE);
        title.setTextSize(TypedValue.COMPLEX_UNIT_SP, 25);
        title.setTypeface(title.getTypeface(), android.graphics.Typeface.BOLD);
        LinearLayout.LayoutParams titleLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, N.dp(this, 52));
        titleLp.topMargin = N.dp(this, 50);
        content.addView(title, titleLp);

        View spacer = new View(this);
        content.addView(spacer, new LinearLayout.LayoutParams(1, N.dp(this, 18)));

        listContainer = new LinearLayout(this);
        listContainer.setOrientation(LinearLayout.VERTICAL);
        content.addView(listContainer, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        TextView addListFab = new TextView(this);
        addListFab.setText("＋");
        addListFab.setTextColor(N.TEXT);
        addListFab.setTextSize(TypedValue.COMPLEX_UNIT_SP, 28);
        addListFab.setGravity(Gravity.CENTER);
        addListFab.setBackground(N.round(N.LBLUE, 30, this));
        addListFab.setOnClickListener(v -> addList());
        FrameLayout.LayoutParams fabLp = new FrameLayout.LayoutParams(N.dp(this, 60), N.dp(this, 60));
        fabLp.gravity = Gravity.END | Gravity.BOTTOM;
        fabLp.rightMargin = N.dp(this, 24);
        fabLp.bottomMargin = N.dp(this, 24);
        root.addView(addListFab, fabLp);

        return root;
    }

    private void renderLists() {
        listContainer.removeAllViews();
        for (int i = 0; i < lists.size(); i++) {
            ColorListModel model = lists.get(i);
            listContainer.addView(createListCard(model, i));
        }
    }

    private View createListCard(ColorListModel model, int index) {
        LinearLayout wrap = new LinearLayout(this);
        wrap.setOrientation(LinearLayout.VERTICAL);

        TextView name = new TextView(this);
        name.setText(model.name);
        name.setTextColor(N.TEXT);
        name.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16);
        name.setTypeface(name.getTypeface(), android.graphics.Typeface.BOLD);
        name.setOnClickListener(v -> showListNameEditor(index));
        name.setPadding(N.dp(this, 4), 0, N.dp(this, 4), N.dp(this, 8));
        wrap.addView(name, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        FlowLayout paletteWrap = new FlowLayout(this);
        paletteWrap.setPadding(N.dp(this, 12), N.dp(this, 12), N.dp(this, 12), N.dp(this, 12));
        paletteWrap.setLineSpacing(N.dp(this, 10));
        paletteWrap.setItemSpacing(N.dp(this, 10));
        paletteWrap.setBackground(N.round(model.backgroundColor, 22, this));

        paletteWrap.addView(createColorCircle(model.backgroundColor, true, v -> showColorEditor(index, -1)));
        for (int i = 0; i < model.colors.size(); i++) {
            int colorIndex = i;
            paletteWrap.addView(createColorCircle(model.colors.get(i), false, v -> showColorEditor(index, colorIndex)));
        }
        paletteWrap.addView(createPlusCircle(v -> addPaletteColor(index)));

        LinearLayout.LayoutParams cardLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        if (index > 0) cardLp.topMargin = N.dp(this, 18);
        wrap.addView(paletteWrap, cardLp);
        return wrap;
    }

    private View createColorCircle(int color, boolean backgroundColor, View.OnClickListener listener) {
        FrameLayout frame = new FrameLayout(this);
        int size = N.dp(this, 38);
        View colorView = new View(this);
        android.graphics.drawable.GradientDrawable d = new android.graphics.drawable.GradientDrawable();
        d.setShape(android.graphics.drawable.GradientDrawable.OVAL);
        d.setColor(color);
        d.setStroke(N.dp(this, 1.5f), Color.argb(120, 255, 255, 255));
        colorView.setBackground(d);
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(size, size);
        lp.gravity = Gravity.CENTER;
        frame.addView(colorView, lp);
        if (backgroundColor) {
            TextView b = new TextView(this);
            b.setText("BG");
            b.setTextColor(Color.WHITE);
            b.setTextSize(TypedValue.COMPLEX_UNIT_SP, 8);
            b.setGravity(Gravity.CENTER);
            frame.addView(b, lp);
        }
        frame.setOnClickListener(listener);
        return frame;
    }

    private View createPlusCircle(View.OnClickListener listener) {
        FrameLayout frame = new FrameLayout(this);
        int size = N.dp(this, 38);
        View circle = new View(this);
        android.graphics.drawable.GradientDrawable d = new android.graphics.drawable.GradientDrawable();
        d.setShape(android.graphics.drawable.GradientDrawable.OVAL);
        d.setColor(Color.WHITE);
        d.setStroke(N.dp(this, 1.5f), Color.argb(80, 0, 0, 0));
        circle.setBackground(d);
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(size, size);
        lp.gravity = Gravity.CENTER;
        frame.addView(circle, lp);
        TextView plus = new TextView(this);
        plus.setText("＋");
        plus.setTextColor(N.DGRAY);
        plus.setTextSize(TypedValue.COMPLEX_UNIT_SP, 22);
        plus.setGravity(Gravity.CENTER);
        frame.addView(plus, lp);
        frame.setOnClickListener(listener);
        return frame;
    }

    private void showListNameEditor(int listIndex) {
        ColorListModel model = lists.get(listIndex);
        EditText input = new EditText(this);
        input.setText(model.name);
        input.setSingleLine(true);
        input.setSelectAllOnFocus(true);
        input.setTextColor(N.TEXT);
        input.setBackground(N.round(N.GRAY, 10, this));
        input.setPadding(N.dp(this, 12), N.dp(this, 10), N.dp(this, 12), N.dp(this, 10));

        LinearLayout box = new LinearLayout(this);
        box.setPadding(N.dp(this, 18), N.dp(this, 12), N.dp(this, 18), 0);
        box.addView(input, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("リスト名編集")
                .setView(box)
                .setNegativeButton("キャンセル", null)
                .setPositiveButton("保存", (d, which) -> {
                    String value = input.getText().toString().trim();
                    if (!value.isEmpty()) {
                        model.name = value;
                        saveState();
                        renderLists();
                    }
                }).create();
        dialog.show();
    }

    private void addPaletteColor(int listIndex) {
        ColorListModel model = lists.get(listIndex);
        model.colors.add(N.WHITE);
        saveState();
        renderLists();
        showColorEditor(listIndex, model.colors.size() - 1);
    }

    private void addList() {
        ColorListModel model = new ColorListModel();
        model.name = "リスト" + (lists.size() + 1);
        model.backgroundColor = N.BG;
        model.colors.add(N.WHITE);
        lists.add(model);
        saveState();
        renderLists();
        Toast.makeText(this, model.name + " を追加", Toast.LENGTH_SHORT).show();
    }

    private void showColorEditor(int listIndex, int colorIndex) {
        ColorListModel model = lists.get(listIndex);
        final int startColor = colorIndex < 0 ? model.backgroundColor : model.colors.get(colorIndex);

        Dialog dialog = new Dialog(this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(N.dp(this, 18), N.dp(this, 18), N.dp(this, 18), N.dp(this, 18));
        root.setBackground(N.round(N.GRAY, 18, this));

        TextView title = new TextView(this);
        title.setText(colorIndex < 0 ? "背景色" : "パレット色");
        title.setTextColor(N.TEXT);
        title.setTextSize(TypedValue.COMPLEX_UNIT_SP, 18);
        title.setTypeface(title.getTypeface(), android.graphics.Typeface.BOLD);
        root.addView(title);

        View gap = new View(this);
        root.addView(gap, new LinearLayout.LayoutParams(1, N.dp(this, 12)));

        View preview = new View(this);
        preview.setBackgroundColor(startColor);
        root.addView(preview, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, N.dp(this, 42)));

        View gap2 = new View(this);
        root.addView(gap2, new LinearLayout.LayoutParams(1, N.dp(this, 12)));

        SVPickerView svPicker = new SVPickerView(this);
        root.addView(svPicker, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, N.dp(this, 180)));

        TextView hueLabel = makeSmallLabel("Hue");
        LinearLayout.LayoutParams hueLblLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        hueLblLp.topMargin = N.dp(this, 12);
        root.addView(hueLabel, hueLblLp);

        SeekBar hueBar = new SeekBar(this);
        hueBar.setMax(360);
        hueBar.setProgressTintList(android.content.res.ColorStateList.valueOf(N.LBLUE));
        hueBar.setThumbTintList(android.content.res.ColorStateList.valueOf(N.WHITE));
        root.addView(hueBar, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        RGBControl rControl = new RGBControl(this, "R");
        RGBControl gControl = new RGBControl(this, "G");
        RGBControl bControl = new RGBControl(this, "B");
        root.addView(rControl.container);
        root.addView(gControl.container);
        root.addView(bControl.container);

        LinearLayout hexRow = new LinearLayout(this);
        hexRow.setOrientation(LinearLayout.HORIZONTAL);
        hexRow.setGravity(Gravity.CENTER_VERTICAL);
        TextView hash = new TextView(this);
        hash.setText("#");
        hash.setTextColor(N.TEXT);
        hash.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16);
        hexRow.addView(hash);
        EditText hexInput = new EditText(this);
        hexInput.setTextColor(N.TEXT);
        hexInput.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16);
        hexInput.setSingleLine(true);
        hexInput.setFilters(new InputFilter[]{new InputFilter.LengthFilter(6)});
        hexInput.setInputType(InputType.TYPE_CLASS_TEXT);
        hexInput.setBackground(N.round(N.DGRAY, 10, this));
        hexInput.setPadding(N.dp(this, 12), N.dp(this, 8), N.dp(this, 12), N.dp(this, 8));
        LinearLayout.LayoutParams hexLp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        hexLp.leftMargin = N.dp(this, 8);
        hexRow.addView(hexInput, hexLp);
        LinearLayout.LayoutParams hexRowLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        hexRowLp.topMargin = N.dp(this, 12);
        root.addView(hexRow, hexRowLp);

        LinearLayout btnRow = new LinearLayout(this);
        btnRow.setOrientation(LinearLayout.HORIZONTAL);
        btnRow.setGravity(Gravity.END | Gravity.CENTER_VERTICAL);
        LinearLayout.LayoutParams btnRowLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        btnRowLp.topMargin = N.dp(this, 16);
        root.addView(btnRow, btnRowLp);

        TextView cancel = dialogButton("キャンセル", N.GRAY);
        cancel.setOnClickListener(v -> dialog.dismiss());
        btnRow.addView(cancel, new LinearLayout.LayoutParams(N.dp(this, 108), N.dp(this, 40)));

        TextView save = dialogButton("保存", N.LBLUE);
        LinearLayout.LayoutParams saveLp = new LinearLayout.LayoutParams(N.dp(this, 108), N.dp(this, 40));
        saveLp.leftMargin = N.dp(this, 10);
        btnRow.addView(save, saveLp);

        dialog.setContentView(root);
        if (dialog.getWindow() != null) {
            dialog.getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            dialog.getWindow().setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(Color.TRANSPARENT));
        }

        final boolean[] syncing = {false};
        final int[] currentColor = {startColor};

        Runnable pushToUi = () -> {
            syncing[0] = true;
            preview.setBackgroundColor(currentColor[0]);
            float[] hsv = new float[3];
            Color.colorToHSV(currentColor[0], hsv);
            hueBar.setProgress(Math.round(hsv[0]));
            svPicker.setColor(currentColor[0]);
            rControl.setValue(Color.red(currentColor[0]));
            gControl.setValue(Color.green(currentColor[0]));
            bControl.setValue(Color.blue(currentColor[0]));
            hexInput.setText(toHex(currentColor[0]));
            syncing[0] = false;
        };

        svPicker.setOnColorChangedListener(color -> {
            if (syncing[0]) return;
            currentColor[0] = color;
            pushToUi.run();
        });

        hueBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onStartTrackingTouch(SeekBar seekBar) { }
            @Override public void onStopTrackingTouch(SeekBar seekBar) { }
            @Override public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                if (!fromUser || syncing[0]) return;
                svPicker.setHue(progress);
                currentColor[0] = svPicker.getColor();
                pushToUi.run();
            }
        });

        rControl.setListener(value -> {
            if (syncing[0]) return;
            currentColor[0] = Color.rgb(value, gControl.getValue(), bControl.getValue());
            pushToUi.run();
        });
        gControl.setListener(value -> {
            if (syncing[0]) return;
            currentColor[0] = Color.rgb(rControl.getValue(), value, bControl.getValue());
            pushToUi.run();
        });
        bControl.setListener(value -> {
            if (syncing[0]) return;
            currentColor[0] = Color.rgb(rControl.getValue(), gControl.getValue(), value);
            pushToUi.run();
        });

        hexInput.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) { }
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) { }
            @Override public void afterTextChanged(Editable s) {
                if (syncing[0]) return;
                String text = s.toString().trim().replace("#", "").toUpperCase(Locale.US);
                if (text.length() == 6) {
                    try {
                        int color = Color.parseColor("#" + text);
                        currentColor[0] = color;
                        pushToUi.run();
                    } catch (Exception ignored) { }
                }
            }
        });

        save.setOnClickListener(v -> {
            if (colorIndex < 0) {
                model.backgroundColor = currentColor[0];
            } else {
                model.colors.set(colorIndex, currentColor[0]);
            }
            saveState();
            renderLists();
            dialog.dismiss();
        });

        pushToUi.run();
        dialog.show();
    }

    private TextView makeSmallLabel(String text) {
        TextView v = new TextView(this);
        v.setText(text);
        v.setTextColor(N.WHITE);
        v.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        return v;
    }

    private TextView dialogButton(String text, int color) {
        TextView v = new TextView(this);
        v.setText(text);
        v.setTextColor(N.TEXT);
        v.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15);
        v.setGravity(Gravity.CENTER);
        v.setBackground(N.round(color, 20, this));
        return v;
    }

    private void loadState() {
        lists.clear();
        SharedPreferences prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        String json = prefs.getString(KEY_LISTS, null);
        if (json == null || json.trim().isEmpty()) {
            createDefaultLists();
            return;
        }
        try {
            JSONArray arr = new JSONArray(json);
            for (int i = 0; i < arr.length(); i++) {
                JSONObject o = arr.getJSONObject(i);
                ColorListModel m = new ColorListModel();
                m.name = o.optString("name", "リスト" + (i + 1));
                m.backgroundColor = o.optInt("bg", N.BG);
                JSONArray colors = o.optJSONArray("colors");
                if (colors != null) {
                    for (int j = 0; j < colors.length(); j++) m.colors.add(colors.getInt(j));
                }
                lists.add(m);
            }
            if (lists.isEmpty()) createDefaultLists();
        } catch (Exception e) {
            createDefaultLists();
        }
    }

    private void saveState() {
        try {
            JSONArray arr = new JSONArray();
            for (ColorListModel m : lists) {
                JSONObject o = new JSONObject();
                o.put("name", m.name);
                o.put("bg", m.backgroundColor);
                JSONArray colorArr = new JSONArray();
                for (Integer c : m.colors) colorArr.put(c);
                o.put("colors", colorArr);
                arr.put(o);
            }
            getSharedPreferences(PREFS, MODE_PRIVATE).edit().putString(KEY_LISTS, arr.toString()).apply();
        } catch (Exception ignored) { }
    }

    private void createDefaultLists() {
        ColorListModel m = new ColorListModel();
        m.name = "リスト1";
        m.backgroundColor = N.BG;
        m.colors.add(Color.parseColor("#252020"));
        m.colors.add(Color.parseColor("#454040"));
        m.colors.add(Color.parseColor("#656060"));
        m.colors.add(Color.parseColor("#223355"));
        m.colors.add(Color.parseColor("#445577"));
        m.colors.add(Color.parseColor("#441100"));
        m.colors.add(Color.parseColor("#662211"));
        m.colors.add(Color.parseColor("#775500"));
        m.colors.add(Color.parseColor("#553300"));
        m.colors.add(Color.parseColor("#A9A999"));
        m.colors.add(Color.parseColor("#227733"));
        m.colors.add(Color.parseColor("#00FF40"));
        m.colors.add(Color.parseColor("#FFFFFF"));
        lists.add(m);
    }

    private String toHex(int color) {
        return String.format(Locale.US, "%02X%02X%02X", Color.red(color), Color.green(color), Color.blue(color));
    }

    private static final class ColorListModel {
        String name;
        int backgroundColor;
        final List<Integer> colors = new ArrayList<>();
    }

    private static final class RGBControl {
        final LinearLayout container;
        final SeekBar seekBar;
        final TextView valueView;
        ValueListener listener;

        RGBControl(Activity activity, String label) {
            container = new LinearLayout(activity);
            container.setOrientation(LinearLayout.HORIZONTAL);
            container.setGravity(Gravity.CENTER_VERTICAL);
            LinearLayout.LayoutParams cLp = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            cLp.topMargin = N.dp(activity, 8);
            container.setLayoutParams(cLp);

            TextView tv = new TextView(activity);
            tv.setText(label);
            tv.setTextColor(N.TEXT);
            tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
            container.addView(tv, new LinearLayout.LayoutParams(N.dp(activity, 20), ViewGroup.LayoutParams.WRAP_CONTENT));

            seekBar = new SeekBar(activity);
            seekBar.setMax(255);
            seekBar.setProgressTintList(android.content.res.ColorStateList.valueOf(N.LBLUE));
            seekBar.setThumbTintList(android.content.res.ColorStateList.valueOf(N.WHITE));
            LinearLayout.LayoutParams sLp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
            sLp.leftMargin = N.dp(activity, 8);
            container.addView(seekBar, sLp);

            valueView = new TextView(activity);
            valueView.setTextColor(N.TEXT);
            valueView.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
            valueView.setGravity(Gravity.END | Gravity.CENTER_VERTICAL);
            LinearLayout.LayoutParams vLp = new LinearLayout.LayoutParams(N.dp(activity, 34), ViewGroup.LayoutParams.WRAP_CONTENT);
            vLp.leftMargin = N.dp(activity, 8);
            container.addView(valueView, vLp);

            seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
                @Override public void onStartTrackingTouch(SeekBar seekBar) { }
                @Override public void onStopTrackingTouch(SeekBar seekBar) { }
                @Override public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                    valueView.setText(String.valueOf(progress));
                    if (fromUser && listener != null) listener.onValue(progress);
                }
            });
        }

        void setValue(int value) {
            seekBar.setProgress(value);
            valueView.setText(String.valueOf(value));
        }

        int getValue() {
            return seekBar.getProgress();
        }

        void setListener(ValueListener l) {
            listener = l;
        }

        interface ValueListener { void onValue(int value); }
    }

    private static final class FlowLayout extends ViewGroup {
        private int lineSpacing;
        private int itemSpacing;

        FlowLayout(Activity c) { super(c); }

        void setLineSpacing(int px) { lineSpacing = px; }
        void setItemSpacing(int px) { itemSpacing = px; }

        @Override
        protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
            int width = MeasureSpec.getSize(widthMeasureSpec);
            int maxWidth = width - getPaddingLeft() - getPaddingRight();
            int x = 0, y = 0, lineHeight = 0;
            for (int i = 0; i < getChildCount(); i++) {
                View child = getChildAt(i);
                measureChild(child, widthMeasureSpec, heightMeasureSpec);
                int cw = child.getMeasuredWidth();
                int ch = child.getMeasuredHeight();
                if (x > 0 && x + cw > maxWidth) {
                    x = 0;
                    y += lineHeight + lineSpacing;
                    lineHeight = 0;
                }
                if (x > 0) x += itemSpacing;
                x += cw;
                lineHeight = Math.max(lineHeight, ch);
            }
            y += lineHeight;
            y += getPaddingTop() + getPaddingBottom();
            setMeasuredDimension(width, resolveSize(y, heightMeasureSpec));
        }

        @Override
        protected void onLayout(boolean changed, int l, int t, int r, int b) {
            int width = r - l;
            int maxWidth = width - getPaddingLeft() - getPaddingRight();
            int x = getPaddingLeft();
            int y = getPaddingTop();
            int lineHeight = 0;
            for (int i = 0; i < getChildCount(); i++) {
                View child = getChildAt(i);
                int cw = child.getMeasuredWidth();
                int ch = child.getMeasuredHeight();
                int childX = x;
                if (x > getPaddingLeft() && (x - getPaddingLeft()) + itemSpacing + cw > maxWidth) {
                    x = getPaddingLeft();
                    y += lineHeight + lineSpacing;
                    lineHeight = 0;
                    childX = x;
                } else if (x > getPaddingLeft()) {
                    childX = x + itemSpacing;
                    x += itemSpacing;
                }
                child.layout(childX, y, childX + cw, y + ch);
                x = childX + cw;
                lineHeight = Math.max(lineHeight, ch);
            }
        }
    }

    private static final class SVPickerView extends View {
        private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint indicatorPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final RectF rect = new RectF();
        private float hue = 0f;
        private float sat = 0f;
        private float val = 1f;
        private OnColorChangedListener listener;

        SVPickerView(Activity c) {
            super(c);
            indicatorPaint.setStyle(Paint.Style.STROKE);
            indicatorPaint.setStrokeWidth(N.dp(c, 2));
            indicatorPaint.setColor(Color.WHITE);
        }

        void setOnColorChangedListener(OnColorChangedListener l) { listener = l; }

        void setColor(int color) {
            float[] hsv = new float[3];
            Color.colorToHSV(color, hsv);
            hue = hsv[0];
            sat = hsv[1];
            val = hsv[2];
            invalidate();
        }

        void setHue(float value) {
            hue = value;
            invalidate();
        }

        int getColor() {
            return Color.HSVToColor(new float[]{hue, sat, val});
        }

        @Override
        protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            rect.set(0, 0, getWidth(), getHeight());
            int hueColor = Color.HSVToColor(new float[]{hue, 1f, 1f});
            Shader satShader = new LinearGradient(0, 0, getWidth(), 0,
                    Color.WHITE, hueColor, Shader.TileMode.CLAMP);
            Shader valShader = new LinearGradient(0, 0, 0, getHeight(),
                    Color.TRANSPARENT, Color.BLACK, Shader.TileMode.CLAMP);
            paint.setShader(new ComposeShader(satShader, valShader, PorterDuff.Mode.MULTIPLY));
            canvas.drawRoundRect(rect, 12f, 12f, paint);

            float cx = sat * getWidth();
            float cy = (1f - val) * getHeight();
            canvas.drawCircle(cx, cy, 12f, indicatorPaint);
            indicatorPaint.setStyle(Paint.Style.FILL);
            indicatorPaint.setColor(getColor());
            canvas.drawCircle(cx, cy, 8f, indicatorPaint);
            indicatorPaint.setStyle(Paint.Style.STROKE);
            indicatorPaint.setColor(Color.WHITE);
        }

        @Override
        public boolean onTouchEvent(MotionEvent event) {
            switch (event.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                case MotionEvent.ACTION_MOVE:
                    sat = clamp(event.getX() / Math.max(1f, getWidth()));
                    val = 1f - clamp(event.getY() / Math.max(1f, getHeight()));
                    invalidate();
                    if (listener != null) listener.onColorChanged(getColor());
                    return true;
            }
            return super.onTouchEvent(event);
        }

        private float clamp(float v) {
            return Math.max(0f, Math.min(1f, v));
        }

        interface OnColorChangedListener { void onColorChanged(int color); }
    }
}
