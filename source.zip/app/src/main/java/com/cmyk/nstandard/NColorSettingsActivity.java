package com.cmyk.nstandard;

import android.app.Activity;
import android.app.Dialog;
import android.content.SharedPreferences;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.ComposeShader;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.RectF;
import android.graphics.Shader;
import android.os.Bundle;
import android.text.Editable;
import android.text.InputFilter;
import android.text.InputType;
import android.text.TextWatcher;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.Space;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class NColorSettingsActivity extends Activity {
    private static final String PREFS = "nstandard_color_settings";
    private static final String KEY_LISTS = "lists";

    private final List<ColorListModel> lists = new ArrayList<>();
    private LinearLayout listContainer;

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        loadState();
        setContentView(buildUi());
        renderLists();
    }

    private View buildUi() {
        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(N.BG);

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        FrameLayout.LayoutParams scrollLp = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
        root.addView(scroll, scrollLp);

        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(N.dp(this, 25), N.dp(this, N.PAGE_TITLE_TOP_DP), N.dp(this, 25), N.dp(this, 110));
        scroll.addView(content, new ScrollView.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        TextView title = new TextView(this);
        title.setText("カラー設定");
        title.setTextColor(N.WHITE);
        title.setTextSize(TypedValue.COMPLEX_UNIT_SP, 25);
        title.setTypeface(title.getTypeface(), android.graphics.Typeface.BOLD);
        LinearLayout.LayoutParams titleLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, N.dp(this, 52));
        content.addView(title, titleLp);

        View spacer = new View(this);
        content.addView(spacer, new LinearLayout.LayoutParams(1, N.dp(this, 18)));

        listContainer = new LinearLayout(this);
        listContainer.setOrientation(LinearLayout.VERTICAL);
        content.addView(listContainer, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        FrameLayout addListFab = createVectorPlusFab(N.LBLUE, Color.WHITE, N.dp(this, 60), N.dp(this, 28));
        addListFab.setOnClickListener(v -> addList());
        FrameLayout.LayoutParams fabLp = new FrameLayout.LayoutParams(N.dp(this, 60), N.dp(this, 60));
        fabLp.gravity = Gravity.END | Gravity.BOTTOM;
        fabLp.rightMargin = N.dp(this, 24);
        fabLp.bottomMargin = N.dp(this, 24);
        root.addView(addListFab, fabLp);

        return root;
    }

    private void renderLists() {
        listContainer.removeAllViews();
        for (int i = 0; i < lists.size(); i++) {
            ColorListModel model = lists.get(i);
            View card = createListCard(model, i);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            if (i > 0) lp.topMargin = N.dp(this, 14);
            listContainer.addView(card, lp);
        }
    }

    private View createListCard(ColorListModel model, int index) {
        LinearLayout wrap = new LinearLayout(this);
        wrap.setOrientation(LinearLayout.VERTICAL);

        TextView name = new TextView(this);
        name.setText(model.name);
        name.setTextColor(N.TEXT);
        name.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16);
        name.setTypeface(name.getTypeface(), android.graphics.Typeface.BOLD);
        name.setOnClickListener(v -> showListNameEditor(index));
        // Keep the list name visually attached to its card.
        name.setPadding(N.dp(this, 4), 0, N.dp(this, 4), N.dp(this, 2));
        wrap.addView(name, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        FlowLayout paletteWrap = new FlowLayout(this);
        // The FlowLayout computes one fixed grid from the available width so the
        // edge gaps and item gaps are visually even. Short rows keep the exact
        // same positions and remain left aligned.
        paletteWrap.setPadding(0, 0, 0, 0);
        paletteWrap.setLineSpacing(N.dp(this, 6));
        paletteWrap.setItemSpacing(N.dp(this, 6));
        paletteWrap.setBackground(N.round(model.backgroundColor, 22, this));
        paletteWrap.setOnLongClickListener(v -> {
            showListOverflowMenu(index);
            return true;
        });

        // Names stay inside the color editor. The list surface shows circles only.
        View bgItem = createPaletteItem(
                model.backgroundColor,
                true,
                v -> showColorEditor(index, -1));
        bindListLongPress(bgItem, index);
        paletteWrap.addView(bgItem);

        ensurePaletteNames(model, index == 0);
        for (int i = 0; i < model.colors.size(); i++) {
            int colorIndex = i;
            View paletteItem = createPaletteItem(
                    model.colors.get(i),
                    false,
                    v -> showColorEditor(index, colorIndex));
            bindListLongPress(paletteItem, index);
            paletteWrap.addView(paletteItem);
        }
        View plusItem = createPlusCircle(v -> addPaletteColor(index));
        bindListLongPress(plusItem, index);
        paletteWrap.addView(plusItem);

        LinearLayout.LayoutParams cardLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        wrap.addView(paletteWrap, cardLp);
        return wrap;
    }

    private View createPaletteItem(int color, boolean backgroundColor,
                                   View.OnClickListener colorListener) {
        FrameLayout circleFrame = new FrameLayout(this);
        int circleSize = N.dp(this, 38);
        circleFrame.setClickable(true);
        circleFrame.setFocusable(true);

        View colorView = new View(this);
        android.graphics.drawable.GradientDrawable d = new android.graphics.drawable.GradientDrawable();
        d.setShape(android.graphics.drawable.GradientDrawable.OVAL);
        d.setColor(color);
        d.setStroke(N.dp(this, 1.5f), Color.argb(120, 255, 255, 255));
        colorView.setBackground(d);
        // Decorative child must not consume taps; the whole circle frame owns the click.
        colorView.setClickable(false);
        colorView.setFocusable(false);
        FrameLayout.LayoutParams circleLp = new FrameLayout.LayoutParams(circleSize, circleSize, Gravity.CENTER);
        circleFrame.addView(colorView, circleLp);

        if (backgroundColor) {
            TextView b = new TextView(this);
            b.setText("BG");
            b.setTextColor(Color.WHITE);
            b.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11);
            b.setTypeface(b.getTypeface(), android.graphics.Typeface.BOLD);
            b.setGravity(Gravity.CENTER);
            b.setClickable(false);
            b.setFocusable(false);
            circleFrame.addView(b, circleLp);
        }
        circleFrame.setOnClickListener(colorListener);
        circleFrame.setLayoutParams(new ViewGroup.LayoutParams(circleSize, circleSize));
        return circleFrame;
    }

    private View createPlusCircle(View.OnClickListener listener) {
        FrameLayout frame = createVectorPlusFab(Color.WHITE, N.DGRAY, N.dp(this, 38), N.dp(this, 22));
        frame.setOnClickListener(listener);
        return frame;
    }

    private FrameLayout createVectorPlusFab(int circleColor, int iconColor, int sizePx, int iconSizePx) {
        FrameLayout frame = new FrameLayout(this);
        NPlusView plus = new NPlusView(this, circleColor, iconColor, 1f);
        if (circleColor == Color.WHITE) {
            plus.setCircleStroke(Color.argb(80, 0, 0, 0), 1.5f);
        }
        frame.addView(plus, new FrameLayout.LayoutParams(sizePx, sizePx, Gravity.CENTER));
        frame.setMinimumWidth(sizePx);
        frame.setMinimumHeight(sizePx);
        frame.setLayoutParams(new ViewGroup.LayoutParams(sizePx, sizePx));
        return frame;
    }

    private void bindListLongPress(View view, int listIndex) {
        view.setOnLongClickListener(v -> {
            showListOverflowMenu(listIndex);
            return true;
        });
    }

    private void showListOverflowMenu(int listIndex) {
        if (listIndex < 0 || listIndex >= lists.size()) return;
        NOverflowDialog.show(this, new String[]{
                "カラーコードをコピー",
                "リストを複製",
                "削除"
        }, which -> {
            if (listIndex < 0 || listIndex >= lists.size()) return;
            if (which == 0) {
                copyPaletteList(lists.get(listIndex));
            } else if (which == 1) {
                duplicateList(listIndex);
            } else if (which == 2) {
                confirmDeleteList(listIndex);
            }
        });
    }

    private void duplicateList(int listIndex) {
        if (listIndex < 0 || listIndex >= lists.size()) return;
        ColorListModel src = lists.get(listIndex);
        ensurePaletteNames(src, listIndex == 0);
        ColorListModel copy = new ColorListModel();
        copy.name = src.name + " コピー";
        copy.backgroundColor = src.backgroundColor;
        copy.colors.addAll(src.colors);
        copy.paletteNames.addAll(src.paletteNames);
        lists.add(Math.min(listIndex + 1, lists.size()), copy);
        saveState();
        renderLists();
        Toast.makeText(this, "リストを複製しました", Toast.LENGTH_SHORT).show();
    }

    private void confirmDeleteList(int listIndex) {
        if (listIndex < 0 || listIndex >= lists.size()) return;
        String name = lists.get(listIndex).name;
        NDialog.showChoices(this, "リストを削除",
                new String[]{"キャンセル", "削除"}, 1, which -> {
                    if (which != 1) return;
                    if (listIndex < 0 || listIndex >= lists.size()) return;
                    lists.remove(listIndex);
                    saveState();
                    renderLists();
                    Toast.makeText(this, name + " を削除しました", Toast.LENGTH_SHORT).show();
                });
    }

    private void showListNameEditor(int listIndex) {
        ColorListModel model = lists.get(listIndex);
        NDialog.showInput(this, "リスト名編集", "リスト名", model.name, false, "保存", text -> {
            String value = text == null ? "" : text.trim();
            if (value.isEmpty()) return;
            model.name = value;
            saveState();
            renderLists();
        });
    }

    private void showPaletteNameEditor(int listIndex, int colorIndex) {
        ColorListModel model = lists.get(listIndex);
        ensurePaletteNames(model, listIndex == 0);
        String initial = model.paletteNames.get(colorIndex);
        NDialog.showInput(this, "パレット名編集", "パレット名", initial, false, "保存", text -> {
            String value = text == null ? "" : text.trim();
            if (value.isEmpty()) return;
            model.paletteNames.set(colorIndex, value);
            saveState();
            renderLists();
        });
    }

    private void addPaletteColor(int listIndex) {
        ColorListModel model = lists.get(listIndex);
        model.colors.add(N.WHITE);
        model.paletteNames.add("");
        // New palettes are numbered from the right: rightmost = パレット1.
        renumberGenericPaletteNamesFromRight(model);
        saveState();
        renderLists();
        showColorEditor(listIndex, model.colors.size() - 1);
    }

    private void addList() {
        ColorListModel model = new ColorListModel();
        model.name = "リスト" + (lists.size() + 1);
        model.backgroundColor = N.BG;
        model.colors.add(N.WHITE);
        model.paletteNames.add("パレット1");
        lists.add(model);
        saveState();
        renderLists();
        Toast.makeText(this, model.name + " を追加", Toast.LENGTH_SHORT).show();
    }

    private void showColorEditor(int listIndex, int colorIndex) {
        ColorListModel model = lists.get(listIndex);
        final int startColor = colorIndex < 0 ? model.backgroundColor : model.colors.get(colorIndex);

        Dialog dialog = new Dialog(this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(N.dp(this, 18), N.dp(this, 18), N.dp(this, 18), N.dp(this, 18));
        root.setBackground(N.round(N.GRAY, 18, this));

        TextView title = new TextView(this);
        title.setText("カラー設定");
        title.setTextColor(N.TEXT);
        title.setTextSize(TypedValue.COMPLEX_UNIT_SP, 18);
        title.setTypeface(title.getTypeface(), android.graphics.Typeface.BOLD);
        root.addView(title);

        LinearLayout nameRow = new LinearLayout(this);
        nameRow.setOrientation(LinearLayout.HORIZONTAL);
        nameRow.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout.LayoutParams nameRowLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, N.dp(this, 40));
        nameRowLp.topMargin = N.dp(this, 8);
        root.addView(nameRow, nameRowLp);

        TextView nameLabel = new TextView(this);
        nameLabel.setText(colorIndex < 0 ? "カラー名" : "パレット名");
        nameLabel.setTextColor(N.WHITE);
        nameLabel.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
        nameRow.addView(nameLabel, new LinearLayout.LayoutParams(N.dp(this, 82), ViewGroup.LayoutParams.WRAP_CONTENT));

        TextView nameValue = new TextView(this);
        nameValue.setText(colorIndex < 0 ? "バックグラウンド" : model.paletteNames.get(colorIndex));
        nameValue.setTextColor(N.TEXT);
        nameValue.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15);
        nameValue.setGravity(Gravity.CENTER_VERTICAL);
        nameValue.setPadding(N.dp(this, 12), 0, N.dp(this, 12), 0);
        nameValue.setBackground(N.round(N.DGRAY, 10, this));
        nameRow.addView(nameValue, new LinearLayout.LayoutParams(0, N.dp(this, 36), 1f));
        if (colorIndex >= 0) {
            nameValue.setClickable(true);
            nameValue.setFocusable(true);
            nameValue.setOnClickListener(v -> {
                String initial = model.paletteNames.get(colorIndex);
                NDialog.showInput(this, "パレット名編集", "パレット名", initial, false, "保存", text -> {
                    String value = text == null ? "" : text.trim();
                    if (value.isEmpty()) return;
                    model.paletteNames.set(colorIndex, value);
                    nameValue.setText(value);
                    saveState();
                });
            });
        }

        View gap = new View(this);
        root.addView(gap, new LinearLayout.LayoutParams(1, N.dp(this, 8)));

        View preview = new View(this);
        preview.setBackgroundColor(startColor);
        root.addView(preview, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, N.dp(this, 42)));

        View gap2 = new View(this);
        root.addView(gap2, new LinearLayout.LayoutParams(1, N.dp(this, 12)));

        SVPickerView svPicker = new SVPickerView(this);
        root.addView(svPicker, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, N.dp(this, 180)));

        TextView hueLabel = makeSmallLabel("Hue");
        LinearLayout.LayoutParams hueLblLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        hueLblLp.topMargin = N.dp(this, 12);
        root.addView(hueLabel, hueLblLp);

        SeekBar hueBar = new SeekBar(this);
        hueBar.setMax(360);
        hueBar.setProgressTintList(android.content.res.ColorStateList.valueOf(N.LBLUE));
        hueBar.setThumbTintList(android.content.res.ColorStateList.valueOf(N.WHITE));
        root.addView(hueBar, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        RGBControl rControl = new RGBControl(this, "R");
        RGBControl gControl = new RGBControl(this, "G");
        RGBControl bControl = new RGBControl(this, "B");
        root.addView(rControl.container);
        root.addView(gControl.container);
        root.addView(bControl.container);

        LinearLayout hexRow = new LinearLayout(this);
        hexRow.setOrientation(LinearLayout.HORIZONTAL);
        hexRow.setGravity(Gravity.CENTER_VERTICAL);
        TextView hash = new TextView(this);
        hash.setText("#");
        hash.setTextColor(N.TEXT);
        hash.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16);
        hexRow.addView(hash);
        EditText hexInput = new EditText(this);
        hexInput.setTextColor(N.TEXT);
        hexInput.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16);
        hexInput.setSingleLine(true);
        hexInput.setFilters(new InputFilter[]{new InputFilter.LengthFilter(6)});
        hexInput.setInputType(InputType.TYPE_CLASS_TEXT);
        hexInput.setBackground(N.round(N.DGRAY, 10, this));
        hexInput.setPadding(N.dp(this, 12), N.dp(this, 8), N.dp(this, 12), N.dp(this, 8));
        LinearLayout.LayoutParams hexLp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        hexLp.leftMargin = N.dp(this, 8);
        hexRow.addView(hexInput, hexLp);
        LinearLayout.LayoutParams hexRowLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        hexRowLp.topMargin = N.dp(this, 12);
        root.addView(hexRow, hexRowLp);

        LinearLayout btnRow = new LinearLayout(this);
        btnRow.setOrientation(LinearLayout.HORIZONTAL);
        btnRow.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout.LayoutParams btnRowLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        btnRowLp.topMargin = N.dp(this, 16);
        root.addView(btnRow, btnRowLp);

        if (colorIndex >= 0) {
            TextView delete = dialogButton("削除", Color.parseColor("#662211"));
            delete.setOnClickListener(v -> {
                if (colorIndex >= 0 && colorIndex < model.colors.size()) {
                    model.colors.remove(colorIndex);
                    if (colorIndex < model.paletteNames.size()) model.paletteNames.remove(colorIndex);
                    renumberGenericPaletteNamesFromRight(model);
                    saveState();
                    renderLists();
                }
                dialog.dismiss();
            });
            btnRow.addView(delete, new LinearLayout.LayoutParams(N.dp(this, 86), N.dp(this, 40)));
        }

        Space pushRight = new Space(this);
        btnRow.addView(pushRight, new LinearLayout.LayoutParams(0, 1, 1f));

        TextView cancel = dialogButton("キャンセル", N.GRAY);
        cancel.setOnClickListener(v -> dialog.dismiss());
        btnRow.addView(cancel, new LinearLayout.LayoutParams(N.dp(this, 108), N.dp(this, 40)));

        TextView save = dialogButton("保存", N.LBLUE);
        LinearLayout.LayoutParams saveLp = new LinearLayout.LayoutParams(N.dp(this, 108), N.dp(this, 40));
        saveLp.leftMargin = N.dp(this, 10);
        btnRow.addView(save, saveLp);

        dialog.setContentView(root);
        if (dialog.getWindow() != null) {
            dialog.getWindow().setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(Color.TRANSPARENT));
        }

        final boolean[] syncing = {false};
        final int[] currentColor = {startColor};

        Runnable pushToUi = () -> {
            syncing[0] = true;
            preview.setBackgroundColor(currentColor[0]);
            float[] hsv = new float[3];
            Color.colorToHSV(currentColor[0], hsv);
            hueBar.setProgress(Math.round(hsv[0]));
            svPicker.setColor(currentColor[0]);
            rControl.setValue(Color.red(currentColor[0]));
            gControl.setValue(Color.green(currentColor[0]));
            bControl.setValue(Color.blue(currentColor[0]));
            hexInput.setText(toHex(currentColor[0]));
            syncing[0] = false;
        };

        svPicker.setOnColorChangedListener(color -> {
            if (syncing[0]) return;
            currentColor[0] = color;
            pushToUi.run();
        });

        hueBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onStartTrackingTouch(SeekBar seekBar) { }
            @Override public void onStopTrackingTouch(SeekBar seekBar) { }
            @Override public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                if (!fromUser || syncing[0]) return;
                svPicker.setHue(progress);
                currentColor[0] = svPicker.getColor();
                pushToUi.run();
            }
        });

        rControl.setListener(value -> {
            if (syncing[0]) return;
            currentColor[0] = Color.rgb(value, gControl.getValue(), bControl.getValue());
            pushToUi.run();
        });
        gControl.setListener(value -> {
            if (syncing[0]) return;
            currentColor[0] = Color.rgb(rControl.getValue(), value, bControl.getValue());
            pushToUi.run();
        });
        bControl.setListener(value -> {
            if (syncing[0]) return;
            currentColor[0] = Color.rgb(rControl.getValue(), gControl.getValue(), value);
            pushToUi.run();
        });

        hexInput.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) { }
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) { }
            @Override public void afterTextChanged(Editable s) {
                if (syncing[0]) return;
                String text = s.toString().trim().replace("#", "").toUpperCase(Locale.US);
                if (text.length() == 6) {
                    try {
                        int color = Color.parseColor("#" + text);
                        currentColor[0] = color;
                        pushToUi.run();
                    } catch (Exception ignored) { }
                }
            }
        });

        save.setOnClickListener(v -> {
            if (colorIndex < 0) {
                model.backgroundColor = currentColor[0];
            } else {
                model.colors.set(colorIndex, currentColor[0]);
            }
            saveState();
            renderLists();
            dialog.dismiss();
        });

        pushToUi.run();
        N.showDialogStable(this, dialog);
        if (dialog.getWindow() != null) {
            dialog.getWindow().setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(Color.TRANSPARENT));
        }
    }

    private TextView makeSmallLabel(String text) {
        TextView v = new TextView(this);
        v.setText(text);
        v.setTextColor(N.WHITE);
        v.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        return v;
    }

    private TextView dialogButton(String text, int color) {
        TextView v = new TextView(this);
        v.setText(text);
        v.setTextColor(N.TEXT);
        v.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15);
        v.setGravity(Gravity.CENTER);
        v.setBackground(N.round(color, 20, this));
        return v;
    }

    private void loadState() {
        lists.clear();
        SharedPreferences prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        String json = prefs.getString(KEY_LISTS, null);
        if (json == null || json.trim().isEmpty()) {
            createDefaultLists();
            return;
        }
        try {
            JSONArray arr = new JSONArray(json);
            for (int i = 0; i < arr.length(); i++) {
                JSONObject o = arr.getJSONObject(i);
                ColorListModel m = new ColorListModel();
                m.name = o.optString("name", "リスト" + (i + 1));
                m.backgroundColor = o.optInt("bg", N.BG);
                JSONArray colors = o.optJSONArray("colors");
                if (colors != null) {
                    for (int j = 0; j < colors.length(); j++) m.colors.add(colors.getInt(j));
                }
                JSONArray names = o.optJSONArray("paletteNames");
                if (names != null) {
                    for (int j = 0; j < names.length(); j++) m.paletteNames.add(names.optString(j, ""));
                }
                ensurePaletteNames(m, i == 0);
                lists.add(m);
            }
            if (lists.isEmpty()) createDefaultLists();
        } catch (Exception e) {
            createDefaultLists();
        }
    }

    private void saveState() {
        try {
            JSONArray arr = new JSONArray();
            for (ColorListModel m : lists) {
                JSONObject o = new JSONObject();
                o.put("name", m.name);
                o.put("bg", m.backgroundColor);
                JSONArray colorArr = new JSONArray();
                for (Integer c : m.colors) colorArr.put(c);
                o.put("colors", colorArr);
                JSONArray names = new JSONArray();
                for (String name : m.paletteNames) names.put(name);
                o.put("paletteNames", names);
                arr.put(o);
            }
            getSharedPreferences(PREFS, MODE_PRIVATE).edit().putString(KEY_LISTS, arr.toString()).apply();
        } catch (Exception ignored) { }
    }

    private void createDefaultLists() {
        ColorListModel m = new ColorListModel();
        m.name = "リスト1";
        m.backgroundColor = N.BG;
        m.colors.add(Color.parseColor("#252020"));
        m.colors.add(Color.parseColor("#454040"));
        m.colors.add(Color.parseColor("#656060"));
        m.colors.add(Color.parseColor("#223355"));
        m.colors.add(Color.parseColor("#445577"));
        m.colors.add(Color.parseColor("#441100"));
        m.colors.add(Color.parseColor("#662211"));
        m.colors.add(Color.parseColor("#775500"));
        m.colors.add(Color.parseColor("#553300"));
        m.colors.add(Color.parseColor("#A9A999"));
        m.colors.add(Color.parseColor("#227733"));
        m.colors.add(Color.parseColor("#00FF40"));
        m.colors.add(Color.parseColor("#FFFFFF"));
        String[] nNames = new String[]{
                "ダークグレー", "グレー", "ライトグレー", "ブルー", "ライトブルー",
                "レッド", "ライトレッド", "オレンジ", "ダークオレンジ", "ホワイト",
                "グリーン", "ネオングリーン", "テキスト"
        };
        for (String name : nNames) m.paletteNames.add(name);
        lists.add(m);
    }

    private void ensurePaletteNames(ColorListModel model, boolean firstList) {
        while (model.paletteNames.size() > model.colors.size()) {
            model.paletteNames.remove(model.paletteNames.size() - 1);
        }
        if (firstList && model.colors.size() == 13) {
            String[] names = new String[]{
                    "ダークグレー", "グレー", "ライトグレー", "ブルー", "ライトブルー",
                    "レッド", "ライトレッド", "オレンジ", "ダークオレンジ", "ホワイト",
                    "グリーン", "ネオングリーン", "テキスト"
            };
            while (model.paletteNames.size() < model.colors.size()) model.paletteNames.add("");
            for (int i = 0; i < names.length; i++) {
                if (model.paletteNames.get(i) == null || model.paletteNames.get(i).trim().isEmpty()) {
                    model.paletteNames.set(i, names[i]);
                }
            }
            return;
        }
        while (model.paletteNames.size() < model.colors.size()) model.paletteNames.add("");
        for (int i = 0; i < model.colors.size(); i++) {
            if (model.paletteNames.get(i) == null || model.paletteNames.get(i).trim().isEmpty()) {
                model.paletteNames.set(i, "パレット" + (model.colors.size() - i));
            }
        }
    }

    private void renumberGenericPaletteNamesFromRight(ColorListModel model) {
        ensurePaletteNames(model, false);
        for (int i = 0; i < model.paletteNames.size(); i++) {
            String current = model.paletteNames.get(i);
            if (current == null || current.trim().isEmpty() || current.matches("パレット\\d+")) {
                model.paletteNames.set(i, "パレット" + (model.paletteNames.size() - i));
            }
        }
    }

    private void copyPaletteList(ColorListModel model) {
        ensurePaletteNames(model, lists.indexOf(model) == 0);
        StringBuilder out = new StringBuilder();
        appendColorCopy(out, "バックグラウンド", model.backgroundColor);
        for (int i = 0; i < model.colors.size(); i++) {
            out.append("\n\n");
            appendColorCopy(out, model.paletteNames.get(i), model.colors.get(i));
        }
        ClipboardManager clipboard = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        if (clipboard != null) {
            clipboard.setPrimaryClip(ClipData.newPlainText(model.name + " カラー", out.toString()));
            Toast.makeText(this, "カラー名とカラーコードをコピーしました", Toast.LENGTH_SHORT).show();
        }
    }

    private void appendColorCopy(StringBuilder out, String name, int color) {
        out.append(name).append('\n').append('#').append(toHex(color));
    }

    private String toHex(int color) {
        return String.format(Locale.US, "%02X%02X%02X", Color.red(color), Color.green(color), Color.blue(color));
    }

    private static final class ColorListModel {
        String name;
        int backgroundColor;
        final List<Integer> colors = new ArrayList<>();
        final List<String> paletteNames = new ArrayList<>();
    }

    private static final class RGBControl {
        final LinearLayout container;
        final SeekBar seekBar;
        final TextView valueView;
        ValueListener listener;

        RGBControl(Activity activity, String label) {
            container = new LinearLayout(activity);
            container.setOrientation(LinearLayout.HORIZONTAL);
            container.setGravity(Gravity.CENTER_VERTICAL);
            LinearLayout.LayoutParams cLp = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            cLp.topMargin = N.dp(activity, 8);
            container.setLayoutParams(cLp);

            TextView tv = new TextView(activity);
            tv.setText(label);
            tv.setTextColor(N.TEXT);
            tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
            container.addView(tv, new LinearLayout.LayoutParams(N.dp(activity, 20), ViewGroup.LayoutParams.WRAP_CONTENT));

            seekBar = new SeekBar(activity);
            seekBar.setMax(255);
            seekBar.setProgressTintList(android.content.res.ColorStateList.valueOf(N.LBLUE));
            seekBar.setThumbTintList(android.content.res.ColorStateList.valueOf(N.WHITE));
            LinearLayout.LayoutParams sLp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
            sLp.leftMargin = N.dp(activity, 8);
            container.addView(seekBar, sLp);

            valueView = new TextView(activity);
            valueView.setTextColor(N.TEXT);
            valueView.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
            valueView.setGravity(Gravity.END | Gravity.CENTER_VERTICAL);
            LinearLayout.LayoutParams vLp = new LinearLayout.LayoutParams(N.dp(activity, 34), ViewGroup.LayoutParams.WRAP_CONTENT);
            vLp.leftMargin = N.dp(activity, 8);
            container.addView(valueView, vLp);

            seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
                @Override public void onStartTrackingTouch(SeekBar seekBar) { }
                @Override public void onStopTrackingTouch(SeekBar seekBar) { }
                @Override public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                    valueView.setText(String.valueOf(progress));
                    if (fromUser && listener != null) listener.onValue(progress);
                }
            });
        }

        void setValue(int value) {
            seekBar.setProgress(value);
            valueView.setText(String.valueOf(value));
        }

        int getValue() {
            return seekBar.getProgress();
        }

        void setListener(ValueListener l) {
            listener = l;
        }

        interface ValueListener { void onValue(int value); }
    }

    private static final class FlowLayout extends ViewGroup {
        private int minGap;
        private int columns = 1;
        private int cellWidth;
        private int cellHeight;
        private float balancedGap;

        FlowLayout(Activity c) { super(c); }

        void setLineSpacing(int px) { minGap = Math.max(minGap, px); }
        void setItemSpacing(int px) { minGap = Math.max(minGap, px); }

        @Override
        protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
            int width = MeasureSpec.getSize(widthMeasureSpec);
            int contentWidth = Math.max(1, width - getPaddingLeft() - getPaddingRight());

            cellWidth = 0;
            cellHeight = 0;
            for (int i = 0; i < getChildCount(); i++) {
                View child = getChildAt(i);
                measureChild(child, widthMeasureSpec, heightMeasureSpec);
                cellWidth = Math.max(cellWidth, child.getMeasuredWidth());
                cellHeight = Math.max(cellHeight, child.getMeasuredHeight());
            }
            if (cellWidth <= 0) cellWidth = 1;
            if (cellHeight <= 0) cellHeight = 1;

            // Pick the maximum column count that still leaves at least minGap
            // both at the card edges and between circles. This grid is based on
            // card width, not item count, so short rows keep the same left-aligned positions.
            columns = Math.max(1, (contentWidth - minGap) / Math.max(1, cellWidth + minGap));
            while (columns > 1) {
                float g = (contentWidth - (columns * cellWidth)) / (float) (columns + 1);
                if (g >= minGap) break;
                columns--;
            }
            balancedGap = Math.max(minGap,
                    (contentWidth - (columns * cellWidth)) / (float) (columns + 1));

            int rows = getChildCount() == 0 ? 0 : (getChildCount() + columns - 1) / columns;
            int contentHeight = rows == 0 ? 0
                    : Math.round(rows * cellHeight + (rows + 1) * balancedGap);
            int measuredHeight = contentHeight + getPaddingTop() + getPaddingBottom();
            setMeasuredDimension(width, resolveSize(measuredHeight, heightMeasureSpec));
        }

        @Override
        protected void onLayout(boolean changed, int l, int t, int r, int b) {
            for (int i = 0; i < getChildCount(); i++) {
                View child = getChildAt(i);
                int row = i / columns;
                int col = i % columns;
                int x = getPaddingLeft() + Math.round(
                        balancedGap + col * (cellWidth + balancedGap)
                        + (cellWidth - child.getMeasuredWidth()) / 2f);
                int y = getPaddingTop() + Math.round(
                        balancedGap + row * (cellHeight + balancedGap)
                        + (cellHeight - child.getMeasuredHeight()) / 2f);
                child.layout(x, y, x + child.getMeasuredWidth(), y + child.getMeasuredHeight());
            }
        }
    }

    private static final class SVPickerView extends View {
        private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint indicatorPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final RectF rect = new RectF();
        private float hue = 0f;
        private float sat = 0f;
        private float val = 1f;
        private OnColorChangedListener listener;

        SVPickerView(Activity c) {
            super(c);
            indicatorPaint.setStyle(Paint.Style.STROKE);
            indicatorPaint.setStrokeWidth(N.dp(c, 2));
            indicatorPaint.setColor(Color.WHITE);
        }

        void setOnColorChangedListener(OnColorChangedListener l) { listener = l; }

        void setColor(int color) {
            float[] hsv = new float[3];
            Color.colorToHSV(color, hsv);
            hue = hsv[0];
            sat = hsv[1];
            val = hsv[2];
            invalidate();
        }

        void setHue(float value) {
            hue = value;
            invalidate();
        }

        int getColor() {
            return Color.HSVToColor(new float[]{hue, sat, val});
        }

        @Override
        protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            rect.set(0, 0, getWidth(), getHeight());
            int hueColor = Color.HSVToColor(new float[]{hue, 1f, 1f});
            Shader satShader = new LinearGradient(0, 0, getWidth(), 0,
                    Color.WHITE, hueColor, Shader.TileMode.CLAMP);
            Shader valShader = new LinearGradient(0, 0, 0, getHeight(),
                    Color.TRANSPARENT, Color.BLACK, Shader.TileMode.CLAMP);
            paint.setShader(new ComposeShader(satShader, valShader, PorterDuff.Mode.MULTIPLY));
            canvas.drawRoundRect(rect, 12f, 12f, paint);

            float cx = sat * getWidth();
            float cy = (1f - val) * getHeight();
            canvas.drawCircle(cx, cy, 12f, indicatorPaint);
            indicatorPaint.setStyle(Paint.Style.FILL);
            indicatorPaint.setColor(getColor());
            canvas.drawCircle(cx, cy, 8f, indicatorPaint);
            indicatorPaint.setStyle(Paint.Style.STROKE);
            indicatorPaint.setColor(Color.WHITE);
        }

        @Override
        public boolean onTouchEvent(MotionEvent event) {
            switch (event.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                case MotionEvent.ACTION_MOVE:
                    sat = clamp(event.getX() / Math.max(1f, getWidth()));
                    val = 1f - clamp(event.getY() / Math.max(1f, getHeight()));
                    invalidate();
                    if (listener != null) listener.onColorChanged(getColor());
                    return true;
            }
            return super.onTouchEvent(event);
        }

        private float clamp(float v) {
            return Math.max(0f, Math.min(1f, v));
        }

        interface OnColorChangedListener { void onColorChanged(int color); }
    }
}
