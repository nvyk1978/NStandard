package com.cmyk.nstandard;

import android.app.Activity;
import android.app.AlertDialog;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.text.Editable;
import android.text.InputType;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.EditText;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashSet;
import java.util.List;

/** Price Rec. v0.1.81 新規商品追加ダイアログのNS見本。 */
public final class NNewProductDialog {
    private static final int DGRAY = Color.parseColor("#252020");
    private static final int GRAY = Color.parseColor("#454040");
    private static final int LGRAY = Color.parseColor("#656060");
    private static final int BLUE = Color.parseColor("#223355");
    private static final int ORANGE = Color.parseColor("#775500");
    private static final int WHITE = Color.WHITE;
    private static final int SECONDARY = Color.parseColor("#A9A999");
    private static final int DIALOG_MARGIN = 14;
    private static final int SPACING = 8;
    private static final int TIGHT = 4;
    private static final int ACTION_GAP = 5;
    private static final int ACTION_SPACING = 18;
    private static final int ACTION_BOTTOM = 14;

    private NNewProductDialog() {}

    public interface SaveListener { void onSave(ProductData data); }

    public static final class ProductData {
        public String storeName;
        public String name;
        public int price;
        public int volume;
        public String productKey;
        public String priceType = "不明";
        public final LinkedHashSet<String> tags = new LinkedHashSet<>();
    }

    public static void show(Activity activity, String initialStore, SaveListener listener) {
        if (activity == null) return;
        final List<String> stores = Arrays.asList("店舗名", "店舗 02", "店舗 03");
        final String[] selectedStore = {initialStore != null && stores.contains(initialStore) ? initialStore : null};
        final String[] selectedPriceType = {"不明"};
        final LinkedHashSet<String> selectedTags = new LinkedHashSet<>();

        LinearLayout panel = new LinearLayout(activity);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(activity, DIALOG_MARGIN), dp(activity, SPACING),
                dp(activity, DIALOG_MARGIN), dp(activity, ACTION_BOTTOM));

        LinearLayout form = new LinearLayout(activity);
        form.setOrientation(LinearLayout.VERTICAL);
        panel.addView(form, new LinearLayout.LayoutParams(-1, -2));

        TextView storeButton = button(activity, selectedStore[0] == null ? "店舗を選択" : selectedStore[0], DGRAY, 14);
        LinearLayout.LayoutParams storeLp = new LinearLayout.LayoutParams(-1, dp(activity, 44));
        storeLp.bottomMargin = dp(activity, SPACING);
        form.addView(storeButton, storeLp);

        EditText name = input(activity, "商品名");
        addControl(activity, form, "商品名", name);

        EditText price = input(activity, "価格");
        price.setInputType(InputType.TYPE_CLASS_NUMBER);
        price.setKeyListener(android.text.method.DigitsKeyListener.getInstance("0123456789"));
        addControl(activity, form, "価格（円）", price);

        EditText volume = input(activity, "容量");
        volume.setInputType(InputType.TYPE_CLASS_NUMBER);
        volume.setKeyListener(android.text.method.DigitsKeyListener.getInstance("0123456789"));
        addControl(activity, form, "容量", volume);

        EditText productKey = input(activity, "product_key（空欄で自動生成）");
        productKey.setKeyListener(android.text.method.DigitsKeyListener.getInstance(
                "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ._-"));
        addControl(activity, form, "product_key", productKey);

        TextView priceType = button(activity, selectedPriceType[0], DGRAY, 14);
        priceType.setOnClickListener(v -> showPriceTypeChoice(activity, selectedPriceType, priceType));
        addControl(activity, form, "価格種別", priceType);

        View tagArea = makeTagArea(activity, selectedTags);
        addWrapControl(activity, form, "タグ", tagArea);

        LinearLayout actions = new LinearLayout(activity);
        actions.setGravity(Gravity.CENTER_VERTICAL | Gravity.END);
        actions.addView(new View(activity), new LinearLayout.LayoutParams(0, dp(activity, 38), 1f));
        TextView cancel = button(activity, "キャンセル", DGRAY, 13);
        TextView save = button(activity, "保存", DGRAY, 13);
        actions.addView(cancel, new LinearLayout.LayoutParams(dp(activity, 92), dp(activity, 38)));
        LinearLayout.LayoutParams saveLp = new LinearLayout.LayoutParams(dp(activity, 92), dp(activity, 38));
        saveLp.leftMargin = dp(activity, ACTION_GAP);
        actions.addView(save, saveLp);
        LinearLayout.LayoutParams actionsLp = new LinearLayout.LayoutParams(-1, dp(activity, 38));
        actionsLp.topMargin = dp(activity, ACTION_SPACING);
        panel.addView(actions, actionsLp);

        ScrollView scroll = new ScrollView(activity);
        scroll.setFillViewport(false);
        scroll.setVerticalFadingEdgeEnabled(true);
        scroll.setFadingEdgeLength(dp(activity, 24));
        scroll.addView(panel, new ScrollView.LayoutParams(-1, -2));

        AlertDialog dialog = new AlertDialog.Builder(activity)
                .setTitle("新規商品追加")
                .setView(scroll)
                .create();

        Runnable refreshSave = () -> {
            boolean valid = selectedStore[0] != null
                    && !name.getText().toString().trim().isEmpty()
                    && !price.getText().toString().trim().isEmpty();
            setButtonEnabled(activity, save, valid);
        };
        TextWatcher watcher = new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) { refreshSave.run(); }
            @Override public void afterTextChanged(Editable s) {}
        };
        name.addTextChangedListener(watcher);
        price.addTextChangedListener(watcher);
        storeButton.setOnClickListener(v -> showStoreChoice(activity, stores, selectedStore, storeButton, refreshSave));
        refreshSave.run();

        cancel.setOnClickListener(v -> dialog.dismiss());
        save.setOnClickListener(v -> {
            if (!save.isEnabled()) return;
            ProductData data = new ProductData();
            data.storeName = selectedStore[0];
            data.name = name.getText().toString().trim();
            try { data.price = Integer.parseInt(price.getText().toString().trim()); }
            catch (Exception e) { price.setError("整数で入力"); price.requestFocus(); return; }
            try { data.volume = Integer.parseInt(volume.getText().toString().trim()); }
            catch (Exception ignored) { data.volume = 0; }
            data.productKey = productKey.getText().toString().trim();
            if (data.productKey.isEmpty()) data.productKey = "prd." + data.name.replace(" ", ".") + "." + data.volume;
            data.priceType = selectedPriceType[0];
            data.tags.addAll(selectedTags);
            dialog.dismiss();
            if (listener != null) listener.onSave(data);
        });

        showRounded(activity, dialog, true);
    }

    private static void showStoreChoice(Activity activity, List<String> stores, String[] selected,
                                        TextView button, Runnable afterChange) {
        AlertDialog d = new AlertDialog.Builder(activity)
                .setTitle("店舗を選択")
                .setItems(stores.toArray(new String[0]), (dialog, which) -> {
                    selected[0] = stores.get(which);
                    button.setText(selected[0]);
                    if (afterChange != null) afterChange.run();
                })
                .setNegativeButton("キャンセル", null)
                .create();
        showRounded(activity, d, false);
    }

    private static void showPriceTypeChoice(Activity activity, String[] selected, TextView button) {
        String[] values = {"税抜", "税込", "不明"};
        int checked = "税抜".equals(selected[0]) ? 0 : ("税込".equals(selected[0]) ? 1 : 2);
        AlertDialog d = new AlertDialog.Builder(activity)
                .setTitle("価格種別")
                .setSingleChoiceItems(values, checked, (dialog, which) -> {
                    selected[0] = values[which];
                    button.setText(values[which]);
                    dialog.dismiss();
                })
                .setNegativeButton("キャンセル", null)
                .create();
        showRounded(activity, d, false);
    }

    private static View makeTagArea(Activity activity, LinkedHashSet<String> selected) {
        LinearLayout host = new LinearLayout(activity);
        host.setGravity(Gravity.CENTER_VERTICAL);
        ArrayList<String> tags = new ArrayList<>(Arrays.asList("ビール", "ウイスキー", "ジン", "ワイン"));
        final Runnable[] render = new Runnable[1];
        render[0] = () -> {
            host.removeAllViews();
            HorizontalScrollView hsv = new HorizontalScrollView(activity);
            hsv.setHorizontalScrollBarEnabled(false);
            LinearLayout row = new LinearLayout(activity);
            row.setGravity(Gravity.CENTER_VERTICAL);
            for (String tag : tags) {
                TextView chip = chip(activity, tag, selected.contains(tag), false);
                chip.setOnClickListener(v -> { if (!selected.add(tag)) selected.remove(tag); render[0].run(); });
                row.addView(chip);
            }
            TextView none = chip(activity, "タグなし", selected.isEmpty(), true);
            none.setOnClickListener(v -> { selected.clear(); render[0].run(); });
            row.addView(none);
            TextView plus = chip(activity, "＋", false, false);
            plus.setBackground(round(activity, ORANGE, 18));
            plus.setOnClickListener(v -> {
                String newTag = "タグ" + (tags.size() + 1);
                tags.add(newTag); selected.add(newTag); render[0].run();
            });
            row.addView(plus);
            hsv.addView(row);
            host.addView(hsv, new LinearLayout.LayoutParams(-1, -2));
        };
        render[0].run();
        return host;
    }

    private static void addControl(Activity a, LinearLayout panel, String label, View control) {
        TextView l = text(a, label, 12, SECONDARY, false);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, dp(a, 24));
        lp.topMargin = dp(a, TIGHT);
        panel.addView(l, lp);
        panel.addView(control, new LinearLayout.LayoutParams(-1, dp(a, 46)));
    }

    private static void addWrapControl(Activity a, LinearLayout panel, String label, View control) {
        TextView l = text(a, label, 12, SECONDARY, false);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, dp(a, 24));
        lp.topMargin = dp(a, TIGHT);
        panel.addView(l, lp);
        control.setMinimumHeight(dp(a, 46));
        panel.addView(control, new LinearLayout.LayoutParams(-1, -2));
    }

    private static EditText input(Activity a, String hint) {
        EditText e = new EditText(a);
        e.setHint(hint); e.setHintTextColor(LGRAY); e.setTextColor(WHITE); e.setTextSize(15);
        e.setSingleLine(true); e.setPadding(dp(a, 12), 0, dp(a, 12), 0);
        e.setBackground(round(a, DGRAY, 14));
        return e;
    }

    private static TextView button(Activity a, String label, int bg, int sp) {
        TextView t = text(a, label, sp, WHITE, true);
        t.setGravity(Gravity.CENTER); t.setBackground(round(a, bg, 18));
        t.setClickable(true); t.setFocusable(true); return t;
    }

    private static TextView chip(Activity a, String label, boolean selected, boolean none) {
        TextView t = text(a, label, 12, selected ? WHITE : SECONDARY, selected);
        t.setGravity(Gravity.CENTER); t.setPadding(dp(a, 12), 0, dp(a, 12), 0);
        t.setBackground(round(a, selected ? BLUE : (none ? DGRAY : GRAY), 16));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, dp(a, 34)); lp.rightMargin = dp(a, 6); t.setLayoutParams(lp);
        return t;
    }

    private static TextView text(Activity a, String s, int sp, int color, boolean bold) {
        TextView t = new TextView(a); t.setText(s); t.setTextSize(sp); t.setTextColor(color);
        t.setGravity(Gravity.CENTER_VERTICAL); if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD); return t;
    }

    private static void setButtonEnabled(Activity a, TextView button, boolean enabled) {
        button.setEnabled(enabled); button.setTextColor(enabled ? WHITE : LGRAY);
        button.setBackground(round(a, enabled ? BLUE : DGRAY, 18));
        button.setAlpha(enabled ? 1f : .78f);
    }

    private static GradientDrawable round(Activity a, int color, float radiusDp) {
        GradientDrawable g = new GradientDrawable(); g.setColor(color); g.setCornerRadius(dp(a, radiusDp)); return g;
    }

    private static void showRounded(Activity a, AlertDialog dialog, boolean wide) {
        dialog.setOnShowListener(v -> {
            Window w = dialog.getWindow(); if (w == null) return;
            w.setBackgroundDrawable(round(a, GRAY, 20));
            WindowManager.LayoutParams p = new WindowManager.LayoutParams(); p.copyFrom(w.getAttributes());
            p.width = Math.round(a.getResources().getDisplayMetrics().widthPixels * (wide ? .94f : .90f));
            p.height = WindowManager.LayoutParams.WRAP_CONTENT; w.setAttributes(p);
        });
        dialog.show();
    }

    private static int dp(Activity a, float v) { return Math.round(v * a.getResources().getDisplayMetrics().density); }
}
