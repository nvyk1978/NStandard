package com.cmyk.nstandard;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.HapticFeedbackConstants;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

/** PriceRec v0.1.81 diagnostic-log dialog, extracted and adapted for N Standard. */
final class NDiagnosticLog {
    private static final int UI_DIALOG_MARGIN_DP = 14;
    private static final int UI_DIALOG_EDGE_MARGIN_DP = 14;
    private static final int UI_SPACING_DP = 8;

    private NDiagnosticLog() {}

    static void show(Activity activity) {
        LinearLayout panel = new LinearLayout(activity);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(activity, UI_DIALOG_MARGIN_DP), dp(activity, UI_DIALOG_EDGE_MARGIN_DP),
                dp(activity, UI_DIALOG_MARGIN_DP), dp(activity, UI_DIALOG_EDGE_MARGIN_DP));

        TextView title = text(activity, "診断ログ", 21, N.TEXT, true);
        panel.addView(title, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(activity, 44)));

        ScrollView scroll = newAutoFadeScrollView(activity);
        scroll.setFillViewport(false);
        TextView body = text(activity, DiagLog.report(activity), 11, N.TEXT, false);
        body.setTypeface(Typeface.MONOSPACE);
        body.setTextIsSelectable(true);
        body.setPadding(dp(activity, 10), dp(activity, 8), dp(activity, 10), dp(activity, 8));
        body.setBackground(roundRect(activity, N.DGRAY, 10));
        scroll.addView(body, new ScrollView.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        panel.addView(withFastScroll(activity, scroll), new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(activity, 430)));

        LinearLayout actions = new LinearLayout(activity);
        actions.setGravity(Gravity.CENTER_VERTICAL);
        actions.setPadding(0, dp(activity, UI_SPACING_DP), 0, 0);

        TextView clearAction = makeDialogAction(activity, "ログ消去");
        TextView copyAction = makeDialogAction(activity, "コピー");
        TextView closeAction = makeDialogAction(activity, "閉じる");
        clearAction.setGravity(Gravity.CENTER_VERTICAL | Gravity.START);
        copyAction.setGravity(Gravity.CENTER);
        closeAction.setGravity(Gravity.CENTER_VERTICAL | Gravity.END);

        LinearLayout rightActions = new LinearLayout(activity);
        rightActions.setOrientation(LinearLayout.HORIZONTAL);
        rightActions.setGravity(Gravity.CENTER_VERTICAL | Gravity.END);
        rightActions.addView(copyAction, new LinearLayout.LayoutParams(dp(activity, 92), dp(activity, 48)));
        rightActions.addView(closeAction, new LinearLayout.LayoutParams(dp(activity, 92), dp(activity, 48)));

        actions.addView(clearAction, new LinearLayout.LayoutParams(0, dp(activity, 48), 1f));
        actions.addView(rightActions, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, dp(activity, 48)));
        panel.addView(actions);

        AlertDialog dialog = new AlertDialog.Builder(activity)
                .setView(panel)
                .create();

        clearAction.setOnClickListener(v -> {
            DiagLog.clear(activity);
            body.setText(DiagLog.report(activity));
            Toast.makeText(activity, "診断ログを消去しました", Toast.LENGTH_SHORT).show();
        });
        copyAction.setOnClickListener(v -> {
            String report = DiagLog.report(activity);
            ClipboardManager cm = (ClipboardManager) activity.getSystemService(Context.CLIPBOARD_SERVICE);
            cm.setPrimaryClip(ClipData.newPlainText("N Standard diagnostic", report));
            Toast.makeText(activity, "診断ログをコピーしました", Toast.LENGTH_SHORT).show();
        });
        closeAction.setOnClickListener(v -> dialog.dismiss());

        dialog.show();
        Window window = dialog.getWindow();
        if (window != null) {
            window.setBackgroundDrawable(roundRect(activity, N.GRAY, 20));
            window.setLayout(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.WRAP_CONTENT);
        }
    }

    private static ScrollView newAutoFadeScrollView(Activity activity) {
        ScrollView scroll = new ScrollView(activity);
        scroll.setScrollbarFadingEnabled(true);
        scroll.setScrollBarDefaultDelayBeforeFade(850);
        scroll.setScrollBarFadeDuration(300);
        scroll.setScrollBarStyle(View.SCROLLBARS_INSIDE_OVERLAY);
        return scroll;
    }

    private static FrameLayout withFastScroll(Activity activity, ScrollView scroll) {
        FrameLayout frame = new FrameLayout(activity);
        scroll.setVerticalScrollBarEnabled(false);
        frame.addView(scroll, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        FrameLayout grip = new FrameLayout(activity);
        grip.setContentDescription("スクロールグリップ");
        grip.setClickable(true);
        grip.setFocusable(true);
        grip.setAlpha(0f);
        FrameLayout.LayoutParams gripLp = new FrameLayout.LayoutParams(
                dp(activity, 32), dp(activity, 58), Gravity.END | Gravity.TOP);
        gripLp.topMargin = dp(activity, 4);
        frame.addView(grip, gripLp);

        View thumb = new View(activity);
        thumb.setBackground(roundRect(activity, N.LGRAY, 999));
        thumb.setContentDescription("スクロールサム");
        FrameLayout.LayoutParams thumbLp = new FrameLayout.LayoutParams(
                dp(activity, 12), dp(activity, 58), Gravity.CENTER);
        grip.addView(thumb, thumbLp);

        final Runnable[] hideGrip = new Runnable[1];
        final Runnable[] showGrip = new Runnable[1];
        hideGrip[0] = () -> grip.animate().alpha(0f).setDuration(280).start();
        showGrip[0] = () -> {
            if (grip.getVisibility() != View.VISIBLE) return;
            grip.removeCallbacks(hideGrip[0]);
            grip.animate().cancel();
            grip.setAlpha(1f);
            grip.postDelayed(hideGrip[0], 900L);
        };

        final Runnable[] update = new Runnable[1];
        update[0] = () -> {
            if (scroll.getChildCount() == 0 || frame.getHeight() <= 0) return;
            int range = Math.max(0, scroll.getChildAt(0).getHeight() - scroll.getHeight());
            if (range <= 0) {
                grip.setVisibility(View.GONE);
                return;
            }
            if (grip.getVisibility() != View.VISIBLE) {
                grip.setVisibility(View.VISIBLE);
                grip.setAlpha(0f);
            }
            int top = dp(activity, 4);
            int travel = Math.max(1, frame.getHeight() - grip.getHeight() - dp(activity, 8));
            float fraction = Math.max(0f, Math.min(1f, scroll.getScrollY() / (float) range));
            grip.setTranslationY(top + fraction * travel);
        };
        scroll.setOnScrollChangeListener((v, sx, sy, oldSx, oldSy) -> {
            update[0].run();
            if (sy != oldSy) showGrip[0].run();
        });

        final float[] grabOffset = {0f};
        grip.setOnTouchListener((v, event) -> {
            switch (event.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    grabOffset[0] = event.getY();
                    v.getParent().requestDisallowInterceptTouchEvent(true);
                    thumb.setBackground(roundRect(activity, N.WHITE, 999));
                    showGrip[0].run();
                    v.performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK);
                    return true;
                case MotionEvent.ACTION_MOVE:
                    if (scroll.getChildCount() == 0) return true;
                    int range = Math.max(0, scroll.getChildAt(0).getHeight() - scroll.getHeight());
                    int top = dp(activity, 4);
                    int travel = Math.max(1, frame.getHeight() - grip.getHeight() - dp(activity, 8));
                    int[] loc = new int[2];
                    frame.getLocationOnScreen(loc);
                    float wanted = event.getRawY() - loc[1] - grabOffset[0] - top;
                    float fraction = Math.max(0f, Math.min(1f, wanted / travel));
                    scroll.scrollTo(scroll.getScrollX(), Math.round(range * fraction));
                    update[0].run();
                    showGrip[0].run();
                    return true;
                case MotionEvent.ACTION_UP:
                case MotionEvent.ACTION_CANCEL:
                    v.getParent().requestDisallowInterceptTouchEvent(false);
                    thumb.setBackground(roundRect(activity, N.LGRAY, 999));
                    showGrip[0].run();
                    return true;
                default:
                    return true;
            }
        });
        frame.post(update[0]);
        return frame;
    }

    private static TextView makeDialogAction(Activity activity, String value) {
        TextView t = text(activity, value, 14, N.TEXT, true);
        t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        t.setIncludeFontPadding(false);
        t.setGravity(Gravity.CENTER);
        t.setSingleLine(true);
        t.setPadding(dp(activity, 8), 0, dp(activity, 8), 0);
        t.setBackground(new LinkCapsuleDrawable(activity, t, N.LBLUE));
        return t;
    }

    private static TextView text(Activity activity, String value, float sp, int color, boolean bold) {
        TextView t = new TextView(activity);
        t.setText(value);
        t.setTextSize(sp);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }

    private static GradientDrawable roundRect(Activity activity, int fill, int radiusDp) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(fill);
        d.setCornerRadius(dp(activity, radiusDp));
        return d;
    }

    private static int dp(Activity activity, float value) {
        return Math.round(value * activity.getResources().getDisplayMetrics().density);
    }

    private static final class LinkCapsuleDrawable extends Drawable {
        private final Activity activity;
        private final TextView host;
        private final int enabledColor;
        private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);

        LinkCapsuleDrawable(Activity activity, TextView host, int enabledColor) {
            this.activity = activity;
            this.host = host;
            this.enabledColor = enabledColor;
            paint.setStyle(Paint.Style.FILL);
        }

        @Override public void draw(Canvas canvas) {
            paint.setColor(host.isEnabled() ? enabledColor : N.DGRAY);
            CharSequence label = host.getText();
            float textWidth = host.getPaint().measureText(label == null ? "" : label.toString());
            float visualWidth = Math.max(dp(activity, 24), textWidth + dp(activity, 14));
            float visualHeight = dp(activity, 26);
            android.graphics.Rect bounds = getBounds();

            int absoluteGravity = Gravity.getAbsoluteGravity(host.getGravity(), host.getLayoutDirection());
            int horizontal = absoluteGravity & Gravity.HORIZONTAL_GRAVITY_MASK;
            float contentLeft = bounds.left + host.getPaddingLeft();
            float contentRight = bounds.right - host.getPaddingRight();
            float textLeft;
            if (horizontal == Gravity.RIGHT) {
                textLeft = contentRight - textWidth;
            } else if (horizontal == Gravity.CENTER_HORIZONTAL) {
                textLeft = (contentLeft + contentRight - textWidth) / 2f;
            } else {
                textLeft = contentLeft;
            }

            float left = textLeft - dp(activity, 7);
            float right = textLeft + textWidth + dp(activity, 7);
            if (left < bounds.left) {
                right += bounds.left - left;
                left = bounds.left;
            }
            if (right > bounds.right) {
                left -= right - bounds.right;
                right = bounds.right;
            }
            if (right - left < visualWidth) {
                float cx = (left + right) / 2f;
                left = Math.max(bounds.left, cx - visualWidth / 2f);
                right = Math.min(bounds.right, cx + visualWidth / 2f);
            }
            float cy = bounds.exactCenterY();
            float top = cy - visualHeight / 2f;
            float bottom = cy + visualHeight / 2f;
            canvas.drawRoundRect(left, top, right, bottom, visualHeight / 2f, visualHeight / 2f, paint);
        }

        @Override public void setAlpha(int alpha) { paint.setAlpha(alpha); }
        @Override public void setColorFilter(android.graphics.ColorFilter colorFilter) { paint.setColorFilter(colorFilter); }
        @Override public int getOpacity() { return android.graphics.PixelFormat.TRANSLUCENT; }
    }
}
