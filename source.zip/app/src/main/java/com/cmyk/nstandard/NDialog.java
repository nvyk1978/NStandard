package com.cmyk.nstandard;

import android.app.Activity;
import android.app.Dialog;
import android.graphics.drawable.GradientDrawable;
import android.text.InputType;
import android.view.Gravity;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Space;
import android.widget.TextView;

/**
 * Generic N dialog extracted from BookmarkLauncher.
 * Bookmark-specific bookmark/folder/thumbnail behavior is intentionally excluded.
 */
public final class NDialog {
    public interface ChoiceListener { void onChoice(int which); }
    public interface TextListener { void onText(String text); }

    private static final int L_RED = 0xFF662211;

    private NDialog() {}

    public static void showChoices(Activity activity, String title, String[] items,
                                   int destructiveIndex, ChoiceListener listener) {
        Dialog dialog = baseDialog(activity);
        LinearLayout root = root(activity);
        addTitle(activity, root, title, Gravity.CENTER_VERTICAL);

        for (int i = 0; i < items.length; i++) {
            final int index = i;
            TextView row = action(activity, items[i], i == destructiveIndex ? L_RED : N.LBLUE);
            row.setOnClickListener(v -> {
                dialog.dismiss();
                if (listener != null) listener.onChoice(index);
            });
            root.addView(row, lpMatchWrap(activity, 0, 4, 0, 4));
        }

        dialog.setContentView(root);
        show(activity, dialog);
    }

    /**
     * Launcher-style context menu: one large rounded N-gray panel with simple
     * left-aligned white rows. Rows are intentionally not pill buttons.
     */
    public static void showPlainMenu(Activity activity, String title, String[] items,
                                     ChoiceListener listener) {
        Dialog dialog = baseDialog(activity);
        LinearLayout root = root(activity);
        addTitle(activity, root, title, Gravity.CENTER_VERTICAL);

        ScrollView scroll = new ScrollView(activity);
        LinearLayout list = new LinearLayout(activity);
        list.setOrientation(LinearLayout.VERTICAL);
        scroll.addView(list, new ScrollView.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT));

        for (int i = 0; i < items.length; i++) {
            final int index = i;
            TextView row = new TextView(activity);
            row.setText(items[i]);
            row.setTextColor(N.TEXT);
            row.setTextSize(18);
            row.setGravity(Gravity.START | Gravity.CENTER_VERTICAL);
            row.setPadding(N.dp(activity, 4), 0, N.dp(activity, 4), 0);
            row.setBackgroundColor(0x00000000);
            row.setOnClickListener(v -> {
                dialog.dismiss();
                if (listener != null) listener.onChoice(index);
            });
            list.addView(row, new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    N.dp(activity, 58)));
        }

        int maxHeight = Math.round(activity.getResources().getDisplayMetrics().heightPixels * 0.62f);
        int menuHeight = Math.min(maxHeight, N.dp(activity, Math.max(1, items.length) * 58));
        root.addView(scroll, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, menuHeight));

        dialog.setContentView(root);
        show(activity, dialog);
    }

    public static void showMessage(Activity activity, String title, String message) {
        Dialog dialog = baseDialog(activity);
        LinearLayout root = root(activity);
        addTitle(activity, root, title, Gravity.CENTER_VERTICAL);

        ScrollView scroll = new ScrollView(activity);
        TextView body = new TextView(activity);
        body.setText(message);
        body.setTextColor(N.TEXT);
        body.setTextSize(15);
        body.setLineSpacing(0f, 1.12f);
        body.setPadding(N.dp(activity, 4), N.dp(activity, 2),
                N.dp(activity, 4), N.dp(activity, 12));
        scroll.addView(body, new ScrollView.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT));
        root.addView(scroll, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                N.dp(activity, 220)));

        LinearLayout buttons = buttonRow(activity);
        TextView close = action(activity, "閉じる", N.LBLUE);
        close.setGravity(Gravity.CENTER);
        close.setOnClickListener(v -> dialog.dismiss());
        buttons.addView(close, new LinearLayout.LayoutParams(
                N.dp(activity, 96), N.dp(activity, 46)));
        root.addView(buttons, lpMatchWrap(activity, 10, 8, 0, 0));

        dialog.setContentView(root);
        show(activity, dialog);
    }

    public static void showInput(Activity activity, String title, String hint, String initial,
                                 boolean uriInput, String positiveLabel, TextListener listener) {
        Dialog dialog = baseDialog(activity);
        LinearLayout root = root(activity);
        addTitle(activity, root, title, Gravity.CENTER_VERTICAL);

        EditText input = new EditText(activity);
        input.setSingleLine(true);
        input.setText(initial == null ? "" : initial);
        input.setHint(hint);
        input.setTextColor(N.TEXT);
        input.setHintTextColor(N.WHITE);
        input.setTextSize(16);
        input.setPadding(N.dp(activity, 14), 0, N.dp(activity, 14), 0);
        input.setBackground(roundRect(activity, N.GRAY, 12));
        input.setInputType(uriInput
                ? InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI
                : InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
        root.addView(input, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                N.dp(activity, 52)));

        LinearLayout buttons = buttonRow(activity);

        TextView cancel = action(activity, "キャンセル", N.LBLUE);
        cancel.setGravity(Gravity.CENTER);
        cancel.setOnClickListener(v -> dialog.dismiss());
        buttons.addView(cancel, new LinearLayout.LayoutParams(
                N.dp(activity, 112), N.dp(activity, 46)));

        Space gap = new Space(activity);
        buttons.addView(gap, new LinearLayout.LayoutParams(N.dp(activity, 8), 1));

        TextView ok = action(activity, positiveLabel, N.LBLUE);
        ok.setGravity(Gravity.CENTER);
        ok.setOnClickListener(v -> {
            String text = input.getText().toString().trim();
            dialog.dismiss();
            if (listener != null) listener.onText(text);
        });
        buttons.addView(ok, new LinearLayout.LayoutParams(
                N.dp(activity, 96), N.dp(activity, 46)));
        root.addView(buttons, lpMatchWrap(activity, 14, 12, 0, 0));

        dialog.setContentView(root);
        dialog.setOnShowListener(d -> {
            input.requestFocus();
            Window w = dialog.getWindow();
            if (w != null) {
                w.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_VISIBLE);
            }
        });
        show(activity, dialog);
    }

    private static Dialog baseDialog(Activity activity) {
        Dialog dialog = new Dialog(activity);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setCancelable(true);
        dialog.setCanceledOnTouchOutside(true);
        return dialog;
    }

    private static LinearLayout root(Activity activity) {
        LinearLayout root = new LinearLayout(activity);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(N.dp(activity, 18), N.dp(activity, 18),
                N.dp(activity, 18), N.dp(activity, 18));
        root.setBackground(roundRect(activity, N.GRAY, 18));
        return root;
    }

    private static void addTitle(Activity activity, LinearLayout root, String title, int gravity) {
        TextView tv = new TextView(activity);
        tv.setText(title);
        tv.setTextColor(N.TEXT);
        tv.setTextSize(20);
        tv.setGravity(gravity);
        root.addView(tv, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                N.dp(activity, 46)));
    }

    private static TextView action(Activity activity, String text, int background) {
        TextView tv = new TextView(activity);
        tv.setText(text);
        tv.setTextColor(N.TEXT);
        tv.setTextSize(16);
        tv.setGravity(Gravity.CENTER_VERTICAL);
        tv.setPadding(N.dp(activity, 14), 0, N.dp(activity, 14), 0);
        tv.setBackground(roundRect(activity, background, 999));
        return tv;
    }

    private static LinearLayout buttonRow(Activity activity) {
        LinearLayout row = new LinearLayout(activity);
        row.setGravity(Gravity.END | Gravity.CENTER_VERTICAL);
        return row;
    }

    private static void show(Activity activity, Dialog dialog) {
        dialog.show();
        Window w = dialog.getWindow();
        if (w != null) {
            w.setBackgroundDrawableResource(android.R.color.transparent);
            WindowManager.LayoutParams p = new WindowManager.LayoutParams();
            p.copyFrom(w.getAttributes());
            p.width = activity.getResources().getDisplayMetrics().widthPixels - N.dp(activity, 36);
            p.height = WindowManager.LayoutParams.WRAP_CONTENT;
            p.gravity = Gravity.CENTER;
            w.setAttributes(p);
        }
    }

    private static GradientDrawable roundRect(Activity activity, int color, int radiusDp) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(N.dp(activity, radiusDp));
        return d;
    }

    private static LinearLayout.LayoutParams lpMatchWrap(Activity activity,
                                                          int topDp, int bottomDp,
                                                          int leftDp, int rightDp) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.setMargins(N.dp(activity, leftDp), N.dp(activity, topDp),
                N.dp(activity, rightDp), N.dp(activity, bottomDp));
        return lp;
    }
}
