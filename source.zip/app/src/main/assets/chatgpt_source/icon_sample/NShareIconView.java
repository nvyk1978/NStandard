package com.cmyk.nstandard;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.view.View;

/**
 * Canonical N Standard round share control.
 * The glyph is geometrically centered in the circle and intentionally one size smaller
 * than the previous 0.1.27 implementation.
 */
final class NShareIconView extends View {
    static final int SIZE_DP = 42;

    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint line = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint node = new Paint(Paint.ANTI_ALIAS_FLAG);

    NShareIconView(Context context) {
        super(context);
        setClickable(true);
        setFocusable(true);
        fill.setColor(N.DGRAY);
        fill.setStyle(Paint.Style.FILL);
        line.setColor(Color.WHITE);
        line.setStyle(Paint.Style.STROKE);
        line.setStrokeCap(Paint.Cap.ROUND);
        line.setStrokeJoin(Paint.Join.ROUND);
        node.setColor(Color.WHITE);
        node.setStyle(Paint.Style.FILL);
    }

    @Override protected void onDraw(Canvas c) {
        super.onDraw(c);
        float w = getWidth(), h = getHeight();
        float size = Math.min(w, h);
        float cx = w / 2f, cy = h / 2f;

        c.drawCircle(cx, cy, size * .5f, fill);

        // Symmetric coordinates keep the complete glyph's bounding box centered at (cx, cy).
        // Smaller than v0.1.27 while preserving the same share-symbol proportions.
        float armX = size * .145f;
        float armY = size * .145f;
        float x1 = cx - armX, y1 = cy;
        float x2 = cx + armX, y2 = cy - armY;
        float x3 = cx + armX, y3 = cy + armY;
        line.setStrokeWidth(Math.max(1.5f, size * .048f));
        c.drawLine(x1, y1, x2, y2, line);
        c.drawLine(x1, y1, x3, y3, line);
        float r = size * .078f;
        c.drawCircle(x1, y1, r, node);
        c.drawCircle(x2, y2, r, node);
        c.drawCircle(x3, y3, r, node);
    }
}
